import {
  LayoutDefinition,
  useLayoutSelector,
} from '@bambu/references-react-ui-components';
import { _ } from '@bambu/js-core';

import { useCallback, useMemo } from 'react';

/**
 * The useLayoutDefinition hook makes it easier to manage the layout configuration by
 * managing and resolving any user defined overrides for a specific layout
 * @param defaults the default settings for the layout.  Any user overrides are merged with this
 * @returns the resolved layout and a function to set overrides for the user
 */
export function useLayoutDefinition<LayoutConfig extends LayoutDefinition>(
  defaults: LayoutConfig
): [LayoutConfig, (overrides: Partial<LayoutConfig>) => void] {
  const name = defaults.name;
  // Check if we have a matching definition in the store
  const currentLayoutSettings = useLayoutSelector<LayoutConfig>(name);

  const resolvedLayout: LayoutConfig = useMemo(() => {
    return _.merge({}, defaults, currentLayoutSettings);
  }, [currentLayoutSettings, defaults]);

  const setLayoutOverrides = useCallback((overrides: Partial<LayoutConfig>) => {
    console.log('set overrides on app state');
  }, []);

  return [resolvedLayout, setLayoutOverrides];
}
