import { render } from '@testing-library/react';

import EmptyLayout from './EmptyLayout';

describe(EmptyLayout.name, () => {
  test.todo(`Test ${EmptyLayout.name}`);
  // it('should render successfully', () => {
  //   const { baseElement } = render(<EmptyLayout>Things</EmptyLayout>);
  //   expect(baseElement).toBeTruthy();
  // });
});
