import {
  AppContextComponent,
  createStore,
} from '@bambu/references-react-ui-components';
import { Meta, Story } from '@storybook/react';
import { Provider } from 'react-redux';
import {
  EmptyLayout as Component,
  EmptyLayoutDefaults,
  EmptyLayoutProps,
} from './EmptyLayout';
const meta: Meta = {
  component: Component,
  argTypes: {},
  parameters: {
    controls: { expanded: true },
  },
};

export default meta;

const Template: Story<EmptyLayoutProps> = (args, { parameters }) => {
  const { appConfig: config, themes } = parameters;

  const store = createStore({});
  return (
    <Provider store={store}>
      <AppContextComponent
        config={config}
        themes={themes}
        getAuthContext={() => {
          return {} as any;
        }}
      >
        <Component {...args} />
      </AppContextComponent>
    </Provider>
  );
};

export const EmptyLayout = Template.bind({});
EmptyLayout.args = {
  layoutConfig: {
    ...EmptyLayoutDefaults,
  },
};
