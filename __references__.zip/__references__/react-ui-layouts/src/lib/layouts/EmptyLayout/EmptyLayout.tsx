import {
  ComponentAlignmentHorizontal,
  ComponentAlignmentVertical,
  ComponentColor,
  ContextPanelPosition,
  LayoutContainerProps,
  LayoutDefinition,
  StateDialog,
  useApplication,
} from '@bambu/references-react-ui-components';
import { Theme } from '@mui/material';
import { ThemeProvider } from '@mui/material/styles';
import { Outlet } from 'react-router-dom';
import { makeStyles } from 'tss-react/mui';
import { useLayoutDefinition } from '../../hooks';
import { AppContextPanel, AppFooter, AppSnackbar } from '../components';

export type EmptyLayoutDefinitionProps = LayoutDefinition & {
  name: 'empty';
  theme: {
    main: string;
    panel: string;
    dialog: string;
    footer: string;
  };
  contextPanel: {
    display: boolean;
    position: ContextPanelPosition;
  };
  messages: {
    position: {
      vertical: Exclude<ComponentAlignmentVertical, 'center'>;
      horizontal: ComponentAlignmentHorizontal;
    };
  };
  footer: {
    display: boolean;
    elevation?: number;
    color?: Exclude<
      ComponentColor,
      'action' | 'disabled' | 'error' | 'warning' | 'info' | 'success'
    >;
  };
};

export const EmptyLayoutDefaults: EmptyLayoutDefinitionProps = {
  name: 'empty',
  theme: {
    main: 'defaultDark',
    panel: 'defaultLight',
    dialog: 'defaultLight',
    footer: 'defaultLight',
  },
  contextPanel: {
    display: true,
    position: 'right',
  },
  messages: {
    position: {
      vertical: 'bottom',
      horizontal: 'left',
    },
  },
  footer: {
    display: true,
  },
};

const useStyles = makeStyles<
  EmptyLayoutDefinitionProps & {
    mainTheme?: Theme;
  }
>()((defaultTheme, layoutConfig) => {
  const theme: Theme = layoutConfig.mainTheme || defaultTheme;

  return {
    root: {
      position: 'relative',
      display: 'flex',
      flexDirection: 'column',
      width: '100%',
      height: '100%',
      overflow: 'hidden',
      backgroundColor: theme.palette.background.paper,
      color: theme.palette.text.primary,
    },
    contentWrapper: {
      display: 'flex',
      flexDirection: 'column',
      flexGrow: 1,
      flexShrink: 1,
      overflow: 'auto',
    },
  };
});

// eslint-disable-next-line @typescript-eslint/no-empty-interface
export interface EmptyLayoutProps
  extends LayoutContainerProps<
    EmptyLayoutDefinitionProps,
    Partial<ReturnType<typeof useStyles>['classes']>
  > {}

export function EmptyLayout({
  className,
  style,
  classes: classesProp,
  layoutConfig = EmptyLayoutDefaults,
}: EmptyLayoutProps) {
  const { themes = {}, config } = useApplication();

  const [layoutProps] = useLayoutDefinition(
    layoutConfig || EmptyLayoutDefaults
  );

  const applicationInfo = {
    author: config?.author.name || 'bambu Pte. Ltd.',
    url: config?.author.url || 'https://bambu.com',
    name: config?.author.name || 'bambu Pte. Ltd.',
    logo: config?.author.logo || 'static/images/logos/logo-shape.png',
  };

  const definedTheme = layoutProps ? themes[layoutProps.theme.main] : undefined;

  const { classes, cx } = useStyles(
    {
      ...layoutProps,
      mainTheme: definedTheme,
    },
    {
      props: {
        classes: classesProp,
      },
    }
  );

  const { theme, messages, contextPanel, footer } = layoutProps;

  return (
    <ThemeProvider theme={themes[theme.main]}>
      <div className={cx(classes.root, className)} style={style}>
        <ThemeProvider theme={themes[theme.dialog]}>
          <StateDialog />
        </ThemeProvider>
        <AppSnackbar
          anchorOrigin={{
            vertical: messages.position.vertical,
            horizontal: messages.position.horizontal,
          }}
        />
        {contextPanel.display && (
          <ThemeProvider theme={themes[theme.panel]}>
            <AppContextPanel position={contextPanel.position} />
          </ThemeProvider>
        )}

        <div className={cx(classes.contentWrapper)}>
          <Outlet />
        </div>
        {footer.display && (
          <ThemeProvider theme={themes[theme.footer]}>
            <AppFooter
              color={footer.color}
              elevation={footer.elevation}
              organisationInfo={applicationInfo}
            />
          </ThemeProvider>
        )}
      </div>
    </ThemeProvider>
  );
}

export default EmptyLayout;
