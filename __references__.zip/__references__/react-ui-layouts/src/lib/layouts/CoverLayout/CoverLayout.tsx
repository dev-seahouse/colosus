import {
  ComponentAlignmentHorizontal,
  ComponentAlignmentVertical,
  ComponentColor,
  Container,
  ContextPanelPosition,
  ImageFit,
  LayoutContainerProps,
  LayoutDefinition,
  StateDialog,
  useApplication,
} from '@bambu/references-react-ui-components';
import { Theme } from '@mui/material';
import { ThemeProvider } from '@mui/material/styles';
import { Outlet } from 'react-router-dom';
import { makeStyles } from 'tss-react/mui';
import { useLayoutDefinition } from '../../hooks';
import { AppContextPanel, AppFooter, AppSnackbar } from '../components';

export type CoverLayoutDefinitionProps = LayoutDefinition & {
  name: 'cover';
  theme: {
    main: string;
    content: string;
    panel: string;
    dialog: string;
    footer: string;
  };
  background: {
    image?: string;
    alpha?: number;
    fit?: ImageFit;
    position?: ComponentAlignmentVertical;
  };
  content: {
    elevation: number;
  };
  contextPanel: {
    display: boolean;
    position: ContextPanelPosition;
  };
  messages: {
    position: {
      vertical: Exclude<ComponentAlignmentVertical, 'center'>;
      horizontal: ComponentAlignmentHorizontal;
    };
  };
  footer: {
    display: boolean;
    elevation?: number;
    color?: Exclude<
      ComponentColor,
      'action' | 'disabled' | 'error' | 'warning' | 'info' | 'success'
    >;
  };
};

export const CoverLayoutDefaults: CoverLayoutDefinitionProps = {
  name: 'cover',
  theme: {
    main: 'defaultDark',
    content: 'defaultLight',
    panel: 'defaultLight',
    dialog: 'defaultLight',
    footer: 'defaultLight',
  },
  background: {
    image: undefined,
    alpha: 0.05,
    fit: 'cover',
    position: 'center',
  },
  content: {
    elevation: 3,
  },
  contextPanel: {
    display: true,
    position: 'right',
  },
  messages: {
    position: {
      vertical: 'bottom',
      horizontal: 'left',
    },
  },
  footer: {
    display: true,
  },
};

const useStyles = makeStyles<
  CoverLayoutDefinitionProps & {
    mainTheme?: Theme;
  }
>()((defaultTheme, layoutConfig) => {
  const theme: Theme = layoutConfig.mainTheme || defaultTheme;

  return {
    root: {
      position: 'relative',
      display: 'flex',
      flexDirection: 'column',
      width: '100%',
      height: '100%',
      overflow: 'hidden',
      alignItems: 'center',

      padding: 0,
    },
    contentArea: {
      flexGrow: 1,
      flexShrink: 0,
      display: 'flex',
      flexDirection: 'column',
      maxWidth: '100%',

      padding: theme.spacing(3),
      justifyContent: 'center',
      alignItems: 'center',

      [theme.breakpoints.down('sm')]: {
        padding: 0,
      },
    },
    content: {
      overflow: 'auto',
    },
    contentWrapper: {
      alignItems: 'center',
      justifyContent: 'center',
      maxHeight: '100vh',

      [theme.breakpoints.up('sm')]: {
        maxHeight: '90vh',
        width: 'auto',
      },
    },
  };
});

// eslint-disable-next-line @typescript-eslint/no-empty-interface
export interface CoverLayoutProps
  extends LayoutContainerProps<
    CoverLayoutDefinitionProps,
    Partial<ReturnType<typeof useStyles>['classes']>
  > {}

export function CoverLayout({
  className,
  style,
  classes: classesProp,
  layoutConfig = CoverLayoutDefaults,
}: CoverLayoutProps) {
  const [layoutProps] = useLayoutDefinition(
    layoutConfig || CoverLayoutDefaults
  );

  const { themes = {}, config } = useApplication();

  const applicationInfo = {
    author: config?.author.name || 'bambu Pte. Ltd.',
    url: config?.author.url || 'https://bambu.com',
    name: config?.author.name || 'bambu Pte. Ltd.',
    logo: config?.author.logo || 'static/images/logos/logo-shape.png',
  };

  const definedTheme = layoutProps ? themes[layoutProps.theme.main] : undefined;

  const { classes, cx } = useStyles(
    {
      ...layoutProps,
      mainTheme: definedTheme,
    },
    {
      props: {
        classes: classesProp,
      },
    }
  );

  if (!layoutProps) {
    return null;
  }

  const { theme, background, content, contextPanel, messages, footer } =
    layoutProps;

  return (
    <ThemeProvider theme={themes[theme.main]}>
      <Container
        className={cx(classes.root, className)}
        style={style}
        imageSrc={background.image}
        imageAlpha={background.alpha}
        imageFit={background.fit}
        imagePosition={background.position}
        square={true}
      >
        <div className={cx(classes.contentArea)}>
          <ThemeProvider theme={themes[theme.dialog]}>
            <StateDialog />
          </ThemeProvider>
          <AppSnackbar
            anchorOrigin={{
              vertical: messages.position.vertical,
              horizontal: messages.position.horizontal,
            }}
          />
          {contextPanel.display && (
            <ThemeProvider theme={themes[theme.panel]}>
              <AppContextPanel position={contextPanel.position} />
            </ThemeProvider>
          )}
          <ThemeProvider theme={themes[theme.content]}>
            <div className={cx(classes.contentWrapper)}>
              <Container
                className={cx(classes.content)}
                style={{
                  ...style,
                  backgroundColor:
                    themes[theme.content].palette.background.paper,
                }}
                elevation={content.elevation}
              >
                <Outlet />
              </Container>
            </div>
          </ThemeProvider>
        </div>

        {footer.display && (
          <ThemeProvider theme={themes[theme.footer]}>
            <AppFooter
              elevation={footer.elevation}
              organisationInfo={applicationInfo}
            />
          </ThemeProvider>
        )}
      </Container>
    </ThemeProvider>
  );
}

export default CoverLayout;
