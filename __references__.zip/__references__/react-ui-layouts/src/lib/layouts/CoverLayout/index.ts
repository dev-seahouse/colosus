export { CoverLayout as default } from './CoverLayout';
export * from './CoverLayout';
