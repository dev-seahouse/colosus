import {
  AppContextComponent,
  createStore,
} from '@bambu/references-react-ui-components';
import { Meta, Story } from '@storybook/react';
import { Provider } from 'react-redux';

import {
  CoverLayout as Component,
  CoverLayoutDefaults,
  CoverLayoutProps,
} from './CoverLayout';
const meta: Meta = {
  component: Component,
  argTypes: {},
  parameters: {
    controls: { expanded: true },
  },
};

export default meta;

const Template: Story<CoverLayoutProps> = (args, { parameters }) => {
  const { appConfig: config, themes } = parameters;

  const store = createStore({});
  return (
    <Provider store={store}>
      <AppContextComponent
        config={config}
        themes={themes}
        getAuthContext={() => {
          return {} as any;
        }}
      >
        <Component {...args} />
      </AppContextComponent>
    </Provider>
  );
};

export const CoverLayout = Template.bind({});
CoverLayout.args = {
  layoutConfig: CoverLayoutDefaults,
};
