import { render } from '@testing-library/react';

import CoverLayout from './CoverLayout';

describe(CoverLayout.name, () => {
  test.todo(`Test ${CoverLayout.name}`);
  // it('should render successfully', () => {
  //   const { baseElement } = render(<CoverLayout>Things</CoverLayout>);
  //   expect(baseElement).toBeTruthy();
  // });
});
