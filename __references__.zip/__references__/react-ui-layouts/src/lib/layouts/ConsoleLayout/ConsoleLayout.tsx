import {
  ComponentAlignmentHorizontal,
  ComponentAlignmentVertical,
  ComponentColor,
  ContextPanelPosition,
  findModule,
  LayoutContainerProps,
  LayoutDefinition,
  StateDialog,
  useApplication,
  useBreakpoint,
  useHookWithRefCallback,
  useLocalization,
} from '@bambu/references-react-ui-components';
import { Theme } from '@mui/material';
import { ThemeProvider } from '@mui/material/styles';

import { ComponentType, useState } from 'react';
import { Outlet } from 'react-router-dom';
import { makeStyles } from 'tss-react/mui';
import { useLayoutDefinition } from '../../hooks';
import {
  AppContextPanel,
  AppFooter,
  AppNavbar,
  AppSnackbar,
  AppToolbar,
  AppUserInfo,
} from '../components';
import { AppLogo } from '../components/AppLogo';
import NavbarToggleButton, {
  NavbarToggleButtonIcons,
} from '../components/NavbarToggleButton';

export type ContentPosition = 'inside' | 'outside';

type AppBarConfig = {
  elevation?: number;
  color?: Exclude<
    ComponentColor,
    'action' | 'disabled' | 'error' | 'warning' | 'info' | 'success'
  >;
  actions?: ComponentType;
};

export type ConsoleLayoutDefinitionProps = LayoutDefinition & {
  name: 'console';
  theme: {
    main: string;
    navbar: string;
    toolbar: string;
    footer: string;
    panel: string;
    dialog: string;
  };
  navbar: {
    display: boolean;
    contentPosition: ContentPosition;
    position: ContextPanelPosition;
    width: number;
    foldedWidth: number;
    flattenNav: boolean;
    folded: boolean;
    header: AppBarConfig;
    shadow: number;
    userInfo: {
      allowProfileClick: boolean;
    };
  };
  toolbar: {
    display: boolean;
    contentPosition: ContentPosition;
  } & AppBarConfig;
  footer: {
    display: boolean;
    contentPosition: ContentPosition;
  } & AppBarConfig;
  contextPanel: {
    display: boolean;
    position: ContextPanelPosition;
  };
  messages: {
    position: {
      vertical: Exclude<ComponentAlignmentVertical, 'center'>;
      horizontal: ComponentAlignmentHorizontal;
    };
  };
};

export const ConsoleLayoutDefaults: ConsoleLayoutDefinitionProps = {
  name: 'console',
  theme: {
    main: 'defaultDark',
    navbar: 'defaultLight',
    toolbar: 'defaultLight',
    footer: 'defaultLight',
    panel: 'defaultLight',
    dialog: 'defaultLight',
  },
  navbar: {
    display: true,
    contentPosition: 'outside',
    position: 'left',
    width: 280,
    foldedWidth: 64,
    flattenNav: true,
    folded: false,
    header: {
      elevation: 0,
      color: 'primary',
    },
    userInfo: {
      allowProfileClick: false,
    },
    shadow: 0,
  },
  contextPanel: {
    display: true,
    position: 'right',
  },
  toolbar: {
    display: true,
    contentPosition: 'inside',
  },
  footer: {
    display: true,
    contentPosition: 'inside',
  },
  messages: {
    position: {
      vertical: 'bottom',
      horizontal: 'left',
    },
  },
};

const useStyles = makeStyles<
  ConsoleLayoutDefinitionProps & {
    mainTheme?: Theme;
    footerHeight?: number;
    toolbarHeight?: number;
    navbarHoverOpen?: boolean;
    navbarResponsive: boolean;
  }
>()((defaultTheme, layoutConfig) => {
  const navbarPosition: ContextPanelPosition = layoutConfig.navbar.position;
  const theme: Theme = layoutConfig.mainTheme || defaultTheme;
  const toolbarHeight: number = layoutConfig.toolbarHeight || 0;
  const footerHeight: number = layoutConfig.footerHeight || 0;
  const navbarHoverOpen = layoutConfig.navbarHoverOpen || false;

  const isFolded = layoutConfig.navbarResponsive
    ? !layoutConfig.navbar.folded
    : layoutConfig.navbar.folded;

  // The width that the navbar should be based on its state
  const navbarIntendedWidth: number = isFolded
    ? layoutConfig.navbar.foldedWidth
    : layoutConfig.navbar.width;

  // The actual width of the navbar based on hover and device type
  const navbarActualWidth: number = isFolded
    ? navbarHoverOpen
      ? layoutConfig.navbar.width
      : layoutConfig.navbar.foldedWidth
    : layoutConfig.navbar.width;

  const navbarBreakpoint = 'lg';

  return {
    root: {
      position: 'relative',
      display: 'flex',
      flexDirection: 'column',
      width: '100%',
      height: '100%',
      overflow: 'hidden',
      backgroundColor: theme.palette.background.default,
      color: theme.palette.text.primary,
    },
    appWrapper: {
      display: 'flex',
      flexDirection: 'column',
      height: '100%',
      overflow: 'hidden',
      flexGrow: 1,
      flexShrink: 0,
      transition: theme.transitions.create(['margin', 'width'], {
        easing: theme.transitions.easing.easeOut,
        duration: theme.transitions.duration.enteringScreen,
      }),

      // Tablet or mobile the navbar is hidden
      width: '100%',
      marginLeft: 0,
      marginRight: 0,

      // Larger screens the navbar is displayed
      [theme.breakpoints.up(navbarBreakpoint)]: {
        width: `calc(100% - ${navbarIntendedWidth}px)`,
        marginLeft:
          navbarPosition === 'left' ? `${navbarIntendedWidth}px` : undefined,
        marginRight:
          navbarPosition === 'right' ? `${navbarIntendedWidth}px` : undefined,
      },
    },
    contentWrapper: {
      display: 'flex',
      flexDirection: 'column',
      flexGrow: 1,
      flexShrink: 1,
      overflow: 'hidden',
    },
    contentWrapper_toolbarOutside: {
      maxHeight: `calc(100% - ${theme.spacing(8)})`,
    },
    appNavbar: {
      '& .MuiDrawer-paper': {
        boxSizing: 'border-box',
        transition: theme.transitions.create(['width'], {
          easing: theme.transitions.easing.easeOut,
          duration: theme.transitions.duration.enteringScreen,
        }),

        // Tablet or mobile the navbar is hidden
        width: `${
          navbarActualWidth === layoutConfig.navbar.foldedWidth
            ? 0
            : navbarActualWidth
        }px`,

        // Larger screens the navbar is displayed
        [theme.breakpoints.up(navbarBreakpoint)]: {
          width: `${navbarActualWidth}px`,
        },
      },
    },
    appPanelClipped: {
      marginTop: toolbarHeight,
      marginBottom: footerHeight,
    },
    appBarOverlay: {
      zIndex: theme.zIndex.drawer + 1,
    },
    appToolbar: {
      display: 'flex',
      flexDirection: 'row',
      flexShrink: 0,
    },
    appToolbar_outside: {
      paddingLeft: theme.spacing(0),
      paddingRight: theme.spacing(0),
      '& .MuiToolbar-root': {
        paddingLeft: theme.spacing(2),
        paddingRight: theme.spacing(2),
      },
    },
    appToolbar_inside: {},
    appFooter: {
      display: 'flex',
      flexDirection: 'row',
      flexShrink: 0,
    },
    appToolbarTitle_outside: {
      width: `calc(${layoutConfig.navbar.width}px - ${theme.spacing(2)})`,
      display: 'flex',
      flexDirection: 'row',
      overflow: 'hidden',
      justifyContent: 'space-between',
    },
    navbarToggleButton_outside: {
      flexShrink: 0,
      flexGrow: 0,
    },
    appLogo_outside: {
      flexShrink: 1,
      flexGrow: 1,
      maxWidth: `calc(${layoutConfig.navbar.width}px - ${theme.spacing(8)})`,
    },
    appFooter_outside: {
      maxWidth: `calc(${layoutConfig.navbar.width}px - ${theme.spacing(4)})`,
    },
    appFooter_inside: {},

    toolbar: {
      transition: theme.transitions.create(['padding'], {
        easing: theme.transitions.easing.easeOut,
        duration: theme.transitions.duration.enteringScreen,
      }),
    },
    navbarToolbar: {
      paddingRight: theme.spacing(2),
    },
    footerToolbar: {
      paddingLeft: 0,
    },
    footerToolbarFolded: {},
    footerToolbarLink: {
      transition: theme.transitions.create(['padding', 'width'], {
        easing: theme.transitions.easing.easeOut,
        duration: theme.transitions.duration.enteringScreen,
      }),
      overflow: 'hidden',
      paddingLeft: theme.spacing(3),
      // Tablet or mobile the navbar is hidden
      width: `${
        navbarActualWidth === layoutConfig.navbar.foldedWidth
          ? 0
          : navbarActualWidth
      }px`,

      // Larger screens the navbar is displayed
      [theme.breakpoints.up(navbarBreakpoint)]: {
        width: `${navbarActualWidth}px`,
      },
    },
    footerToolbarLinkFolded: {
      paddingLeft: `calc((${navbarActualWidth}px - ${theme.spacing(3)}) /2)`,
    },
    footerToolbarLinkText: {
      transition: theme.transitions.create(['opacity', 'width', 'margin'], {
        easing: theme.transitions.easing.easeOut,
        duration: theme.transitions.duration.enteringScreen,
      }),
      opacity: 1,
      maxHeight: theme.spacing(3),
    },
    footerToolbarLinkTextFolded: {
      opacity: 0,
      width: 0,
      flexShrink: 1,
      marginLeft: 0,
    },
    footerToolbarLinkIcon: {
      transition: theme.transitions.create(['opacity', 'width', 'margin'], {
        easing: theme.transitions.easing.easeOut,
        duration: theme.transitions.duration.enteringScreen,
      }),
      opacity: 1,
      maxHeight: theme.spacing(3),
    },
    footerToolbarLinkIconFolded: {
      opacity: 0,
      width: 0,
      flexShrink: 1,
      marginLeft: 0,
    },
    copyrightText: {
      transition: theme.transitions.create(['margin'], {
        easing: theme.transitions.easing.easeOut,
        duration: theme.transitions.duration.enteringScreen,
      }),
    },
    copyrightTextFolded: {
      marginLeft: theme.spacing(0),
    },
    contentNavbarToggle: {
      marginTop: theme.spacing(1),
      marginLeft: theme.spacing(1),
    },
  };
});

export type ConsoleLayoutProps = LayoutContainerProps<
  ConsoleLayoutDefinitionProps,
  Partial<ReturnType<typeof useStyles>['classes']>
>;

export function ConsoleLayout({
  className,
  style,
  classes: classesProp,
  layoutConfig = ConsoleLayoutDefaults,
}: ConsoleLayoutProps) {
  const [layoutProps] = useLayoutDefinition(
    layoutConfig || ConsoleLayoutDefaults
  );

  const {
    themes = {},
    config,
    getAuthContext,
    routes,
    modules,
  } = useApplication();
  const { auth } = getAuthContext();
  const { user } = auth;
  const [navbarHoverOpen, setNavbarHoverOpen] = useState(false);
  const [navbarResponsive, setNavbarResponsive] = useState(false);
  const profileModule = findModule('profileModule', modules);
  const appNavbarID = 'application_navbar';

  const applicationInfo = {
    author: config?.author.name || 'bambu Pte. Ltd.',
    url: config?.author.url || 'https://bambu.com',
    name: config?.author.name || 'bambu Pte. Ltd.',
    logo: config?.author.logo || 'static/images/logos/logo-shape.png',
  };

  const openText = useLocalization('open');
  const closeText = useLocalization('close');
  const pinText = useLocalization('pin');

  const menuIcon = 'menu';

  const toggleIcons: NavbarToggleButtonIcons = {
    pinIcon: {
      icon: 'fa thumbtack',
      text: pinText,
    },
    closeIcon: {
      icon: 'fa angle-double-left',
      text: closeText,
    },
  };

  const [clippedSizes, setClippedSizes] = useState({
    toolbar: 0,
    footer: 0,
  });

  const [footerRef] = useHookWithRefCallback<HTMLDivElement>(
    (ref) => {
      // Only clip if the footer is displayed and outside
      if (
        ref &&
        layoutProps &&
        layoutProps.footer.display &&
        layoutProps.footer.contentPosition === 'outside'
      ) {
        setClippedSizes((sizes) => ({
          ...sizes,
          footer: ref.clientHeight || 0,
        }));
      }
    },
    [layoutProps]
  );

  const [toolbarRef] = useHookWithRefCallback<HTMLDivElement>(
    (ref) => {
      // Only clip if the toolbar is displayed and outside
      if (
        ref &&
        layoutProps &&
        layoutProps.toolbar?.display &&
        layoutProps.toolbar?.contentPosition === 'outside'
      ) {
        setClippedSizes((sizes) => ({
          ...sizes,
          toolbar: ref.clientHeight || 0,
        }));
      }
    },
    [layoutProps]
  );

  const definedTheme = layoutProps ? themes[layoutProps.theme.main] : undefined;

  const { classes, cx } = useStyles(
    {
      ...(layoutProps || ConsoleLayoutDefaults),
      mainTheme: definedTheme,
      footerHeight: clippedSizes.footer,
      toolbarHeight: clippedSizes.toolbar,
      navbarHoverOpen: navbarHoverOpen,
      navbarResponsive: navbarResponsive,
    },
    {
      props: {
        classes: classesProp,
      },
    }
  );

  const breakpoint = definedTheme?.breakpoints.values['lg'] || 400;

  useBreakpoint(
    (isLarger) => {
      setNavbarResponsive(!isLarger);
    },
    breakpoint,
    [breakpoint]
  );

  if (!layoutProps) {
    return null;
  }

  const { toolbar, footer, navbar, contextPanel, theme, messages } =
    layoutProps;

  // Extract modules to render in the toolbar
  const ToolbarModuleActions = toolbar.display && toolbar.actions;

  const isDisplayFolded =
    (navbarResponsive ? !navbar.folded : navbar.folded) && !navbarHoverOpen;

  return (
    <ThemeProvider theme={themes[theme.main]}>
      <div className={cx(classes.root, className)} style={style}>
        <ThemeProvider theme={themes[theme.dialog]}>
          <StateDialog />
        </ThemeProvider>
        <AppSnackbar
          anchorOrigin={{
            vertical: messages.position.vertical,
            horizontal: messages.position.horizontal,
          }}
        />

        {/* Application TOOLBAR */}
        {toolbar.display && toolbar.contentPosition === 'outside' && (
          <ThemeProvider theme={themes[theme.toolbar]}>
            <AppToolbar
              ref={toolbarRef}
              className={cx(
                classes.appToolbar,
                classes.appToolbar_outside,
                classes.appBarOverlay
              )}
              color={toolbar.color}
              elevation={toolbar.elevation}
              titleContent={
                <div className={cx(classes.appToolbarTitle_outside)}>
                  <AppLogo
                    className={cx(classes.appLogo_outside)}
                    title={config?.name || ''}
                    logo={config?.logo || ''}
                  />
                  <NavbarToggleButton
                    variant="animated_simple"
                    folded={navbar.folded}
                    ariaControls={appNavbarID}
                    className={cx(classes.navbarToggleButton_outside)}
                    icon={
                      isDisplayFolded ? menuIcon : toggleIcons.closeIcon.icon
                    }
                    title={
                      isDisplayFolded ? openText : toggleIcons.closeIcon.text
                    }
                    icons={toggleIcons}
                    actionName={ConsoleLayoutDefaults.name}
                  />
                </div>
              }
              actionContent={
                ToolbarModuleActions ? <ToolbarModuleActions /> : undefined
              }
            />
          </ThemeProvider>
        )}

        {/* Application NAVBAR */}
        {navbar.display && navbar.contentPosition === 'outside' && (
          <ThemeProvider theme={themes[theme.navbar]}>
            <AppNavbar
              id={appNavbarID}
              position={navbar.position}
              className={cx(classes.appNavbar)}
              classes={{
                drawerContent: cx(classes.appPanelClipped),
              }}
              HeaderComponent={AppUserInfo}
              HeaderComponentProps={{
                displayName: user?.name,
                profileImage: user?.profileImage,
                roles: user?.roles,
                minimal: isDisplayFolded,
                profilePath: navbar.userInfo.allowProfileClick
                  ? profileModule?.fullPath
                  : null,
              }}
              folded={isDisplayFolded}
              onMouseEnter={() => {
                if (navbar.folded && !navbarResponsive) {
                  setNavbarHoverOpen(true);
                }
              }}
              onMouseLeave={() => {
                setNavbarHoverOpen(false);
              }}
              showTitleBar={
                !toolbar.display || toolbar.contentPosition !== 'outside'
              }
              TitleBarProps={{
                color: navbar.header.color,
                elevation: navbar.header.elevation,
                titleContent:
                  !toolbar.display || toolbar.contentPosition !== 'outside' ? (
                    <AppLogo
                      showTitle={!isDisplayFolded}
                      style={{
                        marginLeft: isDisplayFolded
                          ? themes[theme.navbar].spacing(2)
                          : 0,
                      }}
                      title={config?.name || ''}
                      logo={config?.logo || ''}
                    />
                  ) : undefined,
                actionContent:
                  isDisplayFolded ? undefined : navbarResponsive ? (
                    <NavbarToggleButton
                      ariaControls={appNavbarID}
                      folded={navbar.folded}
                      icon={
                        isDisplayFolded ? menuIcon : toggleIcons.closeIcon.icon
                      }
                      title={
                        isDisplayFolded ? openText : toggleIcons.closeIcon.text
                      }
                      icons={toggleIcons}
                      actionName={ConsoleLayoutDefaults.name}
                    />
                  ) : (
                    <NavbarToggleButton
                      ariaControls={appNavbarID}
                      folded={navbar.folded}
                      icons={toggleIcons}
                      actionName={ConsoleLayoutDefaults.name}
                    />
                  ),
                ToolbarProps: {
                  disableGutters: isDisplayFolded,
                  classes: {
                    root: cx(classes.toolbar, classes.navbarToolbar),
                  },
                },
              }}
              PaperProps={{
                style: {
                  boxShadow: themes[theme.navbar].shadows[navbar.shadow],
                },
              }}
              routes={routes || []}
            >
              {footer.display && footer.contentPosition === 'inside' && (
                <ThemeProvider theme={themes[theme.footer]}>
                  <AppFooter
                    className={cx(classes.appFooter, classes.appFooter_inside)}
                    ref={footerRef}
                    color={footer.color}
                    elevation={footer.elevation}
                    organisationInfo={applicationInfo}
                    showFooterInfo={false}
                    ToolbarProps={{
                      classes: {
                        root: cx(
                          classes.footerToolbar,
                          isDisplayFolded && classes.footerToolbarFolded
                        ),
                      },
                    }}
                    classes={{
                      link: cx(
                        classes.footerToolbarLink,
                        isDisplayFolded && classes.footerToolbarLinkFolded
                      ),
                      linkText: cx(
                        classes.footerToolbarLinkText,
                        isDisplayFolded && classes.footerToolbarLinkTextFolded
                      ),
                      linkIcon: cx(
                        classes.footerToolbarLinkIcon,
                        isDisplayFolded && classes.footerToolbarLinkIconFolded
                      ),
                      contentText: cx(
                        classes.copyrightText,
                        isDisplayFolded && classes.copyrightTextFolded
                      ),
                    }}
                  />
                </ThemeProvider>
              )}
            </AppNavbar>
          </ThemeProvider>
        )}

        {/* Application CONTENT */}
        <div className={cx(classes.appWrapper)}>
          {toolbar.display && toolbar.contentPosition === 'inside' && (
            <ThemeProvider theme={themes[theme.toolbar]}>
              <AppToolbar
                className={cx(classes.appToolbar, classes.appToolbar_inside)}
                ref={toolbarRef}
                color={toolbar.color}
                elevation={toolbar.elevation}
                titleContent={
                  navbarResponsive ? (
                    <NavbarToggleButton
                      ariaControls={appNavbarID}
                      folded={navbar.folded}
                      icon={
                        isDisplayFolded ? menuIcon : toggleIcons.closeIcon.icon
                      }
                      title={
                        isDisplayFolded ? openText : toggleIcons.closeIcon.text
                      }
                      icons={toggleIcons}
                      actionName={ConsoleLayoutDefaults.name}
                    />
                  ) : undefined
                }
                actionContent={
                  ToolbarModuleActions ? <ToolbarModuleActions /> : undefined
                }
              />
            </ThemeProvider>
          )}

          <div
            className={cx(
              classes.contentWrapper,
              toolbar.contentPosition === 'outside' &&
                classes.contentWrapper_toolbarOutside
            )}
          >
            <ThemeProvider theme={themes[theme.main]}>
              <>
                {navbarResponsive && !toolbar.display && (
                  <div>
                    <NavbarToggleButton
                      ariaControls={appNavbarID}
                      className={cx(classes.contentNavbarToggle)}
                      folded={navbar.folded}
                      icon={
                        isDisplayFolded ? menuIcon : toggleIcons.closeIcon.icon
                      }
                      title={
                        isDisplayFolded ? openText : toggleIcons.closeIcon.text
                      }
                      icons={toggleIcons}
                      actionName={ConsoleLayoutDefaults.name}
                    />
                  </div>
                )}
                <Outlet />
              </>
            </ThemeProvider>
          </div>

          {footer.display && footer.contentPosition === 'inside' && (
            <ThemeProvider theme={themes[theme.footer]}>
              <AppFooter
                className={cx(classes.appFooter, classes.appFooter_inside)}
                ref={footerRef}
                color={footer.color}
                elevation={footer.elevation}
                organisationInfo={applicationInfo}
                showOrganisationInfo={false}
              />
            </ThemeProvider>
          )}
        </div>

        {contextPanel.display && (
          <ThemeProvider theme={themes[theme.panel]}>
            <AppContextPanel
              position={contextPanel.position}
              classes={{
                drawerContent: cx(classes.appPanelClipped),
              }}
            />
          </ThemeProvider>
        )}

        {footer.display && footer.contentPosition === 'outside' && (
          <ThemeProvider theme={themes[theme.footer]}>
            <AppFooter
              ref={footerRef}
              className={cx(
                classes.appFooter,
                classes.appFooter_outside,
                classes.appBarOverlay
              )}
              color={footer.color}
              elevation={footer.elevation}
              ToolbarProps={{
                classes: {
                  root: cx(
                    classes.footerToolbar,
                    isDisplayFolded && classes.footerToolbarFolded
                  ),
                },
              }}
              classes={{
                link: cx(
                  classes.footerToolbarLink,
                  isDisplayFolded && classes.footerToolbarLinkFolded
                ),
                linkText: cx(
                  classes.footerToolbarLinkText,
                  isDisplayFolded && classes.footerToolbarLinkTextFolded
                ),
                linkIcon: cx(
                  classes.footerToolbarLinkIcon,
                  isDisplayFolded && classes.footerToolbarLinkIconFolded
                ),
                contentText: cx(
                  classes.copyrightText,
                  isDisplayFolded && classes.copyrightTextFolded
                ),
              }}
              organisationInfo={applicationInfo}
            />
          </ThemeProvider>
        )}

        {/*             
                { config.themeSettingsPanel.display && (
                <ThemeProvider theme={themes.panelTheme}>
                  <SettingsPanelLayout />
                </ThemeProvider>
              ) }
              {
                config.userSettingsPanel.display && (
                  <ThemeProvider theme={themes.panelTheme}>
                    <SessionPanel />
                  </ThemeProvider>
                )
              }

            */}
      </div>
    </ThemeProvider>
  );
}

export default ConsoleLayout;
