import { render } from '@testing-library/react';

import ConsoleLayout from './ConsoleLayout';

describe(ConsoleLayout.name, () => {
  test.todo(`Test ${ConsoleLayout.name}`);
  // it('should render successfully', () => {
  //   const { baseElement } = render(<ConsoleLayout>Things</ConsoleLayout>);
  //   expect(baseElement).toBeTruthy();
  // });
});
