import { _ } from '@bambu/js-core';
import {
  ACTIONS,
  App,
  Button,
  useContextPanelSelector,
} from '@bambu/references-react-ui-components';
import { DialogContent } from '@mui/material';
import { Meta, Story } from '@storybook/react';
import { useDispatch } from 'react-redux';
import {
  ConsoleLayout as Component,
  ConsoleLayoutDefaults,
  ConsoleLayoutProps,
} from './ConsoleLayout';
const meta: Meta = {
  component: Component,
  argTypes: {},
  parameters: {
    controls: { expanded: true },
    storyPadding: '0',
  },
};

const NavTestComponent = () => {
  return <div>Nav Content Component</div>;
};

export default meta;

const TestContent = () => {
  const dispatch = useDispatch();
  const { open: isContextOpen } = useContextPanelSelector();

  const toggleDialog = () => {
    dispatch(
      ACTIONS.dialog.openDialog({
        title: 'A dialog',
        children: <DialogContent>Content in a dialog</DialogContent>,
      })
    );
  };

  const toggleContextPanel = () => {
    if (isContextOpen) {
      dispatch(ACTIONS.contextPanel.closePanel());
    } else {
      dispatch(
        ACTIONS.contextPanel.openPanel({
          title: 'A Context Panel',
          children: <DialogContent>Content in a Context Panel</DialogContent>,
        })
      );
    }
  };

  const toggleMessage = () => {
    dispatch(
      ACTIONS.message.showMessage({
        message: 'Content in a message',
      })
    );
  };

  return (
    <div
      style={{
        display: 'flex',
        flexDirection: 'column',
        padding: 16,
      }}
    >
      <Button onClick={toggleContextPanel} style={{ margin: 8 }}>
        {`Toggle Context Panel (${isContextOpen ? 'CLOSE' : 'OPEN'})`}
      </Button>
      <Button style={{ margin: 8 }} onClick={toggleMessage}>
        Show Message
      </Button>
      <Button style={{ margin: 8 }} onClick={toggleDialog}>
        Show Dialog
      </Button>
    </div>
  );
};

const Template: Story<ConsoleLayoutProps> = (args, { parameters }) => {
  const { themes } = parameters;

  return (
    <App
      config={{
        name: `${Component.name} Test App`,
        logo: 'static/images/logos/logo-shape.png',
        author: {
          name: 'bambu Pte. Ltd.',
          logo: 'static/images/logos/logo-shape.png',
          url: 'https://bambu.com',
        },
      }}
      store={{}}
      themes={themes}
      modules={[
        {
          name: 'fa icons module',
          title: 'icon variants',
          icon: 'fa bell',
          enabled: true,
          navigation: true,
          layout: Component,
          layoutComponentProps: {
            layoutConfig: args.layoutConfig || ConsoleLayoutDefaults,
          },
          modules: [],
          path: '*',
          routes: [
            {
              path: '1',
              title: 'A menu item',
              icon: 'access_time',
              navigation: true,
              component: NavTestComponent,
              index: false,
            },
            {
              path: '2',
              title: 'Another menu item',
              icon: 'fa clock',
              navigation: true,
              component: NavTestComponent,
              index: false,
            },
            {
              path: '3',
              title: 'A menu item',
              icon: 'ion alarm',
              navigation: true,
              component: NavTestComponent,
              index: false,
            },
          ],
        },
        {
          name: 'a default module',
          title: 'Default Module',
          icon: 'add_alert',
          enabled: true,
          navigation: true,
          layout: Component,
          layoutComponentProps: {
            layoutConfig: args.layoutConfig || ConsoleLayoutDefaults,
          },
          modules: [],
          path: '*',
          routes: [
            {
              path: '1',
              title: 'A menu item',
              icon: 'add_alert',
              navigation: true,
              component: NavTestComponent,
              index: false,
            },
            {
              path: '2',
              title: 'Another menu item',
              icon: 'airplay',
              navigation: true,
              component: NavTestComponent,
              index: false,
              routes: [
                {
                  path: '3',
                  title: 'Another menu item',
                  icon: 'airplay',
                  navigation: true,
                  component: NavTestComponent,
                  index: false,
                },
              ],
            },
          ],
        },
      ]}
      DefaultComponent={TestContent}
    />
  );
};

export const ConsoleLayout = Template.bind({});
ConsoleLayout.args = {
  layoutConfig: {
    ...ConsoleLayoutDefaults,
  },
};

export const ConsoleLayoutLTR = Template.bind({});
ConsoleLayoutLTR.args = {
  layoutConfig: _.merge({}, ConsoleLayoutDefaults, {
    navbar: {
      position: 'right',
    },
    contextPanel: {
      position: 'left',
    },
    messages: {
      position: {
        horizontal: 'right',
      },
    },
  }),
};

export const ConsoleLayoutToolsOutside = Template.bind({});
ConsoleLayoutToolsOutside.args = {
  layoutConfig: _.merge({}, ConsoleLayoutDefaults, {
    toolbar: {
      contentPosition: 'outside',
      elevation: 0,
    },
    footer: {
      contentPosition: 'outside',
    },
    navbar: {
      shadow: 3,
    },
  }),
};

export const ConsoleLayoutStandardAppConfig = Template.bind({});
ConsoleLayoutStandardAppConfig.args = {
  layoutConfig: _.merge({}, ConsoleLayoutDefaults, {
    toolbar: {
      display: false,
    },
    footer: {
      color: 'default',
    },
    navbar: {
      shadow: 3,
    },
  }),
};
