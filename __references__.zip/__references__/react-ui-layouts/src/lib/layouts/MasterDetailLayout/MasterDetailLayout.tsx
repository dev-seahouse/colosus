/* eslint-disable @typescript-eslint/ban-types */
import {
  ErrorWrapper,
  LayoutContainerProps,
  LayoutDefinition,
  Loader,
  LocalizationContext,
  Page,
  RepositoryTableRef,
  useApplication,
  useApplicationRepository,
} from '@bambu/references-react-ui-components';
import React, {
  createContext,
  useCallback,
  useContext,
  useMemo,
  useState,
} from 'react';
import { Route, Routes, useNavigate } from 'react-router-dom';
import { makeStyles } from 'tss-react/mui';
import { useLayoutDefinition } from '../../hooks';
import DetailContent from './components/DetailContent';
import MasterContent from './components/MasterContent';
import MasterDetailHeader from './components/MasterDetailHeader';

export type MasterDetailLayout = LayoutDefinition & {
  name: 'masterDetail';
  theme: {
    main: string;
  };
};

export const MasterDetailLayoutDefaults: MasterDetailLayout = {
  name: 'masterDetail',
  theme: {
    main: 'defaultLight',
  },
};

const useStyles = makeStyles()((theme) => {
  return {
    root: {
      backgroundColor: theme.palette.background.default,
      color: theme.palette.text.primary,
      padding: 0,
      overflow: 'auto',
    },
    masterHeader: {
      width: '100%',
      padding: theme.spacing(3),
      paddingTop: theme.spacing(4),
      marginBottom: 0,
    },
    detailHeader: {
      width: '100%',
      padding: theme.spacing(3),
      paddingTop: theme.spacing(2),
      paddingBottom: theme.spacing(1),
      marginBottom: 0,
    },
    errorWrapper: {
      flexGrow: 0,
      flexShrink: 0,
    },
  };
});

export interface MasterDetailLayoutProps
  extends LayoutContainerProps<
    MasterDetailLayout,
    Partial<ReturnType<typeof useStyles>['classes']>
  > {
  repositoryName: string;
  dataDefinition: string;
}

export type MasterDetailContext = {
  // repository: DataRepository<any>;
  isRootContext: boolean;
  selected: any[];
};

export const MasterDetailContext = createContext<MasterDetailContext>(
  {} as MasterDetailContext
);

const newRoute = '/new';
const detailRoute = '/:recordID';

export function MasterDetailLayout({
  className,
  style,
  classes: classesProp,
  layoutConfig = MasterDetailLayoutDefaults,
  repositoryName,
  dataDefinition,
}: MasterDetailLayoutProps) {
  const { classes, cx } = useStyles(undefined, {
    props: {
      classes: classesProp,
    },
  });

  const [layoutProps] = useLayoutDefinition(
    layoutConfig || MasterDetailLayoutDefaults
  );

  const { themes = {}, config } = useApplication();
  const { t } = useContext(LocalizationContext);

  const parentContext = useContext(MasterDetailContext);
  const navigate = useNavigate();

  const isRootContext = !parentContext;
  const { repository, repositoryDescriptor, dataState } =
    useApplicationRepository(repositoryName, dataDefinition);

  const tableRef = React.useRef<RepositoryTableRef<any>>(null);
  const [selected, setSelected] = useState<any[]>([]);

  const errors = useMemo(() => {
    return dataState?.errors && dataState.errors.length > 0
      ? dataState.errors
          .filter((e) => {
            // We filter out cancelled errors because of the use string
            return e[0] !== 'canceled';
          })
          .map((e) => ({
            message: t(...e),
          }))
      : null;
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [dataState?.errors]);

  const hasErrors = errors && errors.length > 0;

  const handleSelectionChange = (selected: any[]) => {
    setSelected(selected);
  };

  return dataState && dataState.page.data ? (
    <MasterDetailContext.Provider
      value={{
        isRootContext: isRootContext,
        selected: selected,
      }}
    >
      <Page className={cx(classes.root, className)} style={style} square={true}>
        <Routes>
          <Route path={newRoute} element={'header:/new'} />
          <Route
            path={detailRoute}
            element={
              <MasterDetailHeader
                className={cx(classes.detailHeader)}
                icon={repositoryDescriptor.icon}
                title={
                  dataState.lastRetrieved
                    ? dataState.lastRetrieved[
                        repositoryDescriptor.primaryTextField
                      ]
                    : repositoryDescriptor.pluralTitle || ''
                }
                model={repositoryDescriptor}
                onAddClick={() => {
                  navigate(`./new`);
                }}
                onBackClick={() => {
                  navigate('./');
                }}
              />
            }
          />
          <Route
            index={true}
            element={
              <MasterDetailHeader
                className={cx(classes.masterHeader)}
                icon={repositoryDescriptor.icon}
                title={repositoryDescriptor.pluralTitle || ''}
                subtitle={
                  repositoryDescriptor.secondaryTextField
                    ? dataState.lastRetrieved[
                        repositoryDescriptor.secondaryTextField
                      ]
                    : undefined
                }
                model={repositoryDescriptor}
                onAddClick={() => {
                  navigate(`./new`);
                }}
                onBackClick={() => {
                  navigate('./');
                }}
                onSearchChange={(e, value) => {
                  tableRef.current?.onSearchChange(value);
                }}
              />
            }
          />
        </Routes>
        {hasErrors && (
          <ErrorWrapper
            className={cx(classes.errorWrapper)}
            errors={errors}
            variant="condensed"
          />
        )}
        <Routes>
          <Route path={newRoute} element={'path:/new'} />
          <Route
            path={detailRoute}
            element={
              <DetailContent
                model={repositoryDescriptor}
                repository={repository}
              />
            }
          />
          <Route
            index={true}
            element={
              <MasterContent
                tableRef={tableRef}
                model={repositoryDescriptor}
                repository={repository}
                onSelectionChange={handleSelectionChange}
                onRowClick={(data) => {
                  navigate(`./${data.id}`);
                }}
              />
            }
          />
        </Routes>
      </Page>
    </MasterDetailContext.Provider>
  ) : (
    <Loader variant="circular" />
  );
}

export default MasterDetailLayout;
