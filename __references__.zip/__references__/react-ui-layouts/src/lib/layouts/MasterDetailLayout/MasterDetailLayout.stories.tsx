import { getQueryParams } from '@bambu/js-core';
import {
  AppContextComponent,
  ApplicationRepositoryBase,
  createModelRepository,
  createStore,
  RepositoryFactory,
} from '@bambu/references-react-ui-components';
import { Meta, Story } from '@storybook/react';
import { Provider } from 'react-redux';
import { MemoryRouter } from 'react-router-dom';
import axios from 'axios';
import {
  MasterDetailLayout as Component,
  MasterDetailLayoutProps,
} from './MasterDetailLayout';

const meta: Meta = {
  component: Component,
  argTypes: {},
  parameters: {
    controls: { expanded: true },
  },
};

export default meta;

class PokemonDto {
  name!: string;
  url!: string;
}

class TestStoryRepositories extends ApplicationRepositoryBase {
  protected createDefinitions(): Record<string, RepositoryFactory<any>> {
    // eslint-disable-next-line @typescript-eslint/no-this-alias
    const self = this;
    return {
      pokemon: createModelRepository<
        PokemonDto & {
          id: string;
        }
      >({
        axios: this.axios,
        baseURL: this.baseURL,
        dtoPath: 'pokemon',
        model: {
          name: 'Pokémon',
          identityField: 'id',
          icon: 'catching_pokemon',
          fields: {
            name: {
              id: 'name',
              type: 'string',
            },
            url: {
              id: 'url',
              type: 'string',
            },
            base_experience: {
              id: 'base_experience',
              type: 'number',
            },
            height: {
              id: 'height',
              type: 'number',
            },
            id: {
              id: 'id',
              type: 'number',
            },
            is_default: {
              id: 'is_default',
              type: 'boolean',
            },
            location_encounters: {
              id: 'location_encounters',
              type: 'url',
            },
            order: {
              id: 'order',
              type: 'number',
            },
            weight: {
              id: 'weight',
              type: 'number',
            },

            // TODO: This is a complex type
            // {
            //   "name": "venusaur",
            //   "url": "https://pokeapi.co/api/v2/pokemon-species/3/"
            // }
            species: {
              id: 'species',
              type: 'string',
            },

            // TODO: This is an array
            abilities: {
              id: 'abilities',
              type: 'string',
            },
            // TODO: This is an array
            forms: {
              id: 'forms',
              type: 'string',
            },
            // TODO: This is an array
            game_indices: {
              id: 'game_indices',
              type: 'string',
            },
            // TODO: This is an array
            held_items: {
              id: 'held_items',
              type: 'string',
            },
            // TODO: This is an array
            moves: {
              id: 'moves',
              type: 'string',
            },
            // TODO: This is an array
            past_types: {
              id: 'past_types',
              type: 'string',
            },

            // TODO: This is complex object
            sprites: {
              id: 'sprites',
              type: 'string',
            },

            // TODO: This is an array
            stats: {
              id: 'stats',
              type: 'string',
            },

            // TODO: This is an array
            types: {
              id: 'types',
              type: 'string',
            },
          },

          listLayout: ['name', 'url'],
          layout: [
            ['name'],
            ['base_experience'],
            ['height'],
            ['id'],
            ['is_default'],
            ['location_encounters'],
            ['order'],
            ['weight'],
          ],
        },
        transforms: {
          // {"count":1154,"next":"https://pokeapi.co/api/v2/pokemon?offset=20&limit=20","previous":null,"results":[{"name":"bulbasaur","url":"https://pokeapi.co/api/v2/pokemon/1/"},{"name":"ivysaur","url":"https://pokeapi.co/api/v2/pokemon/2/"},{"name":"venusaur","url":"https://pokeapi.co/api/v2/pokemon/3/"},{"name":"charmander","url":"https://pokeapi.co/api/v2/pokemon/4/"},{"name":"charmeleon","url":"https://pokeapi.co/api/v2/pokemon/5/"},{"name":"charizard","url":"https://pokeapi.co/api/v2/pokemon/6/"},{"name":"squirtle","url":"https://pokeapi.co/api/v2/pokemon/7/"},{"name":"wartortle","url":"https://pokeapi.co/api/v2/pokemon/8/"},{"name":"blastoise","url":"https://pokeapi.co/api/v2/pokemon/9/"},{"name":"caterpie","url":"https://pokeapi.co/api/v2/pokemon/10/"},{"name":"metapod","url":"https://pokeapi.co/api/v2/pokemon/11/"},{"name":"butterfree","url":"https://pokeapi.co/api/v2/pokemon/12/"},{"name":"weedle","url":"https://pokeapi.co/api/v2/pokemon/13/"},{"name":"kakuna","url":"https://pokeapi.co/api/v2/pokemon/14/"},{"name":"beedrill","url":"https://pokeapi.co/api/v2/pokemon/15/"},{"name":"pidgey","url":"https://pokeapi.co/api/v2/pokemon/16/"},{"name":"pidgeotto","url":"https://pokeapi.co/api/v2/pokemon/17/"},{"name":"pidgeot","url":"https://pokeapi.co/api/v2/pokemon/18/"},{"name":"rattata","url":"https://pokeapi.co/api/v2/pokemon/19/"},{"name":"raticate","url":"https://pokeapi.co/api/v2/pokemon/20/"}]}
          pagedResult(data) {
            // In this case we use the prev and next fields to discover which page we are on
            const previousParams = getQueryParams(data.previous || '');
            const nextParams = getQueryParams(data.next || '');
            const prevOffset = previousParams.offset
              ? Number(previousParams.offset)
              : 0;
            const prevLimit = previousParams.limit
              ? Number(previousParams.limit)
              : 0;
            const nextOffset = nextParams.offset
              ? Number(nextParams.offset)
              : 0;
            const nextLimit = nextParams.limit ? Number(nextParams.limit) : 0;

            const { baseURL } = self;

            return {
              data: data.results.map((p: PokemonDto) => {
                return {
                  ...p,
                  id: p.url.split('/').at(-2),
                };
              }),
              totalCount: data.count,
              index: prevOffset + prevLimit,
              pageSize: prevLimit || data.results.length,
              pageInfo: {
                hasNextPage: Boolean(data.next),
                hasPreviousPage: Boolean(data.previous),
                nextPage: data.next
                  ? `${baseURL}?offset=${nextOffset}&limit=${nextLimit}`
                  : undefined,
                previousPage: data.next
                  ? `${baseURL}?offset=${prevOffset}&limit=${prevLimit}`
                  : undefined,
              },
            };
          },
        },
      }),
    };
  }
}

const Template: Story<MasterDetailLayoutProps> = (args, { parameters }) => {
  const { appConfig: config, themes } = parameters;

  const store = createStore({});
  return (
    <MemoryRouter>
      <Provider store={store}>
        <AppContextComponent
          config={config}
          themes={themes}
          getAuthContext={() => {
            return {} as any;
          }}
          repositories={{
            pokemon: new TestStoryRepositories({
              baseURL: 'https://pokeapi.co/api/v2',
              axios: axios.create({
                headers: {
                  'Content-Type': 'application/json',
                },
                withCredentials: false,
              }),
            }),
          }}
        >
          <Component {...args} />
        </AppContextComponent>
      </Provider>
    </MemoryRouter>
  );
};

export const MasterDetailLayout = Template.bind({});
MasterDetailLayout.args = {
  repositoryName: 'pokemon',
  dataDefinition: 'pokemon',
};
