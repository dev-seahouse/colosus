import { render } from '@testing-library/react';

import Component from './MasterDetailLayout';

describe(Component.name, () => {
  test.todo('test this');
  // it('should render successfully', () => {
  //   const { baseElement } = render(<Component />);
  //   expect(baseElement).toBeTruthy();
  // });
});
