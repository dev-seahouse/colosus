import {
  ComponentColor,
  ContainerRef,
  Icon,
  Page,
  PageProps,
} from '@bambu/references-react-ui-components';
import { mostReadable } from '@bambu/js-core';
import { PaletteColor, Typography } from '@mui/material';
import { makeStyles } from 'tss-react/mui';
import { forwardRef, ReactNode, useCallback, useEffect, useState } from 'react';
import { useTheme } from '@emotion/react';

type StyleProps = {
  backgroundColor: string;
  iconColor: ComponentColor;
};

const useStyles = makeStyles<StyleProps>()(
  (theme, { backgroundColor, iconColor }) => {
    // TODO: Need to set up values for inherit and disabled
    const paletteColor = iconColor as Exclude<
      ComponentColor,
      'inherit' | 'disabled'
    >;
    const color = mostReadable(backgroundColor, [
      (theme.palette[paletteColor] as PaletteColor).main,
      (theme.palette[paletteColor] as PaletteColor).light,
      (theme.palette[paletteColor] as PaletteColor).dark,
    ])?.toHex8String();

    const textColor: string =
      mostReadable(backgroundColor, [
        theme.palette.text.disabled,
        theme.palette.text.secondary,
        theme.palette.text.primary,
        theme.palette.grey[500],
      ])?.toHex8String() || theme.palette.text.secondary;

    return {
      root: {
        textAlign: 'center',
        display: 'flex',
        flexDirection: 'column',
        overflow: 'hidden',
        flexGrow: 1,
        flexShrink: 1,
        padding: theme.spacing(3),
        paddingTop: theme.spacing(4),
      },
      title: {
        margin: theme.spacing(2),
        marginTop: theme.spacing(1),
      },
      excerpt: {
        marginBottom: theme.spacing(4),
      },
      content: {
        marginBottom: theme.spacing(2),
      },
      contentScroll: {
        overflow: 'auto',
        // This is zero to ensure that the content is centered if there are no children
        flexGrow: 0,
        flexShrink: 1,
        paddingLeft: theme.spacing(1),
        paddingRight: theme.spacing(1),
      },
      icon: {
        width: `${theme.spacing(12)}!important`,
        height: `${theme.spacing(12)}!important`,
        fontSize: `${theme.spacing(12)}!important`,

        [theme.breakpoints.up('md')]: {
          width: `${theme.spacing(16)}!important`,
          height: `${theme.spacing(16)}!important`,
          fontSize: `${theme.spacing(16)}!important`,
        },
        marginBottom: theme.spacing(4),
      },
      iconColorFn: {
        color: color,
      },
      contentWrapper: {
        marginBottom: theme.spacing(2),
      },
      captionColorFn: {
        color: textColor,
      },
    };
  }
);

export interface InfoPageProps extends Omit<PageProps, 'children'> {
  title: string;
  /**
   * Can be the string for the icon to display or a component to render
   */
  icon?: ReactNode;
  /**
   * Can be the string for the excerpt box or a component to render
   */
  excerpt?: ReactNode;
  /**
   * Can be the string for the content box or a component to render
   */
  content?: ReactNode;
  iconColor?: ComponentColor;
  children?: ReactNode;
}

export const InfoPage = forwardRef(
  (
    {
      className,
      style,
      classes: classesProp,
      children,
      title,
      icon,
      excerpt,
      content,
      backgroundColor,
      iconColor = 'primary',
      ...rest
    }: InfoPageProps,
    ref
  ) => {
    const theme: any = useTheme();

    // icon could be the icon text, or could be a full node
    const iconName = typeof icon === 'string' ? icon : null;
    const excerptText = typeof excerpt === 'string' ? excerpt : null;
    const contentText = typeof content === 'string' ? content : null;

    const [derivedBackground, setDerivedBackground] = useState<string>();
    const [innerRef, setInnerRef] = useState<ContainerRef>();

    const containerRef = useCallback((node: ContainerRef) => {
      setDerivedBackground(
        node?.backgroundColor || theme.palette.background.default
      );
      setInnerRef(node);
      // eslint-disable-next-line react-hooks/exhaustive-deps
    }, []);

    const { classes, cx } = useStyles(
      {
        backgroundColor: derivedBackground || theme.palette.background.default,
        iconColor,
      },
      {
        props: {
          classes: classesProp,
        },
      }
    );

    useEffect(() => {
      if (!containerRef || !ref) {
        return;
      }
      if (typeof ref === 'function') {
        ref(innerRef);
      } else {
        ref.current = innerRef;
      }
    }, [innerRef, containerRef, ref]);

    return (
      <Page
        className={cx(classes.root, className)}
        backgroundColor={backgroundColor}
        style={style}
        verticalAlign="center"
        horizontalAlign="center"
        ref={containerRef}
        {...rest}
      >
        {
          // Render the IconName or the specified icon Component
          iconName ? (
            <Icon
              className={cx(classes.icon, classes.iconColorFn)}
              color={iconColor}
            >
              {iconName}
            </Icon>
          ) : (
            icon
          )
        }

        <Typography variant="h4" component="h1" className={cx(classes.title)}>
          {title}
        </Typography>

        <div className={cx(classes.contentScroll)}>
          {
            // Render the excerpt text or the specified info Component
            excerptText ? (
              <Typography
                variant="subtitle1"
                component="div"
                className={cx(classes.excerpt, classes.captionColorFn)}
              >
                {excerpt}
              </Typography>
            ) : (
              excerpt
            )
          }

          {
            // Render the content text or the specified info Component
            contentText ? (
              <Typography
                variant="caption"
                component="div"
                className={cx(classes.content, classes.captionColorFn)}
              >
                {content}
              </Typography>
            ) : (
              content
            )
          }

          {children && (
            <div className={cx(classes.contentWrapper, classes.captionColorFn)}>
              {children}
            </div>
          )}
        </div>
      </Page>
    );
  }
);

export default InfoPage;
