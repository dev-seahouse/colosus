export { InfoPage as default } from './InfoPage';
export * from './InfoPage';
