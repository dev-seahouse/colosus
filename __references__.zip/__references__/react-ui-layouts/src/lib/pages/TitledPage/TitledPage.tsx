import {
  ComponentColor,
  ComponentSize,
  IconButtonProps,
  Page,
  PageProps,
  SectionHeader,
  SectionHeaderProps,
} from '@bambu/references-react-ui-components';
import { makeStyles } from 'tss-react/mui';
import { ReactNode } from 'react';

const useStyles = makeStyles()((theme) => {
  return {
    root: {
      padding: 0,
      overflow: 'hidden',
      height: '100%',
    },
    header: {
      display: 'flex',
      flexGrow: 0,
      flexShrink: 0,
      paddingBottom: 0,

      padding: theme.spacing(1),
      paddingTop: theme.spacing(2),
      paddingRight: 0,

      [theme.breakpoints.up('sm')]: {
        padding: theme.spacing(2),
        paddingBottom: 0,
        paddingRight: theme.spacing(2),
      },

      [theme.breakpoints.up('md')]: {
        padding: theme.spacing(3),
        paddingBottom: 0,
        paddingTop: theme.spacing(3),
        paddingRight: theme.spacing(3),
      },
    },
    content: {
      display: 'flex',
      flexDirection: 'column',
      flexGrow: 1,
      width: '100%',
      paddingTop: 0,
      overflow: 'auto',

      padding: theme.spacing(1),
      paddingRight: 0,

      [theme.breakpoints.up('sm')]: {
        padding: theme.spacing(2),
        paddingRight: theme.spacing(2),
      },

      [theme.breakpoints.up('md')]: {
        padding: theme.spacing(3),
        paddingRight: theme.spacing(3),
      },
    },
    containerRoot: {},
  };
});

export interface TitledPageProps extends PageProps {
  title: string;
  headerSize?: ComponentSize;
  actions?: (IconButtonProps | ReactNode)[];
  titleVariant?: SectionHeaderProps['variant'];
  icon?: string;
  iconColor?: ComponentColor;
  iconTitle?: string;
  onIconClick?: () => void;
}

export function TitledPage({
  className,
  style,
  classes: classesProp,
  children,
  renderNavigation,
  headerSize,
  title,
  actions,
  titleVariant = 'condensed',
  icon,
  iconColor,
  iconTitle,
  onIconClick,
  ...rest
}: TitledPageProps) {
  const { classes, cx } = useStyles(undefined, {
    props: {
      classes: classesProp,
    },
  });

  return (
    <Page
      className={cx(classes.root, className)}
      style={style}
      // Render the navigation in the title instead of the page base
      renderNavigation={false}
      classes={{
        root: cx(classes.containerRoot),
      }}
      {...rest}
    >
      <SectionHeader
        className={cx(classes.header)}
        title={title}
        size={headerSize}
        actions={actions as any}
        variant={titleVariant}
        icon={icon}
        iconColor={iconColor}
        iconTitle={iconTitle}
        onIconClick={onIconClick}
      />

      <div className={cx(classes.content)}>{children}</div>
    </Page>
  );
}

export default TitledPage;
