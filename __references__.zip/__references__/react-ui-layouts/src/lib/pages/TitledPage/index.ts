export { TitledPage as default } from './TitledPage';
export * from './TitledPage';
