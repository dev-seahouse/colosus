export { default as ErrorPage } from './ErrorPage/ErrorPage';
export * from './ErrorPage';

export { default as InfoPage } from './InfoPage/InfoPage';
export * from './InfoPage';

export { default as TitledPage } from './TitledPage/TitledPage';
export * from './TitledPage';

export { default as WebPage } from './WebPage/WebPage';
export * from './WebPage';
