export { ErrorPage as default } from './ErrorPage';
export * from './ErrorPage';
