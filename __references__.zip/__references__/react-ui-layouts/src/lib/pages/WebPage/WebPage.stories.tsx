import { Meta, Story } from '@storybook/react';
import { WebPage as Component, WebPageProps } from './WebPage';

const meta: Meta = {
  component: Component,
  argTypes: {
    backgroundColor: {
      control: {
        type: 'color',
      },
    },
  },
  parameters: {
    controls: { expanded: true },
    storyPadding: '0',
  },
};

export default meta;

const Template: Story<WebPageProps> = (args) => <Component {...args} />;

export const WebPage = Template.bind({});
WebPage.args = {
  title: 'A website inside a website',
  src: 'https://www.bambu.co',
  imageSrc:
    'https://i0.wp.com/bambu.co/wp-content/uploads/2021/02/Screen-Shot-2021-09-27-at-2.26.58-PM.png?fit=1868%2C978&ssl=1',
};
