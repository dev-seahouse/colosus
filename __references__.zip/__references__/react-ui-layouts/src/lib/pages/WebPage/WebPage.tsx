import {
  IFrameSandboxProps,
  WebContainer,
} from '@bambu/references-react-ui-components';
import { makeStyles } from 'tss-react/mui';
import TitledPage, { TitledPageProps } from '../TitledPage';

const useStyles = makeStyles()((/*theme*/) => {
  return {
    root: {},
    container: {
      flexGrow: 1,
    },
  };
});

export interface WebPageProps extends Omit<TitledPageProps, 'children'> {
  src: string;
  sandbox?: IFrameSandboxProps[];
}

export function WebPage({
  className,
  style,
  classes: classesProp,
  title,
  src,
  sandbox,
  ...rest
}: WebPageProps) {
  const { classes, cx } = useStyles(undefined, {
    props: {
      classes: classesProp,
    },
  });

  return (
    <TitledPage
      className={cx(classes.root, className)}
      style={style}
      title={title}
      {...rest}
    >
      <WebContainer
        className={cx(classes.container)}
        title={title}
        src={src}
        sandbox={sandbox}
      />
    </TitledPage>
  );
}

export default WebPage;
