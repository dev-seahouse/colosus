export { WebPage as default } from './WebPage';
export * from './WebPage';
