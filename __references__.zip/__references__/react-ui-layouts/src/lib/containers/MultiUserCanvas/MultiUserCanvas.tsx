import { makeStyles } from 'tss-react/mui';
import {
  BaseComponent,
  Container,
  Icon,
  useMouse,
  useWebsockets,
} from '@bambu/references-react-ui-components';
import { useEffect, useRef, useState } from 'react';
import { Typography } from '@mui/material';

const useStyles = makeStyles()((theme) => {
  return {
    root: {
      position: 'relative',
    },
    userAvatar: {
      position: 'absolute',
      display: 'flex',
      flexDirection: 'row',
      transition: theme.transitions.create(['top', 'left'], {
        easing: theme.transitions.easing.easeInOut,
        duration: theme.transitions.duration.shorter,
      }),
    },
  };
});

export interface MultiUserCanvasProps
  extends BaseComponent<
    'div',
    Partial<ReturnType<typeof useStyles>['classes']>
  > {
  host: string;
  namespace: string;
  debounce: number;
}

type UserAvatarProps = {
  displayName: string;
  location: {
    x: number;
    y: number;
  };
};

function UserAvatar({ displayName, location }: UserAvatarProps) {
  const { classes, cx } = useStyles();

  return (
    <div
      className={cx(classes.userAvatar)}
      style={{
        top: location.y,
        left: location.x,
      }}
    >
      <Icon size="small">north_west</Icon>
      <Typography variant="caption">{displayName}</Typography>
    </div>
  );
}

export function MultiUserCanvas({
  className,
  style,
  classes: classesProp,
  host,
  namespace,
  debounce = 200,
}: MultiUserCanvasProps) {
  const { classes, cx } = useStyles(undefined, {
    props: {
      classes: classesProp,
    },
  });

  const [displayName, setDisplayName] = useState('Unknown User');

  const [users, setUsers] = useState<{
    [key: string]: UserAvatarProps;
  }>({});

  const containerRef = useRef(null);

  const handleWSEvent = (event: string, data: any) => {
    const { type, socketID, payload, displayName } = data;
    switch (type) {
      case 'mousemove':
        setUsers((users) => {
          return {
            ...users,
            [socketID]: {
              ...(users[socketID] || {}),
              displayName,
              location: {
                x: payload.offsetX,
                y: payload.offsetY,
              },
            },
          };
        });
        break;
      default:
        console.log(event, { data });
        break;
    }
  };

  const handleUserConnectedEvent = (event: string, data: any) => {
    setUsers((users) => {
      return {
        ...users,
        [data.socketID]: {
          displayName: displayName,
          location: {
            x: 0,
            y: 0,
          },
        },
      };
    });
  };

  const handleUserDisconnectedEvent = (event: string, data: any) => {
    setUsers((users) => {
      delete users[data.socketID];
      return users;
    });
  };

  const handleConnectEvent = (event: string, data: any) => {
    emitEvent('user', {
      namespace: namespace,
      username: 'a user name',
    });
  };

  const { offsetX, offsetY } = useMouse(containerRef, {
    debounce: debounce,
  });

  const { connected, emitEvent, socketID, error } = useWebsockets(
    host,
    namespace,
    {
      connect: handleConnectEvent,
      disconnect: handleWSEvent,
      connect_error: handleWSEvent,
      room: handleWSEvent,
      user: handleWSEvent,
      message: handleWSEvent,
      user_connected: handleUserConnectedEvent,
      user_disconnected: handleUserDisconnectedEvent,
    }
  );

  useEffect(() => {
    if (connected) {
      emitEvent('message', {
        type: 'mousemove',
        message: '',
        displayName: displayName,
        payload: {
          offsetX,
          offsetY,
        },
      });
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [connected, offsetX, offsetY]);

  return (
    <Container
      ref={containerRef}
      className={cx(classes.root, className)}
      style={style}
    >
      <Typography color={connected ? 'green' : 'error'}>
        {connected ? 'Connected' : 'Not Connected'} {`SocketID: ${socketID}`}
      </Typography>
      <Typography color="error">{error}</Typography>
      {Object.entries(users).map(([socketID, userInfo]) => {
        return (
          <UserAvatar
            key={socketID}
            displayName={userInfo.displayName}
            location={userInfo.location}
          />
        );
      })}
    </Container>
  );
}

export default MultiUserCanvas;
