import { Meta, Story } from '@storybook/react';
import {
  MultiUserCanvas as Component,
  MultiUserCanvasProps,
} from './MultiUserCanvas';

const meta: Meta = {
  component: Component,
  argTypes: {},
  parameters: {
    controls: { expanded: true },
  },
};

export default meta;

const Template: Story<MultiUserCanvasProps> = (args) => <Component {...args} />;

export const MultiUserCanvas = Template.bind({});
MultiUserCanvas.args = {
  host: 'https://websockets-staging.bambu.com',
  namespace: 'spaces/multiuser_canvas',
};
