# references-react-ui-layouts

This library was generated with [Nx](https://nx.dev).

## Running unit tests

Run `nx test references-react-ui-layouts` to execute the unit tests via [jest](https://jestjs.io/).
