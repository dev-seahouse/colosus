import { FreezePipe } from './freeze.pipe';

describe('Freeze Pipe', () => {
  let sut: FreezePipe = new FreezePipe();

  beforeEach(() => {
    sut = new FreezePipe();
  });

  it('Should be defined', () => {
    expect(sut).toBeDefined();
  });

  describe('Prevents modification to objects', () => {
    it('prevents modifying objects', async () => {
      const sut: FreezePipe = new FreezePipe();
      const dto = {
        value1: 1,
        value2: 'string',
        objectValue: {
          value1: 2,
          value2: null,
        },
      };

      const transformed = sut.transform(dto);

      expect(transformed.value1).toBe(dto.value1);
      expect(transformed.value2).toBe(dto.value2);
      expect(transformed.objectValue.value1).toBe(dto.objectValue.value1);

      expect(() => {
        transformed.value1 = 4;
      }).toThrowError(
        `Cannot assign to read only property 'value1' of object '#<Object>'`
      );

      expect(() => {
        dto.value2 = 'a string';
      }).toThrowError(
        `Cannot assign to read only property 'value2' of object '#<Object>'`
      );

      expect(() => {
        transformed.objectValue.value1 = 55;
      }).toThrowError(
        `Cannot assign to read only property 'value1' of object '#<Object>'`
      );

      expect(() => {
        transformed.objectValue.value2 = 'something';
      }).toThrowError(
        `Cannot assign to read only property 'value2' of object '#<Object>'`
      );
    });

    it('can handle null objects', async () => {
      const sut: FreezePipe = new FreezePipe();
      const dto = null;

      const transformed = sut.transform(dto);

      expect(transformed).toBe(null);
    });

    it('can handle string primitives', async () => {
      const sut: FreezePipe = new FreezePipe();
      const dto = 'a string';

      const transformed = sut.transform(dto);

      expect(transformed).toBe(dto);
    });

    it('can handle numeric primitives', async () => {
      const sut: FreezePipe = new FreezePipe();
      const dto = 88;

      const transformed = sut.transform(dto);

      expect(transformed).toBe(dto);
    });

    it('can handle boolean primitives', async () => {
      const sut: FreezePipe = new FreezePipe();
      const dto = true;

      const transformed = sut.transform(dto);

      expect(transformed).toBe(dto);
    });
  });
});
