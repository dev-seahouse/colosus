import { AbstractValidationPipe as sut } from './abstract-validation.pipe';

describe(sut.name, () => {
  describe('Defaults', () => {
    // const OLD_ENV = process.env;

    // beforeEach(() => {
    //   jest.resetModules();
    //   process.env = {
    //     ...OLD_ENV,
    //   };
    // });

    // afterAll(() => {
    //   process.env = OLD_ENV;
    // });

    // it('should not be undefined', () => {

    // });

    test.todo('TEST THIS');
  });
});
