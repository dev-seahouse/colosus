import { Injectable, PipeTransform } from '@nestjs/common';

/**
 * Pipe to ensure that any data passed through is readonly
 * and can not accidentally be modified
 */
@Injectable()
export class FreezePipe implements PipeTransform {
  transform(value: any) {
    return this.freezeDeep(value);
  }

  freezeDeep(value: any) {
    if (value) {
      Object.keys(value).forEach((key) => {
        if (typeof value[key] === 'object') {
          this.freezeDeep(value[key]);
        }
      });
    }
    return Object.freeze(value);
  }
}
