/* eslint-disable @typescript-eslint/no-explicit-any */

import * as safeJsonStringify from 'safe-json-stringify';

function serializeObjectAsJsonString(
  jsonObject: object,
  replacer: (key: any, value: any) => any | any[] | null = null,
  space?: string | number
) {
  const plainObject = {};
  Object.getOwnPropertyNames(jsonObject).forEach((key) => {
    plainObject[key] = jsonObject[key];
  });
  return safeJsonStringify(plainObject, replacer, space);
}

/**
 * This is created to solve 2 problems, namely:
 *
 * 1. Fix issue with complex data objects with circular references causing errors/crashes.
 * 2. Allow the stringification/serialization of Error objects into a readable JSON string.
 *
 * The API is modelled after JSON.stringify() with safeguards and ehnaced data extraction capacilities.
 *
 * Docs: https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/JSON/stringify
 * @param {any} jsonObject          Object to strigify/serialize.
 * @param {Function} replacer       A function that alters the behavior of the stringification process, or an array of strings and numbers that specifies properties of value to be included in the output. If replacer is an array, all elements in this array that are not strings or numbers (either primitives or wrapper objects), including Symbol values, are completely ignored. If replacer is anything other than a function or an array (e.g. null or not provided), all string-keyed properties of the object are included in the resulting JSON string.
 * @param {string | number} space   Adds indentation, white space, and line break characters to the return-value JSON text to make it easier to read.
 *
 * @returns {string} Serialized/setring representation of JSON object.
 */
export function Stringify(
  jsonObject: object,
  replacer: (key: any, value: any) => any | any[] | null = null,
  space?: string | number
) {
  if (jsonObject && Array.isArray(jsonObject)) {
    const result = [];
    const numberOfItems = jsonObject.length;

    for (let i = 0; i < numberOfItems; i++) {
      const item = jsonObject[i];
      result.push(
        JSON.parse(serializeObjectAsJsonString(item, replacer, space))
      );
    }

    return JSON.stringify(result, replacer, space);
  }

  return serializeObjectAsJsonString(jsonObject, replacer, space);
}
