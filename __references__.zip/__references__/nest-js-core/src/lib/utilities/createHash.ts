import crypto = require('crypto');

export default function createHash(text: string, algorithm = 'sha256') {
  return crypto.createHash(algorithm).update(text).digest('hex');
}
