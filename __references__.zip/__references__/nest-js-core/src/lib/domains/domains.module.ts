import { Module } from '@nestjs/common';

import { BambuApiLibraryIntegrationDomainModule } from './bambu-api-library-integration/bambu-api-library-integration-domain.module';

@Module({
  imports: [BambuApiLibraryIntegrationDomainModule],
  exports: [BambuApiLibraryIntegrationDomainModule],
})
export class DomainsModule {}
