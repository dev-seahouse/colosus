import {
  IBambuApiLibraryCalculateHouseGoalAmountRequestDto,
  IBambuApiLibraryGetCountriesResponseDto,
  IBambuApiLibraryGetCountryRatesResponseDto,
  IBambuApiLibraryGetProjectionsRequestDto,
  IBambuApiLibraryGetProjectionsResponseDto,
  IBambuApiLibraryCalculateHouseGoalAmountResponseDto,
  IBambuApiLibraryCalculateUniversityGoalAmountResponseDto,
  IBambuApiLibraryCalculateUniversityGoalAmountRequestDto,
} from '@bambu/shared';

export abstract class BambuApiLibraryIntegrationDomainServiceBase {
  abstract GetProjection(
    input: IBambuApiLibraryGetProjectionsRequestDto,
    investorToken: string
  ): Promise<IBambuApiLibraryGetProjectionsResponseDto>;

  abstract GetCountries(
    investorToken: string,
    countryAlpha2Code: string | null
  ): Promise<IBambuApiLibraryGetCountriesResponseDto[]>;

  abstract GetCountryRates(
    investorToken: string,
    countryAlpha2Code: string | null
  ): Promise<IBambuApiLibraryGetCountryRatesResponseDto[]>;

  abstract GetHouseGoalAmount(
    input: IBambuApiLibraryCalculateHouseGoalAmountRequestDto,
    investorToken: string
  ): Promise<IBambuApiLibraryCalculateHouseGoalAmountResponseDto>;

  abstract CalculateUniversityGoalAmount(
    input: IBambuApiLibraryCalculateUniversityGoalAmountRequestDto,
    investorToken: string
  ): Promise<IBambuApiLibraryCalculateUniversityGoalAmountResponseDto>;
}
