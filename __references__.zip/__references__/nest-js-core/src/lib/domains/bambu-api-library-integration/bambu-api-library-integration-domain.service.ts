import { Injectable, Logger } from '@nestjs/common';

import { BambuApiLibraryGraphRepositoryServiceBase } from '../../repositories/bambu-api-library/bambu-api-library-graph-repository.service';
import { BambuApiLibraryCountriesRepositoryServiceBase } from '../../repositories/bambu-api-library/bambu-api-library-countries-repository.service';
import { BambuApiLibraryHouseRepositoryServiceBase } from '../../repositories/bambu-api-library/bambu-api-library-house-repository.service';
import { BambuApiLibraryEducationRepositoryServiceBase } from '../../repositories/bambu-api-library/bambu-api-library-education-repository.service';

import {
  IBambuApiLibraryCalculateHouseGoalAmountRequestDto,
  IBambuApiLibraryCalculateHouseGoalAmountResponseDto,
  IBambuApiLibraryCalculateUniversityGoalAmountRequestDto,
  IBambuApiLibraryCalculateUniversityGoalAmountResponseDto,
  IBambuApiLibraryGetCountriesResponseDto,
  IBambuApiLibraryGetCountryRatesResponseDto,
  IBambuApiLibraryGetProjectionsRequestDto,
  IBambuApiLibraryGetProjectionsResponseDto,
} from '@bambu/shared';
import { BambuApiLibraryIntegrationDomainServiceBase } from './bambu-api-library-integration-domain-service.base';

@Injectable()
export class BambuApiLibraryIntegrationDomainService
  implements BambuApiLibraryIntegrationDomainServiceBase
{
  readonly #logger = new Logger(BambuApiLibraryIntegrationDomainService.name);

  constructor(
    private readonly graphApiRepository: BambuApiLibraryGraphRepositoryServiceBase,
    private readonly countriesApiRepository: BambuApiLibraryCountriesRepositoryServiceBase,
    private readonly houseApiRepository: BambuApiLibraryHouseRepositoryServiceBase,
    private readonly educationApiRepository: BambuApiLibraryEducationRepositoryServiceBase
  ) {}

  async GetProjection(
    input: IBambuApiLibraryGetProjectionsRequestDto,
    investorToken: string
  ): Promise<IBambuApiLibraryGetProjectionsResponseDto> {
    const apiLibBearerToken = await this.#getAdvisorBambuApiLibraryApiKey(
      investorToken
    );
    return await this.graphApiRepository.GetProjections(
      input,
      apiLibBearerToken
    );
  }

  async #getAdvisorBambuApiLibraryApiKey(
    investorToken: string
  ): Promise<string> {
    this.#logger.debug(
      `Getting Bambu API Key for investor token ${investorToken}.`
    );

    /**
     * TODO:
     * Get from DB, introspect from client token.
     */
    return 'b05a8321a5bffa78116c58a9';
  }

  async GetCountries(
    investorToken: string,
    countryAlpha2Code: string | null
  ): Promise<IBambuApiLibraryGetCountriesResponseDto[]> {
    const apiLibBearerToken = await this.#getAdvisorBambuApiLibraryApiKey(
      investorToken
    );
    return await this.countriesApiRepository.GetCountries(
      apiLibBearerToken,
      countryAlpha2Code
    );
  }

  async GetCountryRates(
    investorToken: string,
    countryAlpha2Code: string | null
  ): Promise<IBambuApiLibraryGetCountryRatesResponseDto[]> {
    const apiLibBearerToken = await this.#getAdvisorBambuApiLibraryApiKey(
      investorToken
    );
    return await this.countriesApiRepository.GetCountryRates(
      apiLibBearerToken,
      countryAlpha2Code
    );
  }

  async GetHouseGoalAmount(
    input: IBambuApiLibraryCalculateHouseGoalAmountRequestDto,
    investorToken: string
  ): Promise<IBambuApiLibraryCalculateHouseGoalAmountResponseDto> {
    const apiLibBearerToken = await this.#getAdvisorBambuApiLibraryApiKey(
      investorToken
    );
    return await this.houseApiRepository.CalculateHouseGoalAmount(
      input,
      apiLibBearerToken
    );
  }

  async CalculateUniversityGoalAmount(
    input: IBambuApiLibraryCalculateUniversityGoalAmountRequestDto,
    investorToken: string
  ): Promise<IBambuApiLibraryCalculateUniversityGoalAmountResponseDto> {
    const apiLibBearerToken = await this.#getAdvisorBambuApiLibraryApiKey(
      investorToken
    );

    return await this.educationApiRepository.CalculateUniversityGoalAmount(
      input,
      apiLibBearerToken
    );
  }
}
