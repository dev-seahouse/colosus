import { DeepPartial } from '@bambu/js-core';
import { Logger } from '@nestjs/common';
import Joi = require('joi');
import { ConfigurationFactory } from '.';

type TestConfiguration = {
  prop1: string;
};

type TestOtherFactoryConfiguration = {
  prop2: string;
};

type TestFullConfiguration = {
  test: TestConfiguration;
  otherConfig: TestOtherFactoryConfiguration;
};

class TestConfigurationFactory extends ConfigurationFactory<
  TestConfiguration,
  'test',
  TestFullConfiguration,
  (typeof TestConfigurationFactory)[]
> {
  constructor(
    configOverrides: DeepPartial<TestFullConfiguration>,
    logger?: Logger,
    factories: (typeof TestConfigurationFactory)[] = []
  ) {
    super('test', factories, configOverrides, logger);
  }

  initialiseConfiguration(
    config: DeepPartial<TestFullConfiguration>
  ): DeepPartial<TestFullConfiguration> {
    return {
      ...config,
      test: {
        ...config.test,
        prop1: config.test.prop1 || 'a default value',
      },
    };
  }

  getValidationSchema(schema?: Joi.ObjectSchema<any>): Joi.ObjectSchema<any> {
    schema = super.getValidationSchema(schema);
    if (
      schema.validate({
        prop1: null,
      }).error
    ) {
      return schema.keys({
        ...schema.keys,
        prop2: Joi.string().required(),
      });
    } else {
      return schema.keys({
        ...schema.keys,
        prop1: Joi.string().required(),
      });
    }
  }
}

describe('ConfigurationFactory', () => {
  beforeEach(() => {
    jest.resetModules();
  });

  describe('when constructing', () => {
    it('should have an appropriate key set', () => {
      const factory = new TestConfigurationFactory({}, undefined, []);
      expect(factory.key).toBe('test');
    });

    it('should set the config overrides based on what was passed in', () => {
      let expected = {};
      let factory = new TestConfigurationFactory(expected, undefined, []);
      expect(factory.config).toBe(expected);

      expected = {
        test: { prop1: 'abc' },
        otherConfig: { prop2: 'def' },
      };

      factory = new TestConfigurationFactory(expected, undefined, []);
      expect(factory.config).toBe(expected);
    });

    it('should set the configurable factories correctly', () => {
      const expected = [];
      let factory = new TestConfigurationFactory({}, undefined, []);
      expect(factory.factories).toStrictEqual(expected);

      const expectedFactories = [TestConfigurationFactory];

      factory = new TestConfigurationFactory({}, undefined, expectedFactories);
      expect(factory.factories).toStrictEqual(expectedFactories);
    });

    it('should create a default logger if one is not provided', () => {
      const factory = new TestConfigurationFactory({}, undefined, []);
      expect(factory.logger).toBeDefined();
    });

    it('should will use the logger provided if it is passed in', () => {
      const logger = new Logger('sut logger');
      const factory = new TestConfigurationFactory({}, logger, []);
      expect(factory.logger).toBe(logger);
    });
  });

  describe('when creating a validation schema', () => {
    it('should log that it is doing so', () => {
      const logger = new Logger('sut logger');
      const logSpy = jest.spyOn(logger, 'log');
      const factory = new TestConfigurationFactory({}, logger, []);
      expect(logSpy).toBeCalledTimes(0);
      const validationSchema = factory.getValidationSchema();
      expect(logSpy).toBeCalledTimes(1);
      expect(validationSchema).toBeDefined();
    });

    test.todo('Complete coverage on configuration factory');

    // it('should call any factories that have been provided', () => {
    //   const logger = new Logger('sut logger');
    //   const config: TestFullConfiguration = {
    //     test: { prop1: 'a property' },
    //     otherConfig: { prop2: 'another property' },
    //   };
    //   // Just here to prevent test output to console
    //   jest.spyOn(logger, 'log');
    //   let factory = new TestConfigurationFactory(config, logger, []);
    //   let validationSchema = factory.validationSchema;
    //   expect(validationSchema).toBeDefined();
    //   expect(
    //     validationSchema.validate(
    //       {
    //         prop1: null,
    //         prop2: null,
    //       },
    //       {
    //         abortEarly: false,
    //       },
    //     ).error.message,
    //   ).toBe('"prop1" must be a string. "prop2" is not allowed');

    //   factory = new TestConfigurationFactory(config, logger, [
    //     TestConfigurationFactory,
    //   ]);
    //   validationSchema = factory.validationSchema;
    //   expect(validationSchema).toBeDefined();
    //   expect(
    //     validationSchema.validate(
    //       {
    //         prop1: null,
    //         prop2: null,
    //       },
    //       {
    //         abortEarly: false,
    //       },
    //     ).error[0],
    //   ).toBe('"prop1" must be a string. "prop2" must be a string');
    // });
  });
});
