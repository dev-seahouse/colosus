import { ApplicationInfo, DeepPartial } from '@bambu/js-core';
import { Logger } from '@nestjs/common';
import { ConfigurationFactory } from './configuration-factory';
import { _ } from '@bambu/js-core';

export class ApplicationInfoFactory extends ConfigurationFactory<
  ApplicationInfo,
  'appInfo'
> {
  constructor(
    config?: Record<'appInfo', DeepPartial<ApplicationInfo>>,
    logger?: Logger
  ) {
    super('appInfo', [], config, logger);
  }

  initialiseConfiguration(
    config: DeepPartial<
      Record<'appInfo', ApplicationInfo> & Record<string, any>
    >
  ): DeepPartial<Record<'appInfo', ApplicationInfo> & Record<string, any>> {
    config = _.cloneDeep(config);
    const base: DeepPartial<ApplicationInfo> = config.appInfo || {};
    config.appInfo = {
      ...base,
      name: base.name || 'name not set',
      version: base.version || 'version not set',
      description: base.description || 'description not set',
      keywords: base.keywords || 'keywords not set',
      author: {
        ...base.author,
        name: base.author?.name || 'author not set',
      },
    };
    return config;
  }

  getConfiguration(
    current?: DeepPartial<
      Record<'appInfo', ApplicationInfo> & Record<string, any>
    >
  ): Record<'appInfo', ApplicationInfo> & Record<string, any> {
    current = super.getConfiguration(current);
    // Make any updates to the configuration here
    return current as Record<'appInfo', ApplicationInfo> & Record<string, any>;
  }
}
