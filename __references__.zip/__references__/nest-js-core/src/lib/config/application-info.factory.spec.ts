import { ApplicationInfo } from '@bambu/js-core';
import { ApplicationInfoFactory as sut } from './application-info.factory';

describe('ConfigFactory', () => {
  describe('Defaults', () => {
    const OLD_ENV = process.env;

    beforeEach(() => {
      jest.resetModules();
      process.env = {
        ...OLD_ENV,
      };
    });

    afterAll(() => {
      process.env = OLD_ENV;
    });

    it('should provide defaults for ApplicationInfo', () => {
      const conf: ApplicationInfo = new sut({
        appInfo: {},
      }).getConfiguration().appInfo;

      expect(conf.name).toBe('name not set');
      expect(conf.version).toBe('version not set');
      expect(conf.description).toBe('description not set');
      expect(conf.author).toBeDefined();
      expect(conf.author.name).toBe('author not set');
      expect(conf.keywords).toBe('keywords not set');

      expect(conf.author.logo).toBeUndefined();
      expect(conf.author.url).toBeUndefined();
      expect(conf.logo).toBeUndefined();
      expect(conf.featureImage).toBeUndefined();
    });
  });

  describe('Expands Partial configuration', () => {
    const OLD_ENV = process.env;

    beforeEach(() => {
      jest.resetModules();
      process.env = {
        ...OLD_ENV,
      };
    });

    afterAll(() => {
      process.env = OLD_ENV;
    });

    it('should extract Root Properties from the environment', () => {
      const conf: ApplicationInfo = new sut({
        appInfo: {
          logo: 'a logo url',
          featureImage: 'a feature image url',
          author: {
            logo: 'an author logo',
            url: 'an author url',
          },
        },
      }).getConfiguration().appInfo;

      expect(conf.name).toBe('name not set');
      expect(conf.version).toBe('version not set');
      expect(conf.description).toBe('description not set');
      expect(conf.author).toBeDefined();
      expect(conf.author.name).toBe('author not set');
      expect(conf.keywords).toBe('keywords not set');

      expect(conf.author.logo).toBe('an author logo');
      expect(conf.author.url).toBe('an author url');
      expect(conf.logo).toBe('a logo url');
      expect(conf.featureImage).toBe('a feature image url');
    });
  });

  describe('Full configuration', () => {
    const OLD_ENV = process.env;

    beforeEach(() => {
      jest.resetModules();
      process.env = {
        ...OLD_ENV,
      };
    });

    afterAll(() => {
      process.env = OLD_ENV;
    });

    it('should extract Root Properties from the environment', () => {
      const conf: ApplicationInfo = new sut({
        appInfo: {
          name: 'an application name',
          version: 'an application version',
          description: 'an application description',
          logo: 'a logo url',
          featureImage: 'a feature image url',
          keywords: 'some keywords',
          author: {
            name: 'an author name',
            logo: 'an author logo',
            url: 'an author url',
          },
        },
      }).getConfiguration().appInfo;

      expect(conf.name).toBe('an application name');
      expect(conf.version).toBe('an application version');
      expect(conf.description).toBe('an application description');
      expect(conf.author).toBeDefined();
      expect(conf.author.name).toBe('an author name');
      expect(conf.keywords).toBe('some keywords');

      expect(conf.author.logo).toBe('an author logo');
      expect(conf.author.url).toBe('an author url');
      expect(conf.logo).toBe('a logo url');
      expect(conf.featureImage).toBe('a feature image url');
    });
  });
});
