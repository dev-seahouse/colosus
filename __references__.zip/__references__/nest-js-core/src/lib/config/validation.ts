import * as Joi from 'joi';

export const environmentValidationSchema = Joi.object().keys({
  NODE_ENV: Joi.string()
    .valid('development', 'production', 'staging', 'test')
    .required(),
  PORT: Joi.number().default(9000),
  PROXY_TARGET: Joi.string(),
  SERVER_HOSTNAME: Joi.string(),
  RATE_LIMIT: Joi.number().default(500),
  API_VERSION: Joi.string(),

  DB_SCHEMA: Joi.string(),
  DB_USERNAME: Joi.string(),
  DB_PASSWORD: Joi.string(),
  DB_HOST: Joi.string(),
  DB_PORT: Joi.number(),
  DB_NAME: Joi.string(),
  DB_LOGLEVEL: Joi.string(),
  LOGLEVEL: Joi.string(),
  DB_CONNECTION_STRING: Joi.string(),
});
