import { ApplicationInfo } from '@bambu/js-core';
import {
  Logger,
  NestApplicationOptions,
  ValidationPipe,
  VersioningType,
} from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import { NestFactory } from '@nestjs/core';
import { NestExpressApplication } from '@nestjs/platform-express';
import { enableSecurityHeaders } from '../init/enable-security-headers';
import { staticInitialisation } from '../init/static-inits';
import { ServerConfiguration } from '../modules/server';
import { ConfigurationFactory } from './configuration-factory';
import * as process from 'process';
import { CorsOptions } from '@nestjs/common/interfaces/external/cors-options.interface';

export async function createExpressApp(
  module: unknown,
  options?: NestApplicationOptions
) {
  const app = await NestFactory.create<NestExpressApplication>(module, options);
  const configService: ConfigService = app.get(ConfigService);

  const appInfo: ApplicationInfo = <ApplicationInfo>(
    configService.get('appInfo')
  );

  const logger = new Logger(
    `${appInfo.name}(${appInfo.version})[${process.env.NODE_ENV}]`
  );

  // Set global API prefix.
  app.setGlobalPrefix('api', { exclude: [''] });

  const serverConfig = configService.get<ServerConfiguration>('server');
  const configFactory =
    configService.get<ConfigurationFactory>('configFactory');
  configFactory.logger = logger;

  // Ensure any static fixes and patches are executed
  staticInitialisation(logger);

  process.on('uncaughtException', (err, errorType) => {
    logger.error(`${errorType}: ${err.message}\n${err.stack}`);
  });

  enableSecurityHeaders(logger, app, serverConfig);

  logger.log('Enabling CORS');

  app.enableCors(async (req: Request, callback) => {
    const origin = req.headers['origin'];
    // TODO: check origin against DB (redis)
    const corsOptions: CorsOptions = {
      credentials: true,
      origin: origin,
    };
    callback(null, corsOptions);
  });

  app.useGlobalPipes(
    new ValidationPipe({
      whitelist: true,
      transform: true,
      transformOptions: {
        enableImplicitConversion: true,
      },
      validateCustomDecorators: true,
    })
  );

  // Ensure versioning is enabled for the api
  app.enableVersioning({
    type: VersioningType.URI,
    defaultVersion: serverConfig.apiVersion.toString(),
  });

  configFactory.getInitialisationStrategy(configService).forEach((s) => {
    s(app);
  });

  app.enableShutdownHooks();

  logger.log(
    `listening on ${serverConfig.host} in ${process.env.NODE_ENV} mode`
  );

  // return initialiseApp(logger, app, configService);

  await app.listen(serverConfig.port);

  logger.log(`HTTP port set to listen to port ${serverConfig.port}.`);
}
