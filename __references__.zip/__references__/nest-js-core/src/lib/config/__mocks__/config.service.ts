// import configuration from '../configuration';
import { ConfigurationBase } from '../types';

export class ConfigServiceMock {
  private config: ConfigurationBase;

  constructor() {
    // Nothing here yet
  }

  get(key: string) {
    return this.config[key];
  }
}
