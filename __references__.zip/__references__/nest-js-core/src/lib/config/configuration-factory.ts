import { DeepPartial, _ } from '@bambu/js-core';
import { Logger, Type } from '@nestjs/common';
import {
  ConfigFactory,
  ConfigFactoryKeyHost,
  ConfigObject,
  ConfigService,
  registerAs as registerNestConfigAs,
} from '@nestjs/config';
import { NestModuleConfig } from '../modules';
import * as Joi from 'joi';
import type { NestExpressApplication } from '@nestjs/platform-express';

export type ConfigurationProperties<
  T extends {
    key: string | symbol;
    config: Record<string, any>;
  }
> = T['config'];

export type ResolvedConfiguration<Key extends string, Type> = Record<
  Key,
  Type
> &
  Record<string, any>;
type InitialiseConfiguration<T> = DeepPartial<T>;

export function registerAs<
  K extends string,
  TConfig extends ConfigObject,
  TFactory extends ConfigFactory<TConfig>
>(key: K, config: TFactory) {
  return registerNestConfigAs(key, config) as TFactory &
    ConfigFactoryKeyHost<ReturnType<TFactory>> & { KEY: K };
}

export abstract class ConfigurationFactory<
  ConfigType = any,
  Key extends string = any,
  ResolvedConfigType = ResolvedConfiguration<Key, ConfigType>,
  Factories extends Array<Type<ConfigurationFactory>> = Type<
    ConfigurationFactory<any, any, ResolvedConfigType, any>
  >[],
  InitialisationConfigType = InitialiseConfiguration<ResolvedConfigType>
> {
  private _config: InitialisationConfigType;
  private _logger: Logger;
  private readonly _key: Key;
  private _factories: Factories;

  constructor(
    key: Key,
    factories: Factories,
    config: InitialisationConfigType,
    logger?: Logger
  ) {
    this._logger = logger;
    this._key = key;
    this._factories = factories;
    if (!this._logger) {
      this._logger = new Logger(`${this.constructor.name}`);
    }
    this._config =
      config ||
      ({
        [key]: {},
      } as unknown as InitialisationConfigType);
  }
  get key() {
    return this._key;
  }
  get config() {
    return this._config;
  }
  get factories() {
    return this._factories;
  }
  get logger() {
    return this._logger;
  }
  set logger(logger: Logger) {
    this._logger = logger;
  }

  abstract initialiseConfiguration(
    config: InitialisationConfigType
  ): InitialisationConfigType;

  getValidationSchema(
    schema: Joi.ObjectSchema = Joi.object()
  ): Joi.ObjectSchema {
    this.logger.log(
      `Preparing Environment Validation for ${this.constructor.name}`
    );
    const providedFactories = this.factories;
    if (providedFactories) {
      providedFactories.forEach((Factory) => {
        const factory = new Factory(this.config, this.logger);
        schema = factory.getValidationSchema(schema);
      });
    }
    return schema;
  }

  getConfiguration(current?: InitialisationConfigType): ResolvedConfigType {
    this.logger.log(`Preparing Configuration for ${this.constructor.name}`);
    if (!current) {
      current = this.config;
    }
    current = this.initialiseConfiguration(_.cloneDeep(current));

    return this.factories.reduce((acc, Factory) => {
      const factory = new Factory(acc, this.logger);
      acc = factory.getConfiguration(acc as any);
      return acc;
    }, current) as unknown as ResolvedConfigType;
  }

  getInitialisationStrategy(
    configService: ConfigService
  ): ((app: NestExpressApplication) => void)[] {
    return this.factories.reduce((acc, Factory) => {
      const factory = new Factory({}, this.logger);
      const initialisationStrategy =
        factory.getInitialisationStrategy(configService);
      if (initialisationStrategy && initialisationStrategy.length > 0) {
        this.logger.log(
          `Getting Initialisation Strategy for ${factory.constructor.name}`
        );
        acc.push(...initialisationStrategy);
      }
      return acc;
    }, []);
  }

  getModuleMetadata(): NestModuleConfig[] {
    return this.factories.reduce((acc, Factory) => {
      const factory = new Factory({}, this.logger);
      const moduleMetadata = factory.getModuleMetadata();
      if (moduleMetadata && moduleMetadata.length > 0) {
        this.logger.log(`Getting Metadata for ${factory.constructor.name}`);
        acc.push(...moduleMetadata);
      }
      return acc;
    }, []);
  }
}
