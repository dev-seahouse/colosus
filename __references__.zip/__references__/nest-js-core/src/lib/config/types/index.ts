export * from './configuration-base.type';
