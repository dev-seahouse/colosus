import { ApplicationInfo } from '@bambu/js-core';
import { ServerConfiguration } from '../../modules/server';

// TODO: Switch this to use ConfigurationProperties<*Factory*>
export type ConfigurationBase = {
  server: ServerConfiguration;
  appInfo: ApplicationInfo;
};
