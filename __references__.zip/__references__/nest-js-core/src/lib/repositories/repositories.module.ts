import { Module } from '@nestjs/common';
import { BambuApiLibraryRepositoryModule } from './bambu-api-library/bambu-api-library-repository.module';

@Module({
  imports: [BambuApiLibraryRepositoryModule],
  exports: [BambuApiLibraryRepositoryModule],
})
export class RepositoriesModule {}
