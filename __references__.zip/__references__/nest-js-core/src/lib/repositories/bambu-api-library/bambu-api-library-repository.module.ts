import { Module } from '@nestjs/common';
import { HttpModule } from '@nestjs/axios';

import {
  BambuApiLibraryGraphRepositoryServiceBase,
  BambuApiLibraryGraphRepositoryService,
} from './bambu-api-library-graph-repository.service';
import {
  BambuApiLibraryCountriesRepositoryService,
  BambuApiLibraryCountriesRepositoryServiceBase,
} from './bambu-api-library-countries-repository.service';
import {
  BambuApiLibraryHouseRepositoryService,
  BambuApiLibraryHouseRepositoryServiceBase,
} from './bambu-api-library-house-repository.service';
import {
  BambuApiLibraryEducationRepositoryServiceBase,
  BambuApiLibraryEducationRepositoryService,
} from './bambu-api-library-education-repository.service';

@Module({
  imports: [HttpModule],
  providers: [
    {
      provide: BambuApiLibraryGraphRepositoryServiceBase,
      useClass: BambuApiLibraryGraphRepositoryService,
    },
    {
      provide: BambuApiLibraryCountriesRepositoryServiceBase,
      useClass: BambuApiLibraryCountriesRepositoryService,
    },
    {
      provide: BambuApiLibraryHouseRepositoryServiceBase,
      useClass: BambuApiLibraryHouseRepositoryService,
    },
    {
      provide: BambuApiLibraryEducationRepositoryServiceBase,
      useClass: BambuApiLibraryEducationRepositoryService,
    },
  ],
  exports: [
    BambuApiLibraryGraphRepositoryServiceBase,
    BambuApiLibraryCountriesRepositoryServiceBase,
    BambuApiLibraryHouseRepositoryServiceBase,
    BambuApiLibraryEducationRepositoryServiceBase,
  ],
})
export class BambuApiLibraryRepositoryModule {}
