import { Injectable, Logger } from '@nestjs/common';
import { HttpService } from '@nestjs/axios';
import { firstValueFrom } from 'rxjs';
import { _ } from '@bambu/js-core';

import { JSONUtils } from '../../utilities';

import {
  IBambuApiLibraryGetProjectionsRequestDto,
  IBambuApiLibraryGetProjectionsResponseDto,
} from '@bambu/shared';

export abstract class BambuApiLibraryGraphRepositoryServiceBase {
  public abstract GetProjections(
    input: IBambuApiLibraryGetProjectionsRequestDto,
    bearerToken: string
  ): Promise<IBambuApiLibraryGetProjectionsResponseDto>;
}

@Injectable()
export class BambuApiLibraryGraphRepositoryService
  implements BambuApiLibraryGraphRepositoryServiceBase
{
  readonly #logger: Logger = new Logger(
    BambuApiLibraryGraphRepositoryService.name
  );
  readonly #baseUrl: string;

  constructor(private readonly httpService: HttpService) {
    /**
     * TODO:
     * This needs to come from config later.
     */
    this.#baseUrl = 'https://api-lib.bambu.life';

    this.#logger.debug(`The baseUrl set is ${this.#baseUrl}`);
  }

  public async GetProjections(
    input: IBambuApiLibraryGetProjectionsRequestDto,
    bearerToken: string
  ): Promise<IBambuApiLibraryGetProjectionsResponseDto> {
    const logPrefix = `${this.GetProjections.name} -`;

    try {
      const url = `${this.#baseUrl}/api/returnsCalc/v2/projections`;

      const loggerPayload = {
        input,
        bearerToken,
        url,
      };

      this.#logger.debug(
        `${logPrefix} Calling API with following parameters: ${JSONUtils.Stringify(
          loggerPayload
        )}`
      );

      const source = this.httpService.post(url, input, {
        headers: {
          Authorization: `Bearer ${bearerToken}`,
        },
      });
      const response = await firstValueFrom(source);

      const data = _.cloneDeep(response.data);

      this.#logger.debug(
        [
          `${logPrefix} Data Retrieved: ${JSONUtils.Stringify(data)}.`,
          `Input values: ${JSONUtils.Stringify(loggerPayload)}`,
        ].join(' ')
      );

      return data;
    } catch (error) {
      this.#logger.error(
        `${logPrefix} Error while calling API. Details: ${JSONUtils.Stringify(
          error
        )}`
      );
      throw error;
    }
  }
}
