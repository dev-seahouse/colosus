import { Injectable, Logger } from '@nestjs/common';
import { HttpService } from '@nestjs/axios';
import { firstValueFrom } from 'rxjs';
import { _ } from '@bambu/js-core';

import { JSONUtils } from '../../utilities';

import {
  IBambuApiLibraryCalculateUniversityGoalAmountResponseDto,
  IBambuApiLibraryCalculateUniversityGoalAmountRequestDto,
} from '@bambu/shared';

export abstract class BambuApiLibraryEducationRepositoryServiceBase {
  abstract CalculateUniversityGoalAmount(
    input: IBambuApiLibraryCalculateUniversityGoalAmountRequestDto,
    bearerToken: string
  ): Promise<IBambuApiLibraryCalculateUniversityGoalAmountResponseDto>;
}

@Injectable()
export class BambuApiLibraryEducationRepositoryService
  implements BambuApiLibraryEducationRepositoryServiceBase
{
  readonly #logger: Logger = new Logger(
    BambuApiLibraryEducationRepositoryService.name
  );
  readonly #baseUrl: string;

  constructor(private readonly httpService: HttpService) {
    /**
     * TODO:
     * This needs to come from config later.
     */
    this.#baseUrl = 'https://api-lib.bambu.life';

    this.#logger.debug(`The baseUrl set is ${this.#baseUrl}`);
  }

  async CalculateUniversityGoalAmount(
    input: IBambuApiLibraryCalculateUniversityGoalAmountRequestDto,
    bearerToken: string
  ): Promise<IBambuApiLibraryCalculateUniversityGoalAmountResponseDto> {
    const logPrefix = `${this.CalculateUniversityGoalAmount.name} -`;
    try {
      const url = `${
        this.#baseUrl
      }/api/generalCalculator/v2/goalCalculator/calcUniversityGoalAmount`;
      const loggerPayload = {
        input,
        bearerToken,
        url,
      };
      this.#logger.debug(
        `${logPrefix} Calling API with following parameters: ${JSONUtils.Stringify(
          loggerPayload
        )}`
      );
      const source = this.httpService.post(url, input, {
        headers: {
          Authorization: `Bearer ${bearerToken}`,
        },
      });
      const response = await firstValueFrom(source);
      const data = _.cloneDeep(response.data);
      this.#logger.debug(
        [
          `${logPrefix} Data Retrieved: ${JSONUtils.Stringify(data)}.`,
          `Input values: ${JSONUtils.Stringify(loggerPayload)}`,
        ].join(' ')
      );
      return data;
    } catch (error) {
      this.#logger.error(
        `${logPrefix} Error while calling API. Details: ${JSONUtils.Stringify(
          error
        )}`
      );
      throw error;
    }
  }
}
