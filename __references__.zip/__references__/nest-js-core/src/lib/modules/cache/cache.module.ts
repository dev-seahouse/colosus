import { CacheModule as NestCacheModule, Global, Module } from '@nestjs/common';
import { ConfigModule, ConfigService } from '@nestjs/config';
import { RedisConfiguration } from '../redis';
import { RedisOptions, redisStore } from '../redis/redis-cache-wrapper';

@Global()
@Module({
  imports: [
    NestCacheModule.registerAsync<RedisOptions>({
      imports: [ConfigModule],
      useFactory: async (configService: ConfigService) => {
        // TODO: IF redis is not configured us a local store instead
        const redisConfig = <RedisConfiguration>configService.get('redis');
        return {
          isGlobal: true,
          store: redisStore,
          ...redisConfig,
        };
      },
      inject: [ConfigService],
    }),
  ],
  exports: [NestCacheModule],
})
export class CacheModule {}
