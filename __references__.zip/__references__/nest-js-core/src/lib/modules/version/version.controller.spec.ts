import { ConfigService } from '@nestjs/config';
import { Test, TestingModule } from '@nestjs/testing';
import { VersionController } from './version.controller';
import { VersionService } from './version.service';

describe(VersionController.name, () => {
  let versionController: VersionController;
  let versionService: VersionService;

  beforeEach(async () => {
    const moduleRef: TestingModule = await Test.createTestingModule({
      controllers: [VersionController],
      providers: [
        VersionService,
        {
          provide: ConfigService,
          useValue: {},
        },
      ],
    }).compile();

    versionService = moduleRef.get<VersionService>(VersionService);
    versionController = moduleRef.get<VersionController>(VersionController);
  });

  describe('getVersion', () => {
    const result = [
      {
        type: 'result',
        value: 'my component, v3.4.5(probably a release date)',
      },
    ];

    it('should call the service to provide a version', () => {
      jest.spyOn(versionService, 'getVersion').mockImplementation(() => result);
      expect(versionController.getVersion()).toBe(result);
    });
  });
});
