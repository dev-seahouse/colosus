import { Injectable } from '@nestjs/common';
import { VersionDto } from './dto';
import { ConfigService } from '@nestjs/config';
import * as fs from 'fs';
import { ApplicationInfo } from '@bambu/js-core';

@Injectable()
export class VersionService {
  constructor(private configService: ConfigService) {}

  getVersion(): VersionDto[] {
    const appInfo = this.configService.get<ApplicationInfo>('appInfo');
    const stats = fs.statSync('.');
    const time = stats.mtime;
    return [
      {
        type: 'api',
        value: `${appInfo?.name} - API, v${
          appInfo?.version
        }(${time.toISOString()})`,
      },
    ];
  }
}
