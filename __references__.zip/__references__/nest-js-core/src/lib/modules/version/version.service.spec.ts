import { ConfigService } from '@nestjs/config';
import { Test } from '@nestjs/testing';
import { VersionDto } from './dto';
import { VersionController } from './version.controller';
import { VersionService } from './version.service';

describe(VersionService.name, () => {
  let versionService: VersionService;

  beforeEach(async () => {
    const moduleRef = await Test.createTestingModule({
      controllers: [VersionController],
      providers: [
        VersionService,
        {
          provide: ConfigService,
          useValue: {
            get: () => {
              return {
                name: 'a test app',
                version: '1.1.1',
              };
            },
          },
        },
      ],
    }).compile();

    versionService = moduleRef.get<VersionService>(VersionService);
  });

  describe('getVersion', () => {
    it('should retrieve a list of versioned components', () => {
      const version: VersionDto[] = versionService.getVersion();
      expect(version).toHaveLength(1);

      expect(version[0].type).toBe('api');
      expect(version[0].value).toMatch(/^a test app - API, v1.1.1\(.+\)$/);
    });
  });
});
