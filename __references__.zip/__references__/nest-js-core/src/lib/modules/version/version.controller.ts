import { Controller, Get, VERSION_NEUTRAL } from '@nestjs/common';
import { VersionService } from './version.service';
import { ApiTags } from '@nestjs/swagger';
import { VersionDto } from './dto';

@ApiTags('Version')
@Controller({
  path: 'version',
  version: VERSION_NEUTRAL,
})
export class VersionController {
  constructor(private readonly versionService: VersionService) {}

  /**
   * Gets the version of the components that are running in the api
   * @summary get the version of the api
   * @return a list of versions of the various components
   */
  @Get()
  getVersion(): VersionDto[] {
    return this.versionService.getVersion();
  }
}
