/* eslint-disable @typescript-eslint/no-this-alias */
import { Logger } from '@nestjs/common';
import { createClient } from 'redis';
import { RedisConfiguration } from './types';

export type RedisOptions = RedisConfiguration & {
  logger?: Logger;
};
type RedisSetOptions<T> = {
  ttl?: ((value: T) => number) | number;
};

export type RedisClient = RedisWrapper;

function getURL(redis: RedisConfiguration) {
  return `redis${redis.useTLS ? 's' : ''}://${redis.username ?? 'default'}:${
    redis.password ?? ''
  }@${redis.host}:${redis.port}/${redis.database ?? ''}`;
}

class RedisWrapper {
  private readonly _logger: Logger;
  private readonly _client: ReturnType<typeof createClient>;
  private readonly _storeArgs: Parameters<typeof createClient>[0];

  constructor(options?: RedisOptions) {
    const { logger, ...redisOptions } = options;
    this._logger = logger;
    if (!this._logger) {
      this._logger = new Logger(RedisWrapper.name);
    }

    const url = getURL(redisOptions);

    try {
      this._client = createClient({
        url: url,
        socket: {
          tls: redisOptions.useTLS,
          reconnectStrategy: (retries: number) => {
            this._logger.warn(
              `Failed to connect to redis ${url.replace(
                redisOptions.password,
                '**********'
              )}`
            );
            this._logger.log(`Reconnecting to redis, attempt # ${retries + 1}`);
            // TODO: Make this configurable in the options
            return Math.min(10000);
          },
        },
      });
    } catch (err) {
      this._logger.error(
        `Failed to connect to redis ${url.replace(
          redisOptions.password,
          '**********'
        )} ${err.message}`
      );
      throw err;
    }
    this._storeArgs = this._client.options;

    this._client.on('error', (err) => {
      this._logger.error(err);
    });
  }

  async connect() {
    if (!this._client.isOpen) {
      return this._client.connect();
    }
  }

  isCachableValue(value: any) {
    if ((this._storeArgs as any).isCacheableValue) {
      return (this._storeArgs as any).isCacheableValue(value);
    } else {
      return value !== undefined && value !== null;
    }
  }

  getClient() {
    return this._client;
  }

  handleResponse<T>(redisCall: Promise<string | string[] | number>, opts = {}) {
    return redisCall
      .then((result: string) => {
        // TODO: Check multi get/set
        return typeof result === 'string' &&
          (result.startsWith('{') || result.startsWith('['))
          ? (JSON.parse(result) as T)
          : (result as unknown as T);
      })
      .catch((err) => {
        throw err;
      });
  }

  reset<T>(
    key: string,
    value: T,
    options?: RedisSetOptions<T>
  ): Promise<string[]> | void {
    return;
  }

  keys(pattern: string): Promise<string[]> {
    return this.handleResponse<string[]>(this._client.keys(pattern));
  }

  set<T>(
    key: string,
    value: T,
    options?: RedisSetOptions<T>
  ): Promise<void> | void {
    const ttl =
      options.ttl || options.ttl === 0
        ? typeof options.ttl === 'function'
          ? options.ttl(value)
          : options.ttl
        : undefined;

    // Redis only accepts strings
    const cacheVal = JSON.stringify(value) || '"undefined"';
    if (ttl) {
      return this.handleResponse<void>(this._client.setEx(key, ttl, cacheVal));
    } else {
      return this.handleResponse<void>(this._client.set(key, cacheVal));
    }
  }

  get<T>(key: string): Promise<T | undefined> | T | undefined {
    return this.handleResponse<T>(this._client.get(key));
  }

  del?(key: string): void | Promise<void> {
    return this.handleResponse<void>(this._client.del(key));
  }

  ttl<T>(
    key: string,
    value: T,
    options?: RedisSetOptions<T>
  ): Promise<void> | void {
    return;
  }

  setex<T>(
    key: string,
    value: T,
    options?: RedisSetOptions<T>
  ): Promise<void> | void {
    return;
  }

  mset<T>(
    key: string,
    value: T,
    options?: RedisSetOptions<T>
  ): Promise<void> | void {
    return;
  }

  mget<T>(key: string): Promise<T | undefined> | T | undefined {
    return undefined;
  }
  exists(key: string) {
    return this._client.exists(key);
  }
  ping() {
    return this._client.ping();
  }
}

export const redisStore = {
  create: (args: RedisOptions) => {
    const redisStore = new RedisWrapper(args);
    redisStore.connect();
    return redisStore;
  },
};

//     mset: function(...args) {
//       const self = this;

//       return new Promise((resolve, reject) => {
//         let cb;
//         let options = {};

//         if (typeof args[args.length - 1] === 'function') {
//           cb = args.pop();
//         }

//         if (args[args.length - 1] instanceof Object && args[args.length - 1].constructor === Object) {
//           options = args.pop();
//         }

//         if (!cb) {
//           cb = (err, result) => (err ? reject(err) : resolve(result));
//         }

//         const ttl = (options.ttl || options.ttl === 0) ? options.ttl : storeArgs.ttl;

//         let multi;
//         if (ttl) {
//           multi = redisCache.multi();
//         }

//         let key;
//         let value;
//         const parsed = [];
//         for (let i = 0; i < args.length; i += 2) {
//           key = args[i];
//           value = args[i + 1];

//           /**
//            * Make sure the value is cacheable
//            */
//           if (!self.isCacheableValue(value)) {
//             return cb(new Error(`"${value}" is not a cacheable value`));
//           }

//           value = JSON.stringify(value) || '"undefined"';
//           parsed.push(...[key, value]);

//           if (ttl) {
//             multi.setex(key, ttl, value);
//           }
//         }

//         if (ttl) {
//           multi.exec(handleResponse(cb));
//         } else {
//           redisCache.mset.apply(redisCache, [...parsed, handleResponse(cb)]);
//         }
//       });
//     },
//     get: (key, options, cb) => (
//       new Promise((resolve, reject) => {
//         if (typeof options === 'function') {
//           cb = options;
//         }

//         if (!cb) {
//           cb = (err, result) => (err ? reject(err) : resolve(result));
//         }

//         redisCache.get(key, handleResponse(cb, { parse: true }));
//       })
//     ),
//     mget: (...args) => (
//       new Promise((resolve, reject) => {
//         let cb;
//         let options = {};

//         if (typeof args[args.length - 1] === 'function') {
//           cb = args.pop();
//         }

//         if (args[args.length - 1] instanceof Object && args[args.length - 1].constructor === Object) {
//           options = args.pop();
//         }

//         if (!cb) {
//           cb = (err, result) => (err ? reject(err) : resolve(result));
//         }

//         redisCache.mget.apply(redisCache, [...args, handleResponse(cb, { parse: true })]);
//       })
//     ),
//     del: (...args) => (
//       new Promise((resolve, reject) => {
//         let cb;
//         let options = {};

//         if (typeof args[args.length - 1] === 'function') {
//           cb = args.pop();
//         }

//         if (args[args.length - 1] instanceof Object && args[args.length - 1].constructor === Object) {
//           options = args.pop();
//         }

//         if (!cb) {
//           cb = (err, result) => (err ? reject(err) : resolve(result));
//         }

//         redisCache.del.apply(redisCache, [...args, handleResponse(cb)]);
//       })
//     ),
//     reset: cb => (
//       new Promise((resolve, reject) => {
//         if (!cb) {
//           cb = (err, result) => (err ? reject(err) : resolve(result));
//         }

//         redisCache.flushdb(handleResponse(cb));
//       })
//     ),
//     keys: (pattern = '*', cb) => (
//       new Promise((resolve, reject) => {
//         if (typeof pattern === 'function') {
//           cb = pattern;
//           pattern = '*';
//         }

//         if (!cb) {
//           cb = (err, result) => (err ? reject(err) : resolve(result));
//         }

//         redisCache.keys(pattern, handleResponse(cb));
//       })
//     ),
//     ttl: (key, cb) => (
//       new Promise((resolve, reject) => {
//         if (!cb) {
//           cb = (err, result) => (err ? reject(err) : resolve(result));
//         }

//         redisCache.ttl(key, handleResponse(cb));
//       })
//     ),
//     isCacheableValue: storeArgs.is_cacheable_value || (value => value !== undefined && value !== null),
//   };
// };
