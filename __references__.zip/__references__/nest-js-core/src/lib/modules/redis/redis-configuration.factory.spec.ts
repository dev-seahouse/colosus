describe('RedisConfiguration', () => {
  test.todo('test');
});
// import { getConfiguration } from '../redis.config';

// describe('Redis Configuration', () => {
//   const OLD_ENV = process.env;

//   beforeEach(() => {
//     jest.resetModules();
//     process.env = {
//       ...OLD_ENV,
//     };
//   });

//   afterAll(() => {
//     process.env = OLD_ENV;
//   });

//   describe('password', () => {
//     it('should extract password from REDIS_PASSWORD', () => {
//       process.env.REDIS_PASSWORD = 'mypassword';
//       expect(getConfiguration().password).toBe('mypassword');
//     });

//     it('should allow for no auth', () => {
//       process.env.REDIS_PASSWORD = undefined;
//       expect(getConfiguration().password).toBeUndefined();
//     });

//     it('should treat a blank password as no auth', () => {
//       process.env.REDIS_PASSWORD = '';
//       expect(getConfiguration().password).toBeUndefined();
//     });
//   });

//   describe('host', () => {
//     it('should extract host from REDIS_HOST', () => {
//       process.env.REDIS_HOST = 'localhost';
//       expect(getConfiguration().host).toBe('localhost');
//     });

//     it('should provide an empty string if not defined', () => {
//       process.env.REDIS_HOST = undefined;
//       expect(getConfiguration().host).toBe('');
//     });
//   });

//   describe('port', () => {
//     it('should extract port from REDIS_PORT', () => {
//       process.env.REDIS_PORT = '6789';
//       expect(getConfiguration().port).toBe(6789);
//     });

//     it('should default to 6379 if not defined', () => {
//       process.env.REDIS_HOST = undefined;
//       expect(getConfiguration().port).toBe(6379);
//     });

//     it('should default to 6379 if not a number', () => {
//       process.env.REDIS_HOST = 'not a port';
//       expect(getConfiguration().port).toBe(6379);
//     });
//   });

//   describe('tls', () => {
//     it('should extract tls from REDIS_TLS', () => {
//       process.env.REDIS_TLS = 'false';
//       expect(getConfiguration().useTLS).toBe(false);
//     });

//     it('should default to true if not defined', () => {
//       process.env.REDIS_TLS = undefined;
//       expect(getConfiguration().useTLS).toBe(true);
//     });

//     it('should default to true if not a boolean value', () => {
//       process.env.REDIS_TLS = 'not a boolean';
//       expect(getConfiguration().useTLS).toBe(true);
//     });
//   });
// });
