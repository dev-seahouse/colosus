import { Logger, Module } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import { redisStore } from './redis-cache-wrapper';
import { RedisService } from './redis.service';
import { RedisConfiguration } from './types';

@Module({
  providers: [
    {
      provide: RedisService,
      useFactory: async (configService: ConfigService) => {
        const logger = new Logger(RedisModule.name);
        const redis = <RedisConfiguration>(
          configService.get<RedisConfiguration>('redis')
        );

        const client = redisStore.create({
          ...redis,
        });
        client.connect();

        logger.log(`Redis connecting to ${redis.host}:${redis.port}`);
        return new RedisService(client);
      },
      inject: [ConfigService],
    },
  ],
  exports: [RedisService],
})
export class RedisModule {}
