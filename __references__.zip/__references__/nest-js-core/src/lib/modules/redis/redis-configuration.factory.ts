import { DeepPartial } from '@bambu/js-core';
import { CacheModule, Logger } from '@nestjs/common';
import { ConfigurationFactory } from '../../config';
import { RedisConfiguration } from './types';
import { _ } from '@bambu/js-core';
import { NestModuleConfig } from '../types';
import { RedisModule } from './redis.module';
import { RedisHealthIndicator } from './health/redis.health';
import { ConfigModule, ConfigService } from '@nestjs/config';
import { RedisOptions, redisStore } from './redis-cache-wrapper';

export class RedisConfigurationFactory extends ConfigurationFactory<
  RedisConfiguration,
  'redis'
> {
  constructor(
    config?: Record<'redis', DeepPartial<RedisConfiguration>>,
    logger?: Logger
  ) {
    super('redis', [], config, logger);
  }

  initialiseConfiguration(
    config: DeepPartial<
      Record<'redis', RedisConfiguration> & Record<string, any>
    >
  ): DeepPartial<Record<'redis', RedisConfiguration> & Record<string, any>> {
    config = _.cloneDeep(config);
    const base: DeepPartial<RedisConfiguration> = config.redis || {};
    config.redis = {
      password:
        base.password ||
        (process.env.REDIS_PASSWORD && process.env.REDIS_PASSWORD.length > 0)
          ? process.env.REDIS_PASSWORD
          : undefined,
      host: base.host || process.env.REDIS_HOST || '',
      port: base.port || parseInt(process.env.REDIS_PORT || '6379', 10) || 6379,
      username: base.username || process.env.REDIS_USER || 'default',
      database: base.database || process.env.REDIS_DATABASE,
      useTLS: base.useTLS || process.env.REDIS_TLS !== 'false',
    };
    return config;
  }

  getConfiguration(
    current?: DeepPartial<
      Record<'redis', RedisConfiguration> & Record<string, any>
    >
  ): Record<'redis', RedisConfiguration> & Record<string, any> {
    current = super.getConfiguration(current);
    // Make any updates to the configuration here
    return current as Record<'redis', RedisConfiguration> & Record<string, any>;
  }

  getModuleMetadata(): NestModuleConfig[] {
    const metadata = super.getModuleMetadata();

    return [
      ...metadata,
      {
        name: this.constructor.name,
        imports: [
          CacheModule.registerAsync<RedisOptions>({
            imports: [ConfigModule],
            useFactory: async (configService: ConfigService) => {
              const redis = configService.get<RedisConfiguration>('redis');

              return {
                isGlobal: true,
                logger: this.logger,
                store: redisStore,
                ...redis,
              };
            },
            inject: [ConfigService],
          }),
        ],
        healthIndicators: [
          {
            imports: [RedisModule],
            providers: [RedisHealthIndicator],
          },
        ],
      },
    ];
  }
}
