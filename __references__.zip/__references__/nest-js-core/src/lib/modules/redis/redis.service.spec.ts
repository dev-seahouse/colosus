describe('RedisService', () => {
  test.todo('test');
});
// import { ConfigService } from '@nestjs/config';
// import { Test, TestingModule } from '@nestjs/testing';
// import { ConfigServiceMock } from 'src/config/__mocks__/config.service';
// import { RedisService } from '../redis.service';
// import * as redis from 'redis-mock';
// import { CACHE_MANAGER } from '@nestjs/common';

// const cacheManagerMock = {
//   get: jest.fn(),
//   set: jest.fn(),
//   det: jest.fn(),
//   reset: jest.fn(),
// };

// describe(RedisService.name, () => {
//   let redisService: RedisService;
//   let redisClientMock: redis.RedisClientType;

//   beforeEach(async () => {
//     const redisMock: redis.RedisClientType = redis.createClient();
//     redisMock.get = jest.fn();
//     redisMock.set = jest.fn();
//     redisMock.del = jest.fn();
//     redisMock.ping = jest.fn();

//     const moduleRef: TestingModule = await Test.createTestingModule({
//       exports: [RedisService],
//       providers: [
//         {
//           provide: ConfigService,
//           useValue: ConfigServiceMock,
//         },
//         {
//           provide: CACHE_MANAGER,
//           useValue: cacheManagerMock,
//         },
//         {
//           provide: RedisService,
//           useFactory: async () => {
//             return new RedisService(redisMock);
//           },
//         },
//       ],
//     }).compile();

//     redisService = moduleRef.get<RedisService>(RedisService);
//     redisClientMock = redisMock;
//   });

//   it('should be defined', () => {
//     expect(redisService).toBeDefined();
//   });

//   describe('create', () => {
//     it('should call the redis client with the appropriate key and value', async () => {
//       const data = {
//         value: 'to test',
//       };
//       redisService.set('test', data);
//       expect(redisClientMock.set).toBeCalledWith('test', data);
//     });
//   });

//   // describe('retrieve', ()=>{
//   //     it('should call the redis client with the appropriate key', async ()=>{
//   //         redisService.get('test');
//   //         expect(redisClientMock.get).toBeCalledWith('test');
//   //     });
//   // });

//   // describe('delete', ()=>{
//   //     it('should call the redis client with the appropriate key', async ()=>{
//   //         redisService.del('test');
//   //         expect(redisClientMock.del).toBeCalledWith('test');
//   //     });
//   // });

//   // describe('ping', ()=>{
//   //     it('should call the ping method', async ()=>{
//   //         const result : {
//   //             ms : number
//   //         } = await redisService.pingDb();
//   //         expect(redisClientMock.ping).toBeCalledTimes(1);
//   //         expect(result.ms).toBeGreaterThanOrEqual(0);
//   //     });
//   // });
// });
