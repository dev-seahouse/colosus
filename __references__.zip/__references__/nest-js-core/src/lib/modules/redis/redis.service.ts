import { Injectable } from '@nestjs/common';
import { RedisClient } from './redis-cache-wrapper';

@Injectable()
export class RedisService {
  constructor(private readonly client: RedisClient) {}

  get(key: string) {
    return this.client.get(key);
  }

  set(key: string, value: any) {
    return this.client.set(key, value);
  }

  exists(key: string) {
    return this.client.exists(key);
  }

  del(key: string) {
    return this.client.del(key);
  }

  async pingDb() {
    const now = Date.now();
    await this.client.ping();
    return {
      ms: Date.now() - now,
    };
  }
}
