import { Global, Injectable, Logger, Module } from '@nestjs/common';
import { ConfigModule, ConfigService } from '@nestjs/config';
import { PrismaClientFactory } from './prisma.service';
import { PrismaConfiguration, PRISMA_TOKEN } from './types';

@Global()
@Module({
  imports: [ConfigModule],
  providers: [
    {
      provide: PRISMA_TOKEN,
      useFactory: (configService: ConfigService) => {
        const logger = new Logger(PrismaModule.name);
        const prismaConfig = configService.get<PrismaConfiguration>('prisma');

        @Injectable()
        class PrismaServiceClass extends PrismaClientFactory(
          prismaConfig.prismaClient
        ) {
          constructor(config: ConfigService) {
            super(config);
          }
        }

        logger.log(
          `Prisma connecting to ${prismaConfig.host}:${prismaConfig.port}/${prismaConfig.database}`
        );
        return new PrismaServiceClass(configService);
      },
      inject: [ConfigService],
    },
  ],
  exports: [PRISMA_TOKEN],
})
export class PrismaModule {}
