import { ConfigService } from '@nestjs/config';
import { PrismaConfiguration } from './types';

type PrismaConstructor<T = any> = {
  new (...args: any[]): {
    [P in keyof T]: T[P];
  };
};

export type PrismaService<T = any> = typeof PrismaClientFactory & {
  pingDb(): Promise<{ ms: number }>;
  cleanDb(): void;
  getModels(): (string | symbol)[];
} & {
  [P in keyof T]: T[P];
};

export function PrismaClientFactory<T extends PrismaConstructor>(
  prismaClient: T
) {
  return class PrismaServiceClass extends prismaClient {
    constructor(...args: any) {
      const config = args[0] as ConfigService;
      const dbConfig: PrismaConfiguration | undefined =
        config.get<PrismaConfiguration>('prisma');
      if (!dbConfig) {
        throw new Error("Invalid DB configuration, expecting key 'prisma'");
      }
      super({
        log: dbConfig.log,
        datasources: {
          db: {
            url: dbConfig.connectionString,
          },
        },
      });
    }

    async pingDb(): Promise<{ ms: number }> {
      const now = Date.now();
      await this.$queryRaw`SELECT 1;`;
      return {
        ms: Date.now() - now,
      };
    }

    async cleanDb() {
      if (process.env.NODE_ENV === 'production') {
        return;
      }

      const models = this.getModels();
      return Promise.all(models.map((key) => this[key as string].deleteMany()));
    }

    getModels() {
      return Reflect.ownKeys(this).filter((key) => key[0] !== '_');
    }
  };
}
