// modified from https://github.com/prisma/prisma/issues/5055
import { Readable } from 'stream';
import { PrismaDelegate } from './types/prisma-delegate.type';

interface ReportOptions<PrismaType, Delegate, FindManyArgs> {
  delegate: Delegate;
  params: FindManyArgs;
  batchSize?: number;
  idField?: keyof PrismaType;
}

export function prismaStream<
  Delegate extends PrismaDelegate<PrismaType>,
  PrismaType,
  FindManyArgs
>({
  batchSize = 100,
  delegate,
  params,
  idField = <any>'guid',
}: ReportOptions<PrismaType, Delegate, FindManyArgs>): Readable {
  let cursorID: number;
  return new Readable({
    objectMode: true,
    highWaterMark: batchSize,
    async read() {
      try {
        const results = await delegate.findMany({
          ...params,
          take: batchSize,
          skip: cursorID ? 1 : 0,
          cursor: cursorID
            ? {
                [idField]: cursorID,
              }
            : undefined,
        });
        for (const result of results) {
          this.push(result);
        }
        if (results.length < batchSize) {
          this.push(null);
          return;
        }
        cursorID = (<any>results[results.length - 1])[idField];
      } catch (err: any) {
        this.destroy(err);
      }
    },
  });
}
