import { Prisma } from '@bambu-prisma/nest/core/prismaClient';
import { DeepPartial, _ } from '@bambu/js-core';
import { Logger } from '@nestjs/common';
import { APP_FILTER } from '@nestjs/core';
import { ConfigurationFactory } from '../../config';
import { NestModuleConfig } from '../types';
import { PrismaClientExceptionFilter } from './filters/prisma-client-exception.filter';
import { PrismaHealthIndicator } from './health/prisma.health';
import { PrismaModule } from './prisma.module';
import { PrismaConfiguration } from './types/prisma-configuration.type';

export class PrismaConfigurationFactory extends ConfigurationFactory<
  PrismaConfiguration,
  'prisma'
> {
  constructor(
    config?: Record<'prisma', DeepPartial<PrismaConfiguration>>,
    logger?: Logger
  ) {
    super('prisma', [], config, logger);
  }

  initialiseConfiguration(
    config: DeepPartial<
      Record<'prisma', PrismaConfiguration> & Record<string, any>
    >
  ): DeepPartial<Record<'prisma', PrismaConfiguration> & Record<string, any>> {
    config = _.cloneDeep(config);
    const base: DeepPartial<PrismaConfiguration> = config.prisma || {};
    config.prisma = {
      schema:
        base.schema ||
        (process.env.DB_SCHEMA as PrismaConfiguration['schema']) ||
        'postgresql',
      user: base.user || process.env.DB_USERNAME || 'user',
      password: base.password || process.env.DB_PASSWORD || 'password',
      host: base.host || process.env.DB_HOST || 'localhost',
      port: base.port || parseInt(process.env.DB_PORT || '5343', 10) || 5343,
      database: base.database || process.env.DB_NAME || 'datastore',
      prismaClient: base.prismaClient,
      log:
        base.log ||
        (process.env.DB_LOGLEVEL &&
          <Prisma.LogLevel[]>process.env.DB_LOGLEVEL.split(',')) ||
        undefined,
    };
    config.prisma.connectionString =
      config.prisma.connectionString ||
      process.env.DB_CONNECTION_STRING ||
      `${config.prisma.schema}://${config.prisma.user}:${config.prisma.password}@${config.prisma.host}:${config.prisma.port}/${config.prisma.database}`;

    if (!config.prisma.prismaClient) {
      throw new Error(
        'It looks like you forgot to configure the prisma client for your client connection'
      );
    }
    return config;
  }

  getConfiguration(
    current?: DeepPartial<
      Record<'prisma', PrismaConfiguration> & Record<string, any>
    >
  ): Record<'prisma', PrismaConfiguration> & Record<string, any> {
    current = super.getConfiguration(current);
    // Make any updates to the configuration here
    return current as Record<'prisma', PrismaConfiguration> &
      Record<string, any>;
  }

  getModuleMetadata(): NestModuleConfig[] {
    const metadata = super.getModuleMetadata();

    return [
      ...metadata,
      {
        name: this.constructor.name,
        imports: [PrismaModule],
        healthIndicators: [
          {
            imports: [PrismaModule],
            providers: [PrismaHealthIndicator],
          },
        ],
        providers: [
          {
            provide: APP_FILTER,
            useClass: PrismaClientExceptionFilter,
          },
        ],
      },
    ];
  }
}
