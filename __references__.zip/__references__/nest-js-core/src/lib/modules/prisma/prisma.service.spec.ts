describe('PrismaService', () => {
  test.todo('test');
});
// import { PrismaClient } from '@bambu-prisma/nest/core/prismaClient';
// import { Injectable } from '@nestjs/common';
// import { ConfigService } from '@nestjs/config';
// import { Test, TestingModule } from '@nestjs/testing';
// import { PrismaConfigurationFactory } from './prisma-configuration.factory';
// import { PrismaClientFactory } from './prisma.service';
// import { PrismaConfiguration } from './types';

// describe('PrismaClientFactory', () => {
//   let prismaService;

//   beforeEach(async () => {
//     const configServiceMock: {
//       get: () => PrismaConfiguration;
//     } = {
//       get: () => {
//         return PrismaConfigurationFactory({
//           database: 'test',
//           host: 'test',
//           password: 'test',
//           port: 4321,
//           prismaClient: PrismaClient,
//           schema: 'mysql',
//           user: 'test',
//           log: ['query'],
//         }) as PrismaConfiguration;
//       },
//     };

//     const moduleRef: TestingModule = await Test.createTestingModule({
//       exports: [PRISMA_TOKEN],
//       providers: [
//         {
//           provide: PRISMA_TOKEN,
//           useFactory: (configService: ConfigService) => {
//             const prismaConfig = configService.get<PrismaConfiguration>('prisma');

//             @Injectable()
//             class PrismaServiceClass extends PrismaClientFactory(prismaConfig.prismaClient) {
//               constructor(config: ConfigService) {
//                 super(config);
//               }
//             }
//             return new PrismaServiceClass(configService);
//           },
//           inject: [ConfigService],
//         },
//         {
//           provide: ConfigService,
//           useValue: configServiceMock,
//         },
//       ],
//     }).compile();

//     prismaService = moduleRef.get(PRISMA_TOKEN);
//   });

//   it('should be defined', () => {
//     expect(prismaService).toBeDefined();
//   });

//   describe('ping', () => {
//     it('should ping the database with a basic query', async () => {
//       jest.spyOn(prismaService, '$queryRaw').mockImplementation();

//       const response = await prismaService.pingDb();
//       expect(prismaService.$queryRaw).toBeCalledWith(['SELECT 1;']);

//       expect(response.ms).toBeLessThan(100);
//     });
//   });

//   describe('cleanDb Production', () => {
//     const OLD_ENV = process.env;

//     beforeEach(() => {
//       jest.resetModules();
//       process.env = {
//         ...OLD_ENV,
//       };
//     });

//     afterAll(() => {
//       process.env = OLD_ENV;
//     });

//     it('should do nothing', async () => {
//       process.env.NODE_ENV = 'production';

//       const models = prismaService.getModels();

//       models.forEach((m) => {
//         jest.spyOn(prismaService[m], 'deleteMany').mockImplementation();
//       });

//       await prismaService.cleanDb();

//       models.forEach((m) => {
//         expect(prismaService[m].deleteMany).not.toBeCalled();
//       });
//     });
//   });

//   describe('cleanDb Development', () => {
//     it('should delete the data from every registered model', async () => {
//       const models = prismaService.getModels();

//       models.forEach((m) => {
//         jest.spyOn(prismaService[m], 'deleteMany').mockImplementation();
//       });

//       await prismaService.cleanDb();

//       models.forEach((m) => {
//         expect(prismaService[m].deleteMany).toBeCalledTimes(1);
//       });
//     });
//   });

//   describe('getModels', () => {
//     it('should retrieve the list of models available on the client', async () => {
//       const models = prismaService.getModels();

//       expect(models).toStrictEqual(['fake']);
//     });
//   });
// });
