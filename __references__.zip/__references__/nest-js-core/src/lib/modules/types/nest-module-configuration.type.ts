import { ModuleBase } from '@bambu/js-core';
import { ModuleMetadata } from '@nestjs/common';

export type NestModuleConfig = ModuleBase &
  ModuleMetadata & {
    healthIndicators?: {
      imports: ModuleMetadata['imports'];
      providers: ModuleMetadata['providers'];
    }[];
  };
