import { DynamicModule, Module, ModuleMetadata } from '@nestjs/common';
import { ConfigModule } from '@nestjs/config';
import { ConfigurationFactory } from '../../config';
import { HealthModule } from '../health';
import { NestModuleConfig } from '../types';
import { VersionModule } from '../version';

@Module({})
export class AppModule {
  static forRoot<T extends ConfigurationFactory<any, any, any>>(
    metadata: ModuleMetadata,
    configFactory: T
  ): DynamicModule {
    const dynamicModules = configFactory.getModuleMetadata();

    const resolvedModules = dynamicModules.reduce(
      (acc: NestModuleConfig, module: NestModuleConfig) => {
        acc.imports.push(...(module.imports || []));
        acc.providers.push(...(module.providers || []));
        acc.controllers.push(...(module.controllers || []));
        acc.healthIndicators.push(...(module.healthIndicators || []));
        acc.exports.push(...(module.exports || []));
        return acc;
      },
      {
        name: this.constructor.name,
        imports: [],
        providers: [],
        controllers: [],
        exports: [],
        healthIndicators: [],
      }
    );

    return {
      module: AppModule,
      imports: [
        ConfigModule.forRoot({
          isGlobal: true,
          load: [
            () => ({
              ...configFactory.getConfiguration(),
              configFactory: configFactory,
            }),
          ],
          validationSchema: configFactory.getValidationSchema(),
        }),
        HealthModule.forRoot(resolvedModules.healthIndicators),
        ...resolvedModules.imports,
        // ...moduleMetadata.imports,
        //   AuthModule,
        //   PrismaModule,
        ...(metadata.imports || []),
        VersionModule,
      ],
      controllers: [
        ...resolvedModules.controllers,
        ...(metadata.controllers || []),
      ],
      providers: [...resolvedModules.providers, ...(metadata.providers || [])],
      exports: [...resolvedModules.exports, ...(metadata.exports || [])],
    };
  }
}
