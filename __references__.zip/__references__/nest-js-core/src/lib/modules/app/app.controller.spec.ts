import { AppController } from './app.controller';

describe(AppController.name, () => {
  it('should exist', () => {
    expect(new AppController()).toBeDefined();
  });
});
