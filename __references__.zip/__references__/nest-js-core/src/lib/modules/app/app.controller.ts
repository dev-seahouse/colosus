import { Controller, UseInterceptors } from '@nestjs/common';
import { LoggingInterceptor } from '../../interceptors';

@UseInterceptors(LoggingInterceptor)
@Controller()
export class AppController {}
