import { Injectable, NotFoundException } from '@nestjs/common';
import { validationMetadatasToSchemas } from 'class-validator-jsonschema';
import { SchemaObject } from 'openapi3-ts';

type Models = ReturnType<typeof validationMetadatasToSchemas>;

let localModelCache: Models = null;

@Injectable()
export class ModelsService {
  getModels() {
    if (!localModelCache) {
      localModelCache = validationMetadatasToSchemas();
    }
    return localModelCache;
  }

  findAll(): Models {
    return this.getModels();
  }

  findOne(id: string): SchemaObject {
    const retval: SchemaObject = this.getModels()[id];
    if (retval) {
      return retval;
    } else {
      throw new NotFoundException();
    }
  }
}
