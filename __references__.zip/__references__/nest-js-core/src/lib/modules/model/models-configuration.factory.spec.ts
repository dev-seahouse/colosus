import { ModelsConfigurationFactory as sut } from './models-configuration.factory';

describe('ModelsConfigurationFactory', () => {
  describe('Defaults', () => {
    const OLD_ENV = process.env;

    beforeEach(() => {
      jest.resetModules();
      process.env = {
        ...OLD_ENV,
      };
    });

    afterAll(() => {
      process.env = OLD_ENV;
    });

    it('should provide appropriate defaults', () => {
      process.env.MODEL_ENDPOINT_PATH = undefined;

      const conf = new sut({
        model: {},
      }).getConfiguration().model;

      expect(conf.path).toBe('model');
    });

    it('should pick up environment variables', () => {
      process.env.MODEL_ENDPOINT_PATH = 'a model path';

      const conf = new sut({
        model: {},
      }).getConfiguration().model;

      expect(conf.path).toBe('a model path');
    });

    it('should expand partial configuration', () => {
      process.env.MODEL_ENDPOINT_PATH = undefined;

      const conf = new sut({
        model: {
          path: 'modelsPath',
        },
      }).getConfiguration().model;

      expect(conf.path).toBe('modelsPath');
    });

    it('should override environment variables', () => {
      process.env.MODEL_ENDPOINT_PATH = 'a model path';

      const conf = new sut({
        model: {
          path: 'modelsPath',
        },
      }).getConfiguration().model;

      expect(conf.path).toBe('modelsPath');
    });
  });
});
