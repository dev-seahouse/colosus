import { Controller, Get, Param } from '@nestjs/common';
import { ApiOperation, ApiResponse, ApiTags } from '@nestjs/swagger';
import { HTTPError } from '../../dto';
import { ModelsService } from './models.service';

@ApiTags('Models')
@Controller({})
export class ModelsController {
  constructor(private modelService: ModelsService) {}

  @ApiResponse({ status: 200, description: 'Ok' })
  @ApiResponse({ status: 401, description: 'Unauthorized.', type: HTTPError })
  @ApiOperation({
    summary: 'Retrieve all available data transfer definitions',
    description: `Retrieve all DTOs that are being used by the application.  Response is in JSONSchema format`,
  })
  @Get()
  findAll() {
    return this.modelService.findAll();
  }

  @ApiResponse({
    status: 200,
    description: 'Model retrieved successfully.',
  })
  @ApiResponse({ status: 401, description: 'Unauthorized.', type: HTTPError })
  @ApiResponse({
    status: 404,
    description: 'Model does not exist',
    type: HTTPError,
  })
  @ApiOperation({
    summary: 'Retrieve a single data transfer object',
    description: `Gets a specific DTO`,
  })
  @Get(':id')
  findOne(@Param('id') id: string) {
    return this.modelService.findOne(id);
  }
}
