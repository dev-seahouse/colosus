import { DeepPartial } from '@bambu/js-core';
import { Logger } from '@nestjs/common';
import { ConfigurationFactory } from '../../config';
import { NestModuleConfig } from '../types';
import { ModelsModule } from './models.module';
import { ModelConfiguration } from './types';

export class ModelsConfigurationFactory extends ConfigurationFactory<
  ModelConfiguration,
  'model'
> {
  constructor(
    config?: DeepPartial<Record<'model', ModelConfiguration>>,
    logger?: Logger
  ) {
    super('model', [], config, logger);
  }

  initialiseConfiguration(
    config: DeepPartial<
      Record<'model', ModelConfiguration> & Record<string, any>
    >
  ): DeepPartial<Record<'model', ModelConfiguration> & Record<string, any>> {
    const base = config.model;
    config.model = {
      path: base.path || process.env.MODEL_ENDPOINT_PATH || 'model',
    };
    return config;
  }

  getModuleMetadata(): NestModuleConfig[] {
    const metadata = super.getModuleMetadata();
    return [
      ...metadata,
      {
        name: this.constructor.name,
        imports: [ModelsModule],
      },
    ];
  }
}
