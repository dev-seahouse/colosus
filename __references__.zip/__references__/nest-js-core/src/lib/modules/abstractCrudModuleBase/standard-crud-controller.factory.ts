import { DTOPagedData, UpdateableT } from '@bambu/js-core';
import {
  Body,
  Delete,
  Get,
  NotFoundException,
  Param,
  Patch,
  Post,
  Put,
  Query,
  Type,
  UsePipes,
} from '@nestjs/common';
import {
  ApiBody,
  ApiOperation,
  ApiQuery,
  ApiResponse,
  getSchemaPath,
} from '@nestjs/swagger';
import { map, Observable } from 'rxjs';
import { HTTPError } from '../../dto';
import { AbstractValidationPipe } from '../../pipes/abstract-validation.pipe';
import { ICrudController, ICrudService, PageQueryParamsDto } from './types';

export const VALIDATION_PIPE_CONFIG = {
  whitelist: true,
  transform: true,
  transformOptions: {
    enableImplicitConversion: true,
  },
  validateCustomDecorators: true,
};

type DTOMapType<T> = {
  dtoType: Type<T>;
  createDtoType?: Type<any>;
  queryDtoType?: Type<any>;
  updateDtoType?: Type<any>;
};

function isDTOMapType<T>(
  param: Type<T> | DTOMapType<T>
): param is DTOMapType<T> {
  return (param as DTOMapType<T>).dtoType !== undefined;
}

export function StandardCrudControllerFactory<
  DtoType,
  CreateDtoType,
  UpdateDtoType extends UpdateableT,
  QueryDtoType,
  ServiceType extends ICrudService<
    DtoType,
    CreateDtoType,
    UpdateDtoType,
    QueryDtoType
  > = ICrudService<DtoType, CreateDtoType, UpdateDtoType, QueryDtoType>
>(
  dtos:
    | Type<DtoType>
    | {
        dtoType: Type<DtoType>;
        createDtoType?: Type<CreateDtoType>;
        queryDtoType?: Type<QueryDtoType>;
        updateDtoType?: Type<UpdateDtoType>;
      }
) {
  let dtoType;
  let createDto;
  let queryDto;
  let updateDto;

  if (isDTOMapType<DtoType>(dtos)) {
    dtoType = dtos.dtoType;
    createDto = dtos.createDtoType;
    queryDto = dtos.queryDtoType;
    updateDto = dtos.updateDtoType;
  } else {
    dtoType = dtos;
  }
  createDto = createDto || dtoType;
  queryDto = queryDto || dtoType;
  updateDto = updateDto || dtoType;

  const createPipe = new AbstractValidationPipe(VALIDATION_PIPE_CONFIG, {
    body: createDto,
  });
  const updatePipe = new AbstractValidationPipe(VALIDATION_PIPE_CONFIG, {
    body: updateDto,
  });
  const queryPipe = new AbstractValidationPipe(VALIDATION_PIPE_CONFIG, {
    query: queryDto,
  });

  class CrudController
    implements
      ICrudController<
        DtoType,
        CreateDtoType,
        UpdateDtoType,
        QueryDtoType,
        ServiceType
      >
  {
    constructor(readonly service: ServiceType) {
      if (!service) {
        // It is possible that a null was injected
        throw new Error(
          `A service was not provided for ${this.constructor.name}`
        );
      }
    }

    @ApiResponse({ status: 200, description: 'Ok', type: [dtoType] })
    @ApiResponse({ status: 401, description: 'Unauthorized.', type: HTTPError })
    @ApiQuery({ type: queryDto })
    @UsePipes(queryPipe)
    @ApiOperation({
      summary: 'Retrieve a list of records',
      description: `Retrieve all records of type ${dtoType.name.replace(
        'Dto',
        ''
      )}`,
    })
    @Get()
    findAll(@Query() filterArgs?: QueryDtoType): Observable<DtoType[]> {
      return this.service.findAll(filterArgs);
    }

    @ApiBody({
      type: createDto,
    })
    @ApiResponse({
      status: 201,
      description: 'The record has been successfully created.',
      type: dtoType,
    })
    @ApiResponse({ status: 400, description: 'Bad Request.', type: HTTPError })
    @ApiResponse({ status: 401, description: 'Unauthorized.', type: HTTPError })
    @ApiResponse({ status: 403, description: 'Forbidden.', type: HTTPError })
    @ApiOperation({
      summary: 'Create a new record',
      description: `Creates a new ${dtoType.name.replace('Dto', '')}`,
    })
    @Post()
    @UsePipes(createPipe)
    create(@Body() createDto: CreateDtoType): Observable<DtoType> {
      return this.service.create(createDto);
    }

    @ApiResponse({
      status: 200,
      description: 'Ok',
      schema: {
        title: dtoType.name,
        properties: {
          data: {
            items: {
              $ref: getSchemaPath(dtoType),
            },
          },
          totalCount: {
            type: 'number',
          },
          pageInfo: {
            properties: {
              hasNextPage: {
                type: 'boolean',
              },
              hasPreviousPage: {
                type: 'boolean',
              },
              nextPage: {
                type: 'string',
              },
              previousPage: {
                type: 'boolean',
              },
            },
          },
        },
      },
    })
    @ApiResponse({ status: 401, description: 'Unauthorized.', type: HTTPError })
    @ApiOperation({
      summary: 'Retrieve a paginated list of records',
      description: `Gets a page of type ${dtoType.name.replace('Dto', '')}`,
    })
    @Get('page')
    async findPage(
      @Query() paginationArgs: PageQueryParamsDto<QueryDtoType>
    ): Promise<DTOPagedData<DtoType>> {
      return this.service.findPage(paginationArgs);
    }

    @Get(':id')
    @ApiResponse({
      status: 200,
      description: 'Entity retrieved successfully.',
      type: dtoType,
    })
    @ApiResponse({ status: 401, description: 'Unauthorized.', type: HTTPError })
    @ApiResponse({
      status: 404,
      description: 'Entity does not exist',
      type: HTTPError,
    })
    @ApiOperation({
      summary: 'Retrieve a single record',
      description: `Gets a specific ${dtoType.name.replace('Dto', '')}`,
    })
    findOne(@Param('id') id: string): Observable<DtoType> {
      return this.service.findOne(id).pipe(
        map((result) => {
          if (result === null || result === undefined) {
            throw new NotFoundException(`An entity does not exist for ${id}`);
          }
          return result;
        })
      );
    }

    @ApiResponse({
      status: 200,
      description: 'Entity updated successfully.',
      type: dtoType,
    })
    @ApiResponse({ status: 400, description: 'Bad Request.', type: HTTPError })
    @ApiResponse({ status: 401, description: 'Unauthorized.', type: HTTPError })
    @ApiBody({
      type: updateDto,
    })
    @ApiOperation({
      summary: 'Replace a record',
      description: `Replace all properties of a ${dtoType.name.replace(
        'Dto',
        ''
      )}`,
    })
    @Put(':id')
    @UsePipes(updatePipe)
    update(
      @Param('id') id: string,
      @Body() updateDto: UpdateDtoType
    ): Observable<DtoType> {
      return this.service.update(id, updateDto);
    }

    @ApiResponse({
      status: 200,
      description: 'Entity updated successfully.',
      type: dtoType,
    })
    @ApiResponse({ status: 400, description: 'Bad Request.', type: HTTPError })
    @ApiResponse({ status: 401, description: 'Unauthorized.', type: HTTPError })
    @ApiBody({
      type: updateDto,
    })
    @ApiOperation({
      summary: 'Update properties on a record',
      description: `Updates properties on a ${dtoType.name.replace('Dto', '')}`,
    })
    @Patch(':id')
    @UsePipes(updatePipe)
    patch(
      @Param('id') id: string,
      @Body() updateDto: UpdateDtoType
    ): Observable<DtoType> {
      // // TODO: Implement patch properly
      return this.service.update(id, updateDto);
    }

    @ApiResponse({
      status: 200,
      description: 'Entity deleted successfully.',
      type: dtoType,
    })
    @ApiResponse({ status: 400, description: 'Bad Request.', type: HTTPError })
    @ApiResponse({ status: 401, description: 'Unauthorized.', type: HTTPError })
    @ApiOperation({
      summary: 'Delete a record',
      description: `Deletes a ${dtoType.name.replace('Dto', '')}`,
    })
    @Delete(':id')
    remove(@Param('id') id: string): Observable<DtoType> {
      return this.service.remove(id);
    }
  }

  return class SuperController extends CrudController {
    constructor(service: ServiceType) {
      super(service);
    }
  };
}
