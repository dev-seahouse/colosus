import {
  Connection,
  findManyCursorConnection,
} from '@devoxa/prisma-relay-cursor-connection';
import { DTOPagedData, UpdateableT } from '@bambu/js-core';
import { ConflictException, HttpException, Logger } from '@nestjs/common';
import { STATUS_CODES } from 'http';
import {
  concatMap,
  defaultIfEmpty,
  filter,
  firstValueFrom,
  from,
  isObservable,
  Observable,
  of,
  switchMap,
  toArray,
} from 'rxjs';
import { PrismaService } from '../prisma/prisma.service';
import { PrismaDataStoreType } from '../prisma/types/prisma-data-store-type.type';
import { PrismaDelegate } from '../prisma/types/prisma-delegate.type';
import { ICrudService, PageQueryParamsDto } from './types';

export abstract class StandardCrudService<
  DtoType,
  CreateDtoType,
  UpdateDtoType extends UpdateableT,
  QueryDtoType,
  DataStoreType extends PrismaDataStoreType,
  PrismaServiceType extends PrismaService = PrismaService
> implements ICrudService<DtoType, CreateDtoType, UpdateDtoType, QueryDtoType>
{
  private logger: Logger;
  protected datastoreDelegate: PrismaDelegate<DataStoreType>;
  constructor(
    protected datastore: PrismaServiceType,
    // TODO: Remove any type from datastoreDelegate
    datastoreDelegate: PrismaDelegate<DataStoreType> | any
  ) {
    this.logger = new Logger(this.constructor.name);
    this.datastoreDelegate = datastoreDelegate;
  }

  isUpdateDtoType(data: CreateDtoType | UpdateDtoType): data is UpdateDtoType {
    return Boolean((data as UpdateDtoType).objectVersion);
  }

  dtoToStore(dto: CreateDtoType): DataStoreType;
  dtoToStore(dto: UpdateDtoType): Partial<DataStoreType>;
  /**
   * Transforms a DTO to a format compatible with the data storage mechanism
   * @param dto The dto to transform
   * @returns the data store type derived from the DTO
   */
  dtoToStore(
    dto: CreateDtoType | UpdateDtoType
  ): DataStoreType | Partial<DataStoreType> | null {
    if (this.isUpdateDtoType(dto)) {
      return this.updateDtoToStore(dto);
    } else {
      return this.createDtoToStore(dto);
    }
  }

  /**
   * Transforms from CreateDto to a datastore compatible format
   * @param dto the dto to transform
   * @returns the transformed data
   */
  createDtoToStore(dto: CreateDtoType): Partial<DataStoreType> {
    return <Partial<DataStoreType>>(<unknown>dto);
  }

  /**
   * Transforms from UpdateDto to a datastore compatible format
   * @param dto the dto to transform
   * @returns the transformed data
   */
  updateDtoToStore(dto: UpdateDtoType): Partial<DataStoreType> {
    return <Partial<DataStoreType>>(<unknown>dto);
  }

  transformFromStore(storeDataObject: DataStoreType[]): Observable<DtoType[]>;
  transformFromStore(
    storeDataObject: DataStoreType | null
  ): Observable<DtoType>;
  transformFromStore(
    storeDataObject: Observable<DataStoreType>
  ): Observable<DtoType>;
  /**
   * Transforms datastore objects to externally consumable type
   * @param storeDataObject the data store object(s) to transform
   * @returns A transformed object, or a mapped transform if the input was an array
   */
  transformFromStore(
    storeDataObject:
      | Observable<DataStoreType>
      | DataStoreType
      | DataStoreType[]
      | null
  ): Observable<DtoType | DtoType[] | null> {
    if (!storeDataObject) {
      return of(null);
    }
    if (isObservable(storeDataObject)) {
      return (storeDataObject as Observable<DataStoreType>).pipe(
        concatMap((d) => this.storeToDto(d))
      );
    }
    if (Array.isArray(storeDataObject)) {
      return from(storeDataObject).pipe(
        concatMap((d) => this.storeToDto(d)),
        toArray()
      );
    }
    return this.storeToDto(storeDataObject);
  }

  /**
   * Transforms individual datastore objects to externally consumable objects
   * @param storeDataObject the object to transform
   */
  abstract storeToDto(storeDataObject: DataStoreType): Observable<DtoType>;

  /**
   * Helper function to standardise error formats
   * @param e the error to wrap
   * @returns the HttpException to raise
   */
  createHttpException(e: any) {
    this.logger.error(e);

    const responseCode = e.response?.status || 500;
    const errorData = e.response?.data || {
      errors: null,
    };

    return new HttpException(
      errorData.errors?.join(',') || STATUS_CODES[responseCode],
      responseCode
    );
  }

  /**
   * Gets the maximum number of results when creating a query
   * @returns the default limit
   */
  getQueryLimit(): number {
    return 100;
  }

  /**
   * Creates a new DataType in the datastore
   * @param dto The template to use to create
   * @returns An Observable that emits the transformed created data
   */
  create(dto: CreateDtoType): Observable<DtoType> {
    return from(
      this.datastoreDelegate.create({
        data: this.dtoToStore(dto),
      })
    ).pipe(
      switchMap((created) => {
        return this.transformFromStore(created);
      })
    );
  }

  /**
   * Finds all records in the datastore that match the filter
   * @param filterArgs the filters to apply
   * @returns An observable that emits all of the results
   */
  findAll(filterArgs?: QueryDtoType): Observable<DtoType[]> {
    // TODO: Allow altering the order clause
    return from(
      this.datastoreDelegate.findMany({
        take: this.getQueryLimit(),
        where: filterArgs ? filterArgs : undefined,
        orderBy: {
          modified: 'desc',
        },
      })
    ).pipe(switchMap((data) => this.transformFromStore(data)));
  }

  findFirst(filterArgs?: QueryDtoType): Observable<DtoType> {
    return from(this.datastoreDelegate.findFirst(filterArgs)).pipe(
      switchMap((storeData) => this.transformFromStore(storeData))
    );
  }

  /**
   * Helper function to transform a set of results to a paged view.  This ensures that paged views
   * are standardised
   * @param page the results of the query
   * @param pageSize the size of the page when retrieving the query
   * @returns the formatted page data
   */
  async transformPage(
    page: Connection<any, any>,
    pageSize = 10
  ): Promise<DTOPagedData<DtoType>> {
    const { guid: firstID = null } = page.nodes.length > 0 ? page.nodes[0] : {};
    const { guid: lastID = null } =
      page.nodes.length > 0 ? page.nodes[page.nodes.length - 1] : {};

    const transformedData: DtoType[] = await firstValueFrom(
      this.transformFromStore(page.nodes)
    );
    return {
      data: transformedData,
      totalCount: page.totalCount,
      pageSize: pageSize,
      // TODO: need to calculate the index so the cursor knows which record number we are on
      index: 0,
      pageInfo: {
        ...page.pageInfo,
        nextPage: lastID ? `first=${pageSize}&after=${lastID}` : undefined,
        previousPage: firstID
          ? `last=${pageSize}&before=${firstID}`
          : undefined,
      },
    };
  }

  /**
   * Retrieves a page of data from the datastore
   * @param cursorArgs the query parameters and filters for the page
   * @returns the resulting page
   */
  async findPage(
    cursorArgs: PageQueryParamsDto<QueryDtoType>
  ): Promise<DTOPagedData<DtoType>> {
    const page = await findManyCursorConnection(
      (args) => {
        return this.datastoreDelegate.findMany({
          ...args,
          cursor: args.cursor
            ? {
                guid: args.cursor.id,
              }
            : undefined,
          // where : where,
          // orderby : orderby
        });
      },
      // TODO: This could should take into account the were clause
      // TODO: If the after/before id is not valid then the count should be zero
      () => this.datastoreDelegate.count(),
      cursorArgs
    );
    return this.transformPage(page, cursorArgs.first || cursorArgs.last);
  }

  /**
   * Retrieves a record from the datastore with the specified id
   * @param id the unique identifier of the record to retrieve
   * @returns the transformed record found
   */
  findOne(id: string): Observable<DtoType | null | undefined> {
    return from(
      this.datastoreDelegate.findUnique({
        where: {
          guid: id,
        },
      })
    ).pipe(switchMap((storeData) => this.transformFromStore(storeData)));
  }

  /**
   * Updates an object in the datastore
   * @param id the unique identifier of the object to update
   * @param dto the tempate to update from
   * @returns the updated object
   * @throws ConflictException if the objectversions do not match
   */
  update(id: string, dto: UpdateDtoType): Observable<DtoType> {
    return from(
      this.datastoreDelegate.findUnique({
        where: {
          guid: id,
        },
      })
    ).pipe(
      filter((storeData) => {
        return Boolean(
          storeData && storeData.objectVersion === BigInt(dto.objectVersion)
        );
      }),
      defaultIfEmpty(null),
      switchMap((storeData) => {
        if (storeData) {
          return this.datastoreDelegate.update({
            where: {
              guid: id,
            },
            data: this.dtoToStore({
              ...dto,
              modified: new Date().getTime(),
              // Extract modified by from the user context
              modifiedBy: 'unknown',
              objectVersion: new Date().getTime(),
            }),
          });
        } else {
          throw new ConflictException(
            null,
            `Version mismatch for ${dto.objectVersion}`
          );
        }
      }),
      switchMap((storeData) => this.transformFromStore(storeData))
    );
  }

  /**
   * Removes a record from the datastore
   * @param id the unique identifier of the record to remove
   * @returns the removed record
   */
  remove(id: string): Observable<DtoType> {
    return from(
      this.datastoreDelegate.delete({
        where: {
          guid: id,
        },
      })
    ).pipe(switchMap((r) => this.transformFromStore(r)));
  }

  /**
   * Retrieves a list of objects where the id is in the provided list
   * @param ids The list of unique identifiers to extract
   * @param limit The maximum number of results to return
   * @returns An observable that emits the list of found results
   */
  findByIDs(ids: string[], limit = 999): Observable<DtoType[]> {
    const max = Math.min(limit, this.getQueryLimit());
    return from(
      this.datastoreDelegate.findMany({
        take: max,
        where: {
          guid: {
            in: [...ids],
          },
        },
        orderBy: {
          modified: 'desc',
        },
      })
    ).pipe(switchMap((data) => this.transformFromStore(data)));
  }
}
