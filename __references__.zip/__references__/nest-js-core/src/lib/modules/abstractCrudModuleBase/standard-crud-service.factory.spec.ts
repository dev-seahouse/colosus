describe('StandardCrudServiceFactory', () => {
  test.todo('test');
});

// import { ConflictException } from '@nestjs/common';
// import { Test, TestingModule } from '@nestjs/testing';
// import { firstValueFrom, Observable } from 'rxjs';
// import { PrismaService } from 'src/prisma/prisma.service';
// import { StandardCrudService } from '../StandardCrudService';
// import { AbstractStandardCrudService } from './stubs/AbstractStandardCrudService';
// import {
//   CreateTestClassDto,
//   createTestClassDtoStub,
// } from './stubs/create-test-class-stub.dto';
// import { PrismaDelegateMock } from './stubs/test-class-prisma-delegator-mock';
// import {
//   TestClassPrisma,
//   testClassPrismaStub,
// } from './stubs/test-class-prisma.stub';
// import { testClassStub, TestClassT } from './stubs/test-class.stub';
// import {
//   UpdateTestClassDto,
//   updateTestClassDtoStub,
// } from './stubs/update-test-class.stub.dto';

// describe(StandardCrudService.name, () => {
//   let sut: AbstractStandardCrudService;
//   let prismaDelegate: PrismaDelegateMock<TestClassPrisma>;

//   beforeEach(async () => {
//     prismaDelegate = new PrismaDelegateMock();

//     const moduleRef: TestingModule = await Test.createTestingModule({
//       providers: [
//         {
//           provide: AbstractStandardCrudService,
//           useFactory: (prismaService: PrismaService) => {
//             return new AbstractStandardCrudService(
//               prismaService,
//               prismaDelegate,
//             );
//           },
//         },
//       ],
//     }).compile();

//     sut = await moduleRef.get<AbstractStandardCrudService>(
//       AbstractStandardCrudService,
//     );
//   });

//   it('should be defined', () => {
//     expect(sut).toBeDefined();
//   });

//   describe('when calling create', () => {
//     let dtoToStoreSpy: jest.SpyInstance;
//     let storeToDtoSpy: jest.SpyInstance;
//     let delegateSpy: jest.SpyInstance;
//     let dto: CreateTestClassDto;
//     let retVal: Observable<TestClassT | null>;

//     beforeAll(() => {
//       dtoToStoreSpy = jest.spyOn(sut, 'dtoToStore');
//       storeToDtoSpy = jest.spyOn(sut, 'transformFromStore');

//       delegateSpy = jest.spyOn(prismaDelegate, 'create');
//       dto = createTestClassDtoStub();
//       retVal = sut.create(dto);
//     });

//     it('should transform the dto to a datastore type', () => {
//       expect(dtoToStoreSpy).toBeCalledWith(dto);
//     });

//     it('should call create on the datastore delegate', () => {
//       expect(delegateSpy).toBeCalledWith({
//         data: sut.createDtoToStore(dto),
//       });
//     });

//     it('should return an observable that is transformed when used', async () => {
//       expect(retVal).toBeInstanceOf(Observable);

//       expect(storeToDtoSpy).not.toBeCalled();
//       await retVal.subscribe((data) => {
//         expect(data).toEqual(testClassStub());
//       });
//       expect(storeToDtoSpy).toBeCalledWith(testClassPrismaStub());
//     });
//   });

//   describe('when calling findAll', () => {
//     let storeToDtoSpy: jest.SpyInstance;
//     let delegateSpy: jest.SpyInstance;
//     let retVal: Observable<TestClassT | null>;

//     beforeAll(() => {
//       storeToDtoSpy = jest.spyOn(sut, 'transformFromStore');

//       delegateSpy = jest.spyOn(prismaDelegate, 'findMany');
//       retVal = sut.findAll();
//     });

//     it('should call findAll on the datastore delegate', () => {
//       expect(delegateSpy).toBeCalledWith({
//         take: sut.getQueryLimit(),
//         orderBy: {
//           modified: 'desc',
//         },
//       });
//     });

//     it('should return an observable that is transformed when used', async () => {
//       expect(retVal).toBeInstanceOf(Observable);

//       await retVal.subscribe((data) => {
//         expect(data).toEqual([testClassStub()]);
//       });
//       expect(storeToDtoSpy).toBeCalledWith(testClassPrismaStub());
//     });
//   });

//   describe('when calling findOne', () => {
//     let storeToDtoSpy: jest.SpyInstance;
//     let delegateSpy: jest.SpyInstance;
//     let dto: CreateTestClassDto;
//     let retVal: Observable<TestClassT | null | undefined>;

//     beforeAll(() => {
//       storeToDtoSpy = jest.spyOn(sut, 'transformFromStore');

//       delegateSpy = jest.spyOn(prismaDelegate, 'findUnique');
//       dto = createTestClassDtoStub();
//       retVal = sut.findOne('an id');
//     });

//     it('should call findUnique on the datastore delegate', () => {
//       expect(delegateSpy).toBeCalledWith({
//         where: {
//           guid: 'an id',
//         },
//       });
//     });

//     it('should return an observable that is transformed when used', async () => {
//       expect(retVal).toBeInstanceOf(Observable);

//       expect(storeToDtoSpy).not.toBeCalled();
//       await retVal.subscribe((data) => {
//         expect(data).toEqual(testClassStub());
//       });
//       expect(storeToDtoSpy).toBeCalledWith(testClassPrismaStub());
//     });
//   });

//   describe('when calling update, happy path', () => {
//     let dtoToStoreSpy: jest.SpyInstance;
//     let delegateFindUniqueSpy: jest.SpyInstance;
//     let delegateUpdateSpy: jest.SpyInstance;
//     let retVal: Observable<TestClassT | null>;

//     beforeAll(() => {
//       dtoToStoreSpy = jest.spyOn(sut, 'dtoToStore');

//       delegateFindUniqueSpy = jest.spyOn(prismaDelegate, 'findUnique');
//       delegateUpdateSpy = jest.spyOn(prismaDelegate, 'update');
//       retVal = sut.update('an id', updateTestClassDtoStub());
//     });

//     it('should call findUnique on the datastore delegate', () => {
//       expect(delegateFindUniqueSpy).toBeCalledWith({
//         where: {
//           guid: 'an id',
//         },
//       });
//     });

//     it('should return an observable that executes the update when used', async () => {
//       expect(retVal).toBeInstanceOf(Observable);

//       expect(dtoToStoreSpy).not.toBeCalled();
//       expect(delegateUpdateSpy).not.toBeCalled();

//       await retVal.subscribe((data) => {
//         expect(data).toEqual(testClassStub());
//       });
//       expect(dtoToStoreSpy).toBeCalledWith({
//         ...updateTestClassDtoStub(),
//         modified: expect.anything(),
//         modifiedBy: 'unknown',
//         objectVersion: expect.anything(),
//       });

//       expect(delegateUpdateSpy).toBeCalledWith({
//         where: {
//           guid: 'an id',
//         },
//         data: sut.dtoToStore({
//           ...updateTestClassDtoStub(),
//           modified: expect.anything(),
//           modifiedBy: 'unknown',
//           objectVersion: expect.anything(),
//         }),
//       });
//     });
//   });

//   describe('when calling update, unhappy path', () => {
//     let dtoToStoreSpy: jest.SpyInstance;
//     let delegateFindUniqueSpy: jest.SpyInstance;
//     let delegateUpdateSpy: jest.SpyInstance;
//     let retVal: Observable<TestClassT | null>;

//     beforeAll(() => {
//       dtoToStoreSpy = jest.spyOn(sut, 'dtoToStore');

//       delegateFindUniqueSpy = jest.spyOn(prismaDelegate, 'findUnique');
//       delegateUpdateSpy = jest.spyOn(prismaDelegate, 'update');
//       retVal = sut.update(
//         'an id',
//         updateTestClassDtoStub({
//           objectVersion: 1234567890,
//         }),
//       );
//     });

//     it('should call findUnique on the datastore delegate', () => {
//       expect(delegateFindUniqueSpy).toBeCalledWith({
//         where: {
//           guid: 'an id',
//         },
//       });
//     });

//     it('should return an observable that executes the update when used', async () => {
//       expect(retVal).toBeInstanceOf(Observable);

//       expect(dtoToStoreSpy).not.toBeCalled();
//       expect(delegateUpdateSpy).not.toBeCalled();

//       const subscriber = await retVal.subscribe({
//         next: () => fail('an error should have been thrown'),
//         error: (err) => expect(err).toBeInstanceOf(ConflictException),
//       });

//       expect(dtoToStoreSpy).not.toBeCalled();
//       expect(delegateUpdateSpy).not.toBeCalled();
//     });
//   });

//   describe('when calling remove', () => {
//     let storeToDtoSpy: jest.SpyInstance;
//     let delegateSpy: jest.SpyInstance;
//     let retVal: Observable<TestClassT | null>;

//     beforeAll(() => {
//       storeToDtoSpy = jest.spyOn(sut, 'transformFromStore');

//       delegateSpy = jest.spyOn(prismaDelegate, 'delete');
//       retVal = sut.remove('an id');
//     });

//     it('should call delete on the datastore delegate', () => {
//       expect(delegateSpy).toBeCalledWith({
//         where: {
//           guid: 'an id',
//         },
//       });
//     });

//     it('should return an observable that is transformed when used', async () => {
//       expect(retVal).toBeInstanceOf(Observable);

//       expect(storeToDtoSpy).not.toBeCalled();
//       await retVal.subscribe((data) => {
//         expect(data).toEqual(testClassStub());
//       });
//       expect(storeToDtoSpy).toBeCalledWith(testClassPrismaStub());
//     });
//   });

//   describe('when calling findByIDs', () => {
//     let storeToDtoSpy: jest.SpyInstance;
//     let delegateSpy: jest.SpyInstance;
//     let retVal: Observable<TestClassT[]>;

//     beforeAll(() => {
//       storeToDtoSpy = jest.spyOn(sut, 'transformFromStore');

//       delegateSpy = jest.spyOn(prismaDelegate, 'findMany');
//       retVal = sut.findByIDs(['an id']);
//     });

//     it('should call delete on the datastore delegate', () => {
//       expect(delegateSpy).toBeCalledWith({
//         take: sut.getQueryLimit(),
//         where: {
//           guid: {
//             in: ['an id'],
//           },
//         },
//         orderBy: {
//           modified: 'desc',
//         },
//       });
//     });

//     it('should return a promise that is transformed when used', (done) => {
//       expect(retVal).toBeInstanceOf(Observable);

//       expect(storeToDtoSpy).not.toBeCalled();

//       retVal.subscribe((data) => {
//         expect(storeToDtoSpy).toBeCalledWith([
//           {
//             guid: 'a guid',
//             created: 987654321n,
//             createdBy: 'created by',
//             modified: 987654321n,
//             modifiedBy: 'modified by',
//             objectVersion: 987654321n,
//           },
//         ]);
//         expect(data).toEqual([{}]);
//         done();
//       });
//     });
//   });

//   describe('when transforming data', () => {
//     it('should return null if null is provided', async () => {
//       expect(await firstValueFrom(sut.transformFromStore(null))).toBe(null);
//     });

//     it('performs an identity transform by default on updateDtoToStore', () => {
//       const dto: UpdateTestClassDto = {
//         objectVersion: 876954321,
//       };

//       expect(sut.updateDtoToStore(dto)).toEqual({
//         objectVersion: 876954321,
//       });
//     });

//     it('can transform an array of datastore objects', async () => {
//       const dto: TestClassPrisma[] = [testClassPrismaStub()];

//       expect(await firstValueFrom(sut.transformFromStore(dto))).toEqual([{}]);
//     });
//   });
// });
