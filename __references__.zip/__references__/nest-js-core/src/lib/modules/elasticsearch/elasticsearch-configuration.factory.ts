import { DeepPartial, _ } from '@bambu/js-core';
import { Logger } from '@nestjs/common';
import { ConfigurationFactory } from '../../config';
import { NestModuleConfig } from '../types';
import { ElasticsearchModule } from './elasticsearch.module';
import { ElasticsearchHealthIndicator } from './health/elasticsearch.health';
import { ElasticsearchConfiguration } from './types';

export class ElasticsearchConfigurationFactory extends ConfigurationFactory<
  ElasticsearchConfiguration,
  'elasticsearch'
> {
  constructor(
    config?: Record<'elasticsearch', DeepPartial<ElasticsearchConfiguration>>,
    logger?: Logger
  ) {
    super('elasticsearch', [], config, logger);
  }

  initialiseConfiguration(
    config: DeepPartial<
      Record<'elasticsearch', ElasticsearchConfiguration> & Record<string, any>
    >
  ): DeepPartial<
    Record<'elasticsearch', ElasticsearchConfiguration> & Record<string, any>
  > {
    config = _.cloneDeep(config);
    const base: DeepPartial<ElasticsearchConfiguration> =
      config.elasticsearch || {};
    config.elasticsearch = {
      database: base.database || process.env.ELASTICSEARCH_DATABASE,
      host: base.host || process.env.ELASTICSEARCH_HOST || 'http://localhost',
      password: base.password || process.env.ELASTICSEARCH_PASSWORD,
      port:
        base.port ||
        parseInt(process.env.ELASTICSEARCH_PORT || '9200', 10) ||
        9200,
      username: base.username || process.env.ELASTICSEARCH_USERNAME,
    };
    return config;
  }

  getConfiguration(
    current?: DeepPartial<
      Record<'elasticsearch', ElasticsearchConfiguration> & Record<string, any>
    >
  ): Record<'elasticsearch', ElasticsearchConfiguration> & Record<string, any> {
    current = super.getConfiguration(current);
    return current as Record<'elasticsearch', ElasticsearchConfiguration> &
      Record<string, any>;
  }

  getModuleMetadata(): NestModuleConfig[] {
    const metadata = super.getModuleMetadata();

    return [
      ...metadata,
      {
        name: this.constructor.name,
        imports: [ElasticsearchModule],
        healthIndicators: [
          {
            imports: [ElasticsearchModule],
            providers: [ElasticsearchHealthIndicator],
          },
        ],
      },
    ];
  }
}
