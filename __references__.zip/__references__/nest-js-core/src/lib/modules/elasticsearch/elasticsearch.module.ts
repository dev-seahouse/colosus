import { Module } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import { ElasticsearchModule as NestESModule } from '@nestjs/elasticsearch';
import { ElasticsearchAdminService } from './elasticsearch-admin.service';
import { ElasticsearchNodeService } from './elasticsearch-node.service';
import { ElasticsearchSearchService } from './elasticsearch-search.service';
import { ElasticsearchConfiguration } from './types';

@Module({
  imports: [
    NestESModule.registerAsync({
      useFactory: async (configService: ConfigService) => {
        const config =
          configService.get<ElasticsearchConfiguration>('elasticsearch');
        const esBaseUrl = `${config.host}:${config.port}`;

        console.log(esBaseUrl, { config });

        // TODO: Configure other options
        return {
          node: esBaseUrl,
        };
      },
      inject: [ConfigService],
    }),
  ],
  providers: [
    ElasticsearchSearchService,
    ElasticsearchNodeService,
    ElasticsearchAdminService,
  ],
  exports: [
    ElasticsearchSearchService,
    ElasticsearchNodeService,
    ElasticsearchAdminService,
  ],
})
export class ElasticsearchModule {}
