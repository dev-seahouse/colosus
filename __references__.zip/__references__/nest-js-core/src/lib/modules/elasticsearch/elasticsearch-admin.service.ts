import { Injectable } from '@nestjs/common';
import { ElasticsearchService } from '@nestjs/elasticsearch';

@Injectable()
export class ElasticsearchAdminService {
  constructor(private readonly elasticsearchService: ElasticsearchService) {}

  async pingDb() {
    const now = Date.now();
    await this.elasticsearchService.ping();
    return {
      ms: Date.now() - now,
    };
  }
}
