describe('ElasticsearchConfiguration', () => {
  test.todo('test');
});
