import { ApplicationInfo, DeepPartial } from '@bambu/js-core';
import { INestApplication, Logger } from '@nestjs/common';
import { ConfigurationFactory } from '../../config';
import { SwaggerConfiguration } from './types';
import { _ } from '@bambu/js-core';
import { ConfigService } from '@nestjs/config';
import { DocumentBuilder, SwaggerModule } from '@nestjs/swagger';
import { ServerConfiguration } from '../server';

import type { NestExpressApplication } from '@nestjs/platform-express';

export function enableSwagger(
  app: INestApplication,
  logger: Logger,
  swaggerConfig: SwaggerConfiguration,
  serverConfig: ServerConfiguration,
  appInfo: ApplicationInfo
) {
  if (!serverConfig.host) {
    throw new Error('serverConfig host not set');
  }
  const swaggerBuilder = new DocumentBuilder()
    .addServer(serverConfig.host)
    .setTitle(appInfo.name)
    .setDescription(appInfo.description)
    .setVersion(appInfo.version)
    .addBearerAuth()
    .addSecurity('Client Token', {
      type: 'http',
      scheme: 'basic',
    })
    .addServer(
      'http://localhost:9000',
      'For poor Windows users where http://0.0.0.0:9000/ does not work.'
    )
    .build();

  const swaggerDoc = SwaggerModule.createDocument(app, swaggerBuilder, {
    deepScanRoutes: true,
    operationIdFactory: (_, methodKey) => methodKey,
  });

  logger.log(`Enabling swagger on /${swaggerConfig.path}`);
  SwaggerModule.setup(swaggerConfig.path, app, swaggerDoc, {
    customCssUrl: `/static/swagger-ui/themes/theme-${swaggerConfig.theme}.css`,
    customJs: `/static/swagger-ui/customise-swagger.js`,
    customfavIcon: `/favicon.ico`,
    customSiteTitle: `${appInfo.name} - docs`,
  });
}

export class SwaggerConfigurationFactory extends ConfigurationFactory<
  SwaggerConfiguration,
  'swagger'
> {
  constructor(
    config?: Record<'swagger', DeepPartial<SwaggerConfiguration>>,
    logger?: Logger
  ) {
    super('swagger', [], config, logger);
  }

  initialiseConfiguration(
    config: DeepPartial<
      Record<'swagger', SwaggerConfiguration> & Record<string, any>
    >
  ): DeepPartial<
    Record<'swagger', SwaggerConfiguration> & Record<string, any>
  > {
    config = _.cloneDeep(config);
    const base: DeepPartial<SwaggerConfiguration> = config.swagger || {};
    config.swagger = {
      ...base,
      theme: base.theme || process.env.SWAGGER_THEME || 'material',
      path: base.theme || process.env.OPENAPI_PATH || 'openapi',
    };
    return config;
  }

  getConfiguration(
    current?: DeepPartial<
      Record<'swagger', SwaggerConfiguration> & Record<string, any>
    >
  ): Record<'swagger', SwaggerConfiguration> & Record<string, any> {
    current = super.getConfiguration(current);
    // Make any updates to the configuration here
    return current as Record<'swagger', SwaggerConfiguration> &
      Record<string, any>;
  }

  getInitialisationStrategy(
    configService: ConfigService
  ): ((app: NestExpressApplication) => void)[] {
    const strategies = super.getInitialisationStrategy(configService);
    return [
      ...strategies,
      (app: NestExpressApplication) => {
        enableSwagger(
          app,
          this.logger,
          configService.get('swagger'),
          configService.get('server'),
          configService.get('appInfo')
        );
      },
    ];
  }
}
