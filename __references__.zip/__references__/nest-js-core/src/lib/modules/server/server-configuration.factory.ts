import { DeepPartial, _ } from '@bambu/js-core';
import { Inject, Logger, Scope } from '@nestjs/common';
import { ConfigService, ConfigType, registerAs } from '@nestjs/config';
import { APP_FILTER, APP_INTERCEPTOR, APP_PIPE } from '@nestjs/core';
import { NestExpressApplication } from '@nestjs/platform-express';
import rateLimit from 'express-rate-limit';
import { createProxyMiddleware } from 'http-proxy-middleware';
import { ConfigurationFactory } from '../../config';
import { AllExceptionFilter, HttpExceptionFilter } from '../../filters';
import { LoggingInterceptor } from '../../interceptors';
import { FreezePipe } from '../../pipes';
import { isExpress } from '../../types';
import { CacheModule } from '../cache';
import { NestModuleConfig } from '../types';

export const serverConfiguration = registerAs('server', () => {
  const config = {
    /**
     * The API version to add to API calls where the
     * API version has not been explicitly set.
     * @see https://docs.nestjs.com/techniques/versioning
     */
    apiVersion: Number(process.env.API_VERSION) || 1,
    /**
     * The port number that this server is listening on
     */
    port: Number(process.env.PORT) || 9000,
    /**
     * A path for serving any static files.  If not
     * specified the server will not serve static files
     */
    staticRootPath: undefined as string,
    /**
     * url path prefix for serving static files.
     * Defaults to /static/
     */
    staticPrefix: '/static/',
    /**
     * The URL to forward requests for proxied endpoints
     */
    proxyTarget: process.env.PROXY_TARGET || undefined,
    /**
     * The list of endpoints that should be forwarded to the proxy
     */
    proxyEndpoints: undefined as string[],
    /**
     * The hostname for this server
     */
    hostname: process.env.SERVER_HOSTNAME || 'http://0.0.0.0',
    /**
     * The host address
     */
    host: process.env.HOST,
    /**
     * The rate limit settings.  This will allow N/second requests.
     */
    rateLimit: Number(process.env.RATE_LIMIT) || 500,
    /**
     * The url for the web application that is being served by this api
     */
    webHost: process.env.WEB_HOST || null,
  };

  return config;
});

export type ServerConfiguration = ConfigType<typeof serverConfiguration>;

export const InjectServerConfig = () => Inject(serverConfiguration.KEY);

function enableExpressProxy(
  app: NestExpressApplication,
  logger: Logger,
  serverConfig: ServerConfiguration
) {
  const proxyTarget = serverConfig.proxyTarget;
  const proxyEndpoints = serverConfig.proxyEndpoints;

  if (proxyTarget) {
    logger.log(`Creating proxy to ${proxyTarget}`);
    if (!proxyEndpoints || proxyEndpoints.length === 0) {
      throw new Error('ProxyTarget set but no endpoints specified');
    }
    const denyProxy = proxyEndpoints
      .filter((ep) => ep.startsWith('!'))
      .map((ep) => ep.substring(1));
    const proxy = proxyEndpoints.filter((ep) => !ep.startsWith('!'));
    proxy.forEach((ep) => {
      logger.log(`${ep} ==> ${proxyTarget}${ep}`);
    });
    denyProxy.forEach((ep) => {
      logger.log(`${ep} !=> ${proxyTarget}${ep}`);
    });
    app.use(
      createProxyMiddleware(
        (pathname) => {
          if (denyProxy.some((ep) => pathname.startsWith(ep))) {
            return false;
          } else if (proxy.some((ep) => pathname.startsWith(ep))) {
            return true;
          }
          return false;
        },
        {
          target: proxyTarget,
          changeOrigin: false,
          logProvider: () => {
            const logFN = () => {
              // Do nothing
            };
            return {
              log: logFN,
              debug: logFN,
              info: logFN,
              warn: logFN,
              error: logFN,
            };
          },
        }
      )
    );
  }
}

function initialiseExpress(
  app: NestExpressApplication,
  logger: Logger,
  serverConfig: ServerConfiguration
) {
  logger.log('Initialising Express');

  // As we are behind a loadbalancer we need to set up a trusted proxy
  logger.log('Setting trust proxy');
  app.set('trust proxy', 1);

  if (serverConfig.staticRootPath) {
    logger.log(
      `Serving static files from ${serverConfig.staticRootPath} at ${serverConfig.host}/static`
    );
    app.useStaticAssets(serverConfig.staticRootPath, {
      dotfiles: 'ignore',
      etag: true,
      extensions: [],
      fallthrough: false,
      immutable: true,
      index: false,
      lastModified: true,
      maxAge: 1000 * 60 * 60,
      prefix: serverConfig.staticPrefix,
      redirect: true,
    });

    if (serverConfig.rateLimit) {
      const limit = serverConfig.rateLimit;
      logger.log(`Setting rate limit to ${limit} per minute`);
      app.use(
        rateLimit({
          windowMs: 1000 * 60,
          max: limit,
        })
      );
    }

    enableExpressProxy(app, logger, serverConfig);
  }
}

export class ServerConfigurationFactory extends ConfigurationFactory<
  ServerConfiguration,
  'server'
> {
  constructor(
    config?: Record<'server', DeepPartial<ServerConfiguration>>,
    logger?: Logger
  ) {
    super('server', [], config, logger);
  }

  initialiseConfiguration(
    config: DeepPartial<
      Record<'server', ServerConfiguration> & Record<string, any>
    >
  ): DeepPartial<Record<'server', ServerConfiguration> & Record<string, any>> {
    config = _.cloneDeep(config);
    const base: DeepPartial<ServerConfiguration> = config.server || {};
    config.server = {
      ...base,
      port: base.port || parseInt(process.env.PORT || '9000', 10) || 9000,
      proxyTarget: base.proxyTarget || process.env.PROXY_TARGET || undefined,
      proxyEndpoints: base.proxyEndpoints,
      hostname:
        base.hostname || process.env.SERVER_HOSTNAME || 'http://0.0.0.0',
      host: process.env.HOST,
      rateLimit:
        base.rateLimit || parseInt(process.env.RATE_LIMIT || '500', 10) || 500,
      apiVersion:
        base.apiVersion || parseInt(process.env.API_VERSION || '1', 10) || 1,
      staticRootPath: base.staticRootPath,
      staticPrefix: base.staticPrefix || '/static/',
      webHost: base.webHost || process.env.WEB_HOST || null,
    };
    config.server.host =
      base.host ||
      process.env.HOST ||
      `${config.server.hostname}:${config.server.port}`;
    return config;
  }

  getConfiguration(
    current?: DeepPartial<
      Record<'server', ServerConfiguration> & Record<string, any>
    >
  ): Record<'server', ServerConfiguration> & Record<string, any> {
    current = super.getConfiguration(current);
    // Make any updates to the configuration here
    return current as Record<'server', ServerConfiguration> &
      Record<string, any>;
  }

  getInitialisationStrategy(
    configService: ConfigService<Record<string, unknown>, false>
  ): ((app: NestExpressApplication) => void)[] {
    const strategies = super.getInitialisationStrategy(configService);
    return [
      ...strategies,
      (app: NestExpressApplication) => {
        if (isExpress(app)) {
          initialiseExpress(app, this.logger, configService.get('server'));
        } else {
          throw new Error('Fastify for Nest.js has been removed.');
        }
      },
    ];
  }

  getModuleMetadata(): NestModuleConfig[] {
    const metadata = super.getModuleMetadata();
    return [
      ...metadata,
      {
        name: this.constructor.name,
        imports: [CacheModule],
        providers: [
          {
            provide: APP_INTERCEPTOR,
            scope: Scope.REQUEST,
            useClass: LoggingInterceptor,
          },
          {
            provide: APP_PIPE,
            useClass: FreezePipe,
          },
          {
            provide: APP_FILTER,
            useClass: AllExceptionFilter,
          },
          {
            provide: APP_FILTER,
            useClass: HttpExceptionFilter,
          },
        ],
      },
    ];
  }
}
