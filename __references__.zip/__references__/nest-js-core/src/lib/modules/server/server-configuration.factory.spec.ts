import { ServerConfigurationFactory as sut } from './server-configuration.factory';

describe('ConfigFactory', () => {
  describe('Defaults', () => {
    const OLD_ENV = process.env;

    beforeEach(() => {
      jest.resetModules();
      process.env = {
        ...OLD_ENV,
      };
    });

    afterAll(() => {
      process.env = OLD_ENV;
    });

    it('should provide appropriate defaults', () => {
      process.env.PORT = undefined;
      process.env.PROXY_TARGET = undefined;
      process.env.SERVER_HOSTNAME = undefined;
      process.env.CLIENT_URL = undefined;
      process.env.RATE_LIMIT = undefined;
      process.env.TOKEN_CALLBACK_URL = undefined;
      process.env.HOST = undefined;
      process.env.API_VERSION = undefined;

      const conf = new sut({
        server: {},
      }).getConfiguration().server;

      expect(conf.port).toBe(9000);
      expect(conf.proxyTarget).toBeUndefined();
      expect(conf.hostname).toBe('http://0.0.0.0');
      expect(conf.host).toBe('http://0.0.0.0:9000');
      expect(conf.rateLimit).toBe(500);
      expect(conf.apiVersion).toBe(1);
    });

    it('should pick up environment variables', () => {
      process.env.PORT = '8000';
      process.env.PROXY_TARGET = 'http://www.google.com';
      process.env.SERVER_HOSTNAME = 'http://my.server.com';
      process.env.RATE_LIMIT = '1000';
      process.env.HOST = 'http://my.custom.host.com';
      process.env.API_VERSION = '2';

      const conf = new sut({
        server: {},
      }).getConfiguration().server;

      expect(conf.port).toBe(8000);
      expect(conf.proxyTarget).toBe('http://www.google.com');
      expect(conf.hostname).toBe('http://my.server.com');
      expect(conf.rateLimit).toBe(1000);
      expect(conf.host).toBe('http://my.custom.host.com');
      expect(conf.apiVersion).toBe(2);
    });
  });

  describe('Expands Partial configuration', () => {
    const OLD_ENV = process.env;

    beforeEach(() => {
      jest.resetModules();
      process.env = {
        ...OLD_ENV,
      };
    });

    afterAll(() => {
      process.env = OLD_ENV;
    });

    it('Allows overriding of environment variables', () => {
      process.env.PORT = '8000';
      process.env.PROXY_TARGET = 'http://www.google.com';
      process.env.SERVER_HOSTNAME = 'http://my.server.com';
      process.env.RATE_LIMIT = '1000';
      process.env.HOST = 'http://my.custom.host.com';
      process.env.API_VERSION = '2';

      const conf = new sut({
        server: {
          port: 1234,
        },
      }).getConfiguration().server;

      expect(conf.port).toBe(1234);
      expect(conf.proxyTarget).toBe('http://www.google.com');
      expect(conf.hostname).toBe('http://my.server.com');
      expect(conf.rateLimit).toBe(1000);
      expect(conf.host).toBe('http://my.custom.host.com');
      expect(conf.apiVersion).toBe(2);
    });

    it('Allows overriding of all environment variables', () => {
      process.env.PORT = '8000';
      process.env.PROXY_TARGET = 'http://www.google.com';
      process.env.SERVER_HOSTNAME = 'http://my.server.com';
      process.env.RATE_LIMIT = '1000';
      process.env.HOST = 'http://my.custom.host.com';
      process.env.API_VERSION = '2';

      const conf = new sut({
        server: {
          port: 1234,
          proxyTarget: 'a proxy target url',
          hostname: 'a server hostname',
          rateLimit: 200,
          host: 'a host url',
          apiVersion: 12,
        },
      }).getConfiguration().server;

      expect(conf.port).toBe(1234);
      expect(conf.proxyTarget).toBe('a proxy target url');
      expect(conf.hostname).toBe('a server hostname');
      expect(conf.rateLimit).toBe(200);
      expect(conf.host).toBe('a host url');
      expect(conf.apiVersion).toBe(12);
    });
  });

  describe('Configures modules', () => {
    const OLD_ENV = process.env;

    beforeEach(() => {
      jest.resetModules();
      process.env = {
        ...OLD_ENV,
      };
    });

    afterAll(() => {
      process.env = OLD_ENV;
    });

    test.todo('reimplement tests');

    // it('Does not configure a static module if no root is provided', () => {
    //   const conf = sut({});

    //   console.log({ conf });
    //   expect(conf.nestModule).toBeDefined();
    //   expect(conf.nestModule.name).toBe('Server Module');
    //   expect(conf.nestModule.title).toBe('Server Module');
    //   expect(conf.nestModule.imports).toStrictEqual([]);
    //   expect(conf.nestModule.providers).toStrictEqual([]);
    // });

    // it('Configures a static module if a root is provided', () => {
    //   const conf = sut({
    //     staticRootPath: '../pathToStaticFiles',
    //   });

    //   expect(conf.nestModule).toBeDefined();
    //   expect(conf.nestModule.name).toBe('Server Module');
    //   expect(conf.nestModule.title).toBe('Server Module');
    //   const staticModule = conf.nestModule.imports.find((m: DynamicModule) => {
    //     return m.module === ServeStaticModule;
    //   }) as DynamicModule;

    //   expect(staticModule).toBeDefined();
    //   const useValue = (staticModule.providers[0] as any).useValue;
    //   expect(useValue).toBeDefined();
    //   expect(useValue[0].rootPath).toBe(conf.staticRootPath);
    // });
  });
});
