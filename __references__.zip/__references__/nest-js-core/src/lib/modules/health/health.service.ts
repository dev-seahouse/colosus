import { Inject, Injectable } from '@nestjs/common';
import { ModuleRef } from '@nestjs/core';
import { HealthCheckService } from '@nestjs/terminus';
import { HEALTH_INDICATOR_TOKEN } from './types';

@Injectable()
export class HealthService {
  constructor(
    private moduleRef: ModuleRef,
    private readonly healthCheckService: HealthCheckService,
    @Inject(HEALTH_INDICATOR_TOKEN) private healthIndicators
  ) {}

  check() {
    const checks = this.healthIndicators.map((i) => {
      let service = null;
      try {
        service = this.moduleRef.get(i);
      } catch {
        // Do nothing
      }
      return () => service.isConnected();
    });
    return this.healthCheckService.check(checks);
  }
}
