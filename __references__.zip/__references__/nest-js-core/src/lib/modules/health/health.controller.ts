import { Controller, Get, VERSION_NEUTRAL } from '@nestjs/common';
import { ApiTags } from '@nestjs/swagger';
import { HealthCheck } from '@nestjs/terminus';
import { HealthService } from './health.service';

@ApiTags('Health')
@Controller({
  path: 'health',
  version: VERSION_NEUTRAL,
})
export class HealthController {
  constructor(private healthService: HealthService) {}

  /**
   * Reports the status of all dependencies that have health indicators set up
   */
  @Get()
  @HealthCheck()
  Check() {
    return this.healthService.check();
  }
}
