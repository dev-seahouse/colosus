import { DynamicModule, Module, ModuleMetadata } from '@nestjs/common';
import { TerminusModule } from '@nestjs/terminus';
import { NestModuleConfig } from '../types';
import { HealthController } from './health.controller';
import { HealthService } from './health.service';
import { HEALTH_INDICATOR_TOKEN } from './types';

@Module({})
export class HealthModule {
  static forRoot(
    indicators: NestModuleConfig['healthIndicators']
  ): DynamicModule {
    const resolvedModules = indicators.reduce(
      (acc: ModuleMetadata, module: ModuleMetadata) => {
        acc.imports.push(...(module.imports || []));
        acc.providers.push(...(module.providers || []));
        acc.controllers.push(...(module.controllers || []));
        acc.exports.push(...(module.exports || []));
        return acc;
      },
      {
        imports: [],
        providers: [],
        controllers: [],
        exports: [],
      }
    );

    return {
      module: HealthModule,
      imports: [TerminusModule, ...resolvedModules.imports],
      providers: [
        ...resolvedModules.providers,
        {
          provide: HEALTH_INDICATOR_TOKEN,
          useFactory: () => {
            return resolvedModules.providers;
          },
        },
        HealthService,
      ],
      controllers: [HealthController, ...resolvedModules.controllers],
      exports: [...resolvedModules.exports],
    };
  }
}
