import { ArgumentsHost, Catch, ExceptionFilter, Logger } from '@nestjs/common';
import { HttpAdapterHost } from '@nestjs/core';
import { STATUS_CODES } from 'http';
import { HTTPError } from '../dto';

@Catch()
export class AllExceptionFilter implements ExceptionFilter {
  private readonly logger = new Logger(AllExceptionFilter.name);

  constructor(private readonly httpAdapterHost: HttpAdapterHost) {}

  catch(exception: any, host: ArgumentsHost) {
    // In certain situations `httpAdapter` might not be available in the
    // constructor method, thus we should resolve it here.
    const { httpAdapter } = this.httpAdapterHost;

    const ctx = host.switchToHttp();

    const httpStatus =
      (exception.getStatus
        ? exception.getStatus()
        : exception.statusCode || exception.response?.status) || 500;

    const responseBody: HTTPError = {
      statusCode: httpStatus,
      timestamp: new Date().toISOString(),
      path: httpAdapter.getRequestUrl(ctx.getRequest()),
      errors: [exception.expose ? exception.message : STATUS_CODES[httpStatus]],
    };

    this.logger.error(exception);
    httpAdapter.reply(ctx.getResponse(), responseBody, httpStatus);
  }
}
