import { Exception } from '@jest/types/build/Circus';
import { Logger } from '@nestjs/common';
import { AbstractHttpAdapter } from '@nestjs/core';
import { ExpressAdapter } from '@nestjs/platform-express';
import { AllExceptionFilter } from './all-exception.filter';

describe(AllExceptionFilter.name, () => {
  let filter: AllExceptionFilter;
  let httpAdapter: AbstractHttpAdapter;
  let loggerSpy: jest.SpyInstance;

  const mockContext: any = {
    switchToHttp: () => ({
      getRequest: () => ({
        url: 'mock-url',
      }),
      getResponse: () => {
        const response = {
          code: jest.fn().mockReturnThis(),
          send: jest.fn().mockReturnThis(),
        };
        return response;
      },
    }),
  };

  beforeEach(async () => {
    const mockHttpAdapter: AbstractHttpAdapter = new ExpressAdapter();
    mockHttpAdapter.reply = jest.fn();
    mockHttpAdapter.getRequestUrl = jest.fn().mockReturnValue('/somewhere');

    httpAdapter = mockHttpAdapter;
    filter = new AllExceptionFilter({
      httpAdapter: mockHttpAdapter,
    });

    loggerSpy = jest.spyOn(Logger.prototype, 'error');
  });

  afterEach(() => {
    loggerSpy.mockReset();
  });

  it('should be defined', () => {
    expect(filter).toBeDefined();
  });

  it('should catch and log the error', () => {
    const mockException: Exception = new Error('An error');

    jest.fn(mockContext.switchToHttp().getResponse().send);
    filter.catch(mockException, mockContext);

    expect(httpAdapter.reply).toBeCalledWith(
      expect.anything(),
      {
        errors: ['Internal Server Error'],
        statusCode: 500,
        path: '/somewhere',
        timestamp: expect.anything(),
      },
      500
    );
    expect(loggerSpy).toBeCalledWith(mockException);
  });
});
