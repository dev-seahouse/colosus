import { BadRequestException, Logger } from '@nestjs/common';
import { AbstractHttpAdapter } from '@nestjs/core';
import { ExpressAdapter } from '@nestjs/platform-express';
import { HttpExceptionFilter } from './http-exception.filter';

describe(HttpExceptionFilter.name, () => {
  let filter: HttpExceptionFilter;
  let httpAdapter: AbstractHttpAdapter;
  let loggerSpy: jest.SpyInstance;

  const mockContext: any = {
    switchToHttp: () => ({
      getRequest: () => ({
        url: 'mock-url',
      }),
      getResponse: () => {
        const response = {
          code: jest.fn().mockReturnThis(),
          send: jest.fn().mockReturnThis(),
        };
        return response;
      },
    }),
  };

  beforeEach(async () => {
    const mockHttpAdapter: AbstractHttpAdapter = new ExpressAdapter();
    mockHttpAdapter.reply = jest.fn();
    mockHttpAdapter.getRequestUrl = jest.fn().mockReturnValue('/somewhere');

    httpAdapter = mockHttpAdapter;
    filter = new HttpExceptionFilter({
      httpAdapter: mockHttpAdapter,
    });

    loggerSpy = jest.spyOn(Logger.prototype, 'error');
  });

  afterEach(() => {
    loggerSpy.mockReset();
  });

  it('should be defined', () => {
    expect(filter).toBeDefined();
  });

  it('should catch and log the error', () => {
    const mockException: BadRequestException = new BadRequestException();

    jest.fn(mockContext.switchToHttp().getResponse().send);
    filter.catch(mockException, mockContext);

    expect(httpAdapter.reply).toBeCalledWith(
      expect.anything(),
      {
        errors: [mockException.message],
        statusCode: mockException.getStatus(),
        path: '/somewhere',
        timestamp: expect.anything(),
      },
      mockException.getStatus()
    );
    expect(loggerSpy).toBeCalledWith(mockException);
  });
});
