import { CallHandler, ExecutionContext, Logger } from '@nestjs/common';
import { of } from 'rxjs';
import { LoggingInterceptor } from './logging.interceptor';

describe('Logging Interceptor', () => {
  it('Should be defined', () => {
    expect(new LoggingInterceptor()).toBeDefined();
  });

  describe('Logs requests', () => {
    let loggerSpy: jest.SpyInstance;
    let sut: LoggingInterceptor;

    const mockExecutionContext: unknown = {
      getClass: jest.fn().mockReturnValue({
        name: 'test execution',
      }),
      getHandler: jest.fn().mockReturnValue({
        name: 'test handler',
      }),
      getType: jest.fn().mockReturnValue('http'),
      switchToHttp: jest.fn().mockReturnValue({
        getRequest: jest.fn(() => ({
          get: () => 'test-user-agent',
          originalUrl: '/',
          method: 'GET',
          params: undefined,
          query: undefined,
          body: undefined,
          ip: '0.0.0.0',
          path: '/a/path',
        })),
        getResponse: () => ({
          statusCode: 200,
        }),
      }),
    };
    const mockCallHandler: unknown = {
      handle: () => of('test'),
    };

    beforeEach(() => {
      sut = new LoggingInterceptor();
      loggerSpy = jest.spyOn(Logger.prototype, 'log');
    });

    afterEach(() => {
      loggerSpy.mockReset();
    });

    it('should log request initialised', (done: any) => {
      const responseInterceptor: any = sut.intercept(
        <ExecutionContext>mockExecutionContext,
        <CallHandler<any>>mockCallHandler
      );

      responseInterceptor.subscribe({
        next: (value: unknown) => value,
        error: (error: unknown) => {
          throw error;
        },
        complete: () => {
          expect(loggerSpy).toHaveBeenCalledTimes(2);
          expect(loggerSpy).toHaveBeenCalledWith(
            'GET /a/path test-user-agent 0.0.0.0 test execution test handler invoked...'
          );
          expect(loggerSpy).toHaveBeenLastCalledWith(
            expect.stringMatching(
              /^GET \/a\/path 200 - test-user-agent \(unknown\) 0.0.0.0: \d+$/
            )
          );
          done();
        },
      });
    });
  });
});
