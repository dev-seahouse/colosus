import {
  Injectable,
  NestInterceptor,
  Logger,
  ExecutionContext,
  CallHandler,
} from '@nestjs/common';
import { Observable, tap } from 'rxjs';

@Injectable()
export class LoggingInterceptor implements NestInterceptor {
  private readonly logger = new Logger(LoggingInterceptor.name);

  intercept(
    ctx: ExecutionContext,
    next: CallHandler<any>
  ): Observable<any> | Promise<Observable<any>> {
    const request = ctx.switchToHttp().getRequest();
    const userAgent = request.get('user-agent') || '';
    const { ip, method, path: url } = request;

    this.logger.log(
      `${method} ${url} ${userAgent} ${ip} ${ctx.getClass().name} ${
        ctx.getHandler().name
      } invoked...`
    );

    const now = Date.now();
    return next.handle().pipe(
      tap((/*res*/) => {
        const response = ctx.switchToHttp().getResponse();
        const { statusCode } = response;
        const user = request.user?.id || 'unknown';

        this.logger.log(
          `${method} ${url} ${statusCode} - ${userAgent} (${user}) ${ip}: ${
            Date.now() - now
          }`
        );
      })
    );
  }
}
