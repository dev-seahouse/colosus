export type KeyValuePair<ValueType> = {
  [key: string]: ValueType;
};
