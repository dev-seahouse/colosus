import { NestExpressApplication } from '@nestjs/platform-express';

type NestApplicationType = NestExpressApplication;

export function isExpress(
  app: NestApplicationType
): app is NestExpressApplication {
  return (app as NestApplicationType).use !== undefined;
}
