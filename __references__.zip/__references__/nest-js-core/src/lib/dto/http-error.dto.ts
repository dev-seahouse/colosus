export class HTTPError {
  /**
   * The HTTP status code for the error
   * @example 401
   */
  statusCode: number;
  /**
   * The time at which the error occurred
   * @example "2022-08-26T13:11:05.221Z"
   */
  timestamp: string;
  /**
   * The path that caused the error
   * @example "/<resource>/<id>?param=1"
   */
  path: string;
  /**
   * The list of errors that occurred
   * @example ["User does not have permission to access this resource"]
   */
  errors: string[];
}
