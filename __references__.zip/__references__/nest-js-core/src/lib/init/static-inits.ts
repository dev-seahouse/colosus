import { Logger } from '@nestjs/common';

export function staticInitialisation(logger: Logger) {
  logger.log('Applying static initialisation');

  // Apply any global monkey patches here
}
