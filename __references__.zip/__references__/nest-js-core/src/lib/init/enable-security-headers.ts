import { INestApplication, Logger } from '@nestjs/common';
import helmet from 'helmet';
import { ServerConfiguration } from '../modules';

export function enableSecurityHeaders(
  logger: Logger,
  app: INestApplication,
  config: ServerConfiguration
) {
  logger.log('Enabling helmet');
  const isDevelopmentMode = process.env.NODE_ENV === 'development';

  app.use(
    helmet({
      contentSecurityPolicy: {
        useDefaults: true,
        directives: {
          'frame-ancestors': [`'none'`],
          defaultSrc: [`'self'`, `${config.host}`],
          styleSrc: [
            `'self'`,
            `'sha256-/jDKvbQ8cdux+c5epDIqkjHbXDaIY8RucT1PmAe8FG4='`,
            `'sha256-eaPyLWVdqMc60xuz5bTp2yBRgVpQSoUggte1+40ONPU='`,
            `'sha256-ezdv1bOGcoOD7FKudKN0Y2Mb763O6qVtM8LT2mtanIU='`,
          ],
          imgSrc: [`'self'`, 'data:'],
          scriptSrc: [`'self'`],
          // Disable upgrading http to https in dev mode
          upgradeInsecureRequests: isDevelopmentMode ? null : [],
        },
      },
      frameguard: {
        action: 'deny',
      },
      hsts: {
        maxAge: 15552000,
        includeSubDomains: true,
      },
    })
  );
}
