import { ApiProperty } from '@nestjs/swagger';

export class Fake {
  @ApiProperty({ type: String })
  id: string;
}
