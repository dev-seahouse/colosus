import { Fake as _Fake } from './fake';

export namespace PrismaModel {
  export class Fake extends _Fake {}

  export const extraModels = [Fake];
}
