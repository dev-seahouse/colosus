import { useApplication } from '../../hooks';

/**
 * Helper hook to extract the proper auth context
 */
export default function useAuthorisation() {
  const { getAuthContext } = useApplication();
  return getAuthContext();
}
