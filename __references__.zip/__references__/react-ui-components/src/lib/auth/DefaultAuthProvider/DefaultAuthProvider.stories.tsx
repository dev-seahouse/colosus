import { Meta, Story } from '@storybook/react';
import { AuthProviderProps } from '../../types';
import {
  DefaultAuthProvider as Component,
  useDefaultAuthorisation,
} from './DefaultAuthProvider';

const meta: Meta = {
  component: Component,
  argTypes: {},
  parameters: {
    controls: { expanded: true },
  },
};

export default meta;

function TestContent() {
  const stuff = useDefaultAuthorisation();
  return (
    <div>
      <div>persist: {stuff.persist}</div>
      <div>auth: {JSON.stringify(stuff.auth)}</div>
    </div>
  );
}

const Template: Story<AuthProviderProps> = (args) => (
  <Component {...args}>
    <TestContent />
  </Component>
);

export const DefaultAuthProvider = Template.bind({});
DefaultAuthProvider.args = {};
