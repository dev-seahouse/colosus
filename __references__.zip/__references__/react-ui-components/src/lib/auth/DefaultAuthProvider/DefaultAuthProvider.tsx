import { _ } from '@bambu/js-core';
import { createContext, useCallback, useContext, useState } from 'react';
import {
  AuthContextProps,
  AuthPaths,
  AuthProviderProps,
  AuthState,
} from '../../types';
import DefaultAuthGuard, { DefaultAuthGuardProps } from '../DefaultAuthGuard';

const AuthContext = createContext<AuthContextProps>({} as AuthContextProps);

export function useDefaultAuthorisation() {
  return useContext(AuthContext);
}

export function DefaultAuthProvider({
  children,
  paths = {},
}: AuthProviderProps) {
  const [auth, setAuth] = useState<AuthState>({});
  const [persist, setPersist] = useState<boolean>(
    JSON.parse(localStorage.getItem('persist') || 'false')
  );

  const [authPaths] = useState<AuthPaths>(
    _.merge(
      {},
      {
        login: '/login',
        unauthorised: '/unauthorised',
        logout: '/logout',
      },
      paths
    )
  );

  const isInRole = useCallback(
    (roles: string[]) => {
      if (!auth || !auth.user) {
        return false;
      }
      return false;
    },
    [auth]
  );

  const logoutUser = (accessToken?: string) => {
    console.log('redirect to logout page');
  };

  return (
    <AuthContext.Provider
      value={{
        auth,
        setAuth,
        persist,
        setPersist,
        GuardComponent: ({
          roles,
          ...rest
        }: Omit<DefaultAuthGuardProps, 'paths'>) => (
          <DefaultAuthGuard paths={authPaths} roles={roles} {...rest} />
        ),
        isInRole,
        logoutUser,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
}

export default DefaultAuthProvider;
