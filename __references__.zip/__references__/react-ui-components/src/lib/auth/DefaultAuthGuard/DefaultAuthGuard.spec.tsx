import { render } from '@testing-library/react';
import { MemoryRouter } from 'react-router-dom';
import { AppContextComponent } from '../../application';

import Component from './DefaultAuthGuard';

describe('DefaultAuthGuard', () => {
  it('should render successfully', () => {
    const { baseElement } = render(
      <AppContextComponent
        config={{
          author: {
            logo: 'a logo',
            name: 'a name',
            url: 'a url',
          },
          logo: 'a logo',
          name: 'an app name',
        }}
        themes={[]}
        getAuthContext={() => {
          return {
            auth: {},
            setAuth: () => ({}),
            persist: false,
            setPersist: () => ({}),
            GuardComponent: () => {
              return null;
            },
            isInRole: (roles: string[]) => {
              return false;
            },
            logoutUser: () => ({}),
          };
        }}
      >
        <MemoryRouter>
          <Component
            roles={[]}
            paths={{
              unauthorised: '/',
              login: '/',
            }}
          />
        </MemoryRouter>
      </AppContextComponent>
    );
    expect(baseElement).toBeTruthy();
  });
});
