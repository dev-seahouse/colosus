import { Suspense } from 'react';
import { Navigate, Outlet, useLocation } from 'react-router-dom';
import { Loader, SuspenseLoader } from '../../progress';
import { AuthGuardProps, AuthPaths } from '../../types';
import useAuthorisation from '../useAuthorisation';

export type DefaultAuthGuardProps = AuthGuardProps & {
  paths: AuthPaths;
};

export function DefaultAuthGuard({ roles, paths }: AuthGuardProps) {
  const location = useLocation();
  const { auth = {}, isInRole } = useAuthorisation();
  const { user } = auth;
  const { login, unauthorised } = paths;
  const externalLogin = login.startsWith('http');

  // Prevent looping
  const isInGuard =
    location.pathname.endsWith(unauthorised) ||
    location.pathname.endsWith(login);

  // Just for clarity on the code
  const isAuthenticated = Boolean(user);

  // If we are redirecting to an external login, update the location
  if (!isAuthenticated && externalLogin) {
    window.location.href = login;
    return null;
  } else {
    return isInGuard || isInRole(roles) ? (
      // The user has the appropriate role assigned
      <SuspenseLoader>
        <Outlet />
      </SuspenseLoader>
    ) : (
      <Navigate
        to={
          user
            ? // There is a user but they are not authorised for this page
              unauthorised
            : // There is no user so ask them to log in
              login
        }
        state={{
          from: location,
        }}
        replace
      />
    );
  }
}

export default DefaultAuthGuard;
