import { Typography } from '@mui/material';
import { Meta, Story } from '@storybook/react';
import { useContext, useRef } from 'react';
import { MemoryRouter, Route, Routes, useNavigate } from 'react-router-dom';
import { AppContext, AppContextComponent } from '../../application/App';
import { Button } from '../../buttons';
import { Container } from '../../containers';
import { AuthState } from '../../types';
import {
  DefaultAuthGuard as Component,
  DefaultAuthGuardProps,
} from './DefaultAuthGuard';

const meta: Meta = {
  component: Component,
  argTypes: {},
  parameters: {
    controls: { expanded: true },
  },
};

export default meta;

function AuthorisationComponent({
  state = 'UNAUTHORISED',
}: {
  state: 'LOGGED_IN' | 'LOGGED_OUT' | 'AUTHORISED' | 'UNAUTHORISED';
}) {
  const navigate = useNavigate();
  const { getAuthContext } = useContext(AppContext);

  const { setAuth, auth } = getAuthContext();
  const { user } = auth;

  return (
    <Container>
      {state === 'UNAUTHORISED' && (
        <>
          <div>
            {`Sorry ${user?.name}, you are not authorised for this page`}
          </div>
          <Button
            onClick={() => {
              setAuth({});
              navigate('/');
            }}
          >
            Sign out
          </Button>
        </>
      )}
      {state === 'AUTHORISED' && (
        <>
          <div>{`Hey, look at that ${user?.name}, you are authorised!`}</div>
          <Button
            onClick={() => {
              setAuth({
                token: 'a token',
                user: {
                  name: 'A test user',
                  roles: [
                    {
                      code: 'a different role code',
                      id: 'a different role id',
                      name: 'a different role',
                    },
                  ],
                  id: 'a user id',
                },
              });
              navigate('/');
            }}
          >
            Try an unauthorised page
          </Button>
          <Button
            onClick={() => {
              setAuth({});
              navigate('/');
            }}
          >
            Sign out
          </Button>
        </>
      )}
      {state === 'LOGGED_OUT' && (
        <>
          <Typography>You are logged out</Typography>
          <Button
            onClick={() => {
              setAuth({
                token: 'a token',
                user: {
                  name: 'A test user',
                  roles: [
                    {
                      code: 'a role code',
                      id: 'a role id',
                      name: 'a role',
                    },
                  ],
                  id: 'a user id',
                },
              });
              navigate('/');
            }}
          >
            Sign In
          </Button>
        </>
      )}
    </Container>
  );
}

const Template: Story<DefaultAuthGuardProps> = (args, { parameters }) => {
  const { appConfig: config, themes } = parameters;

  const authRef = useRef<AuthState>({});

  return (
    <AppContextComponent
      config={config}
      themes={themes}
      getAuthContext={() => {
        return {
          auth: authRef.current,
          setAuth: (auth) => {
            authRef.current = auth as AuthState;
          },
          persist: false,
          setPersist: () => ({}),
          GuardComponent: () => {
            return null;
          },
          isInRole: (roles: string[]) => {
            return Boolean(
              authRef.current.user?.roles &&
                authRef.current.user?.roles[0].id === 'a role id'
            );
          },
          logoutUser: () => ({}),
        };
      }}
    >
      <MemoryRouter initialEntries={['/']}>
        <Routes>
          <Route element={<Component {...args} />}>
            <Route
              index={true}
              element={<AuthorisationComponent state={'AUTHORISED'} />}
            />
          </Route>
          <Route
            path="login"
            element={<AuthorisationComponent state={'LOGGED_OUT'} />}
          />
          <Route
            path="logout"
            element={<AuthorisationComponent state={'LOGGED_IN'} />}
          />
          <Route
            path="unauthorised"
            element={<AuthorisationComponent state={'UNAUTHORISED'} />}
          />
        </Routes>
      </MemoryRouter>
    </AppContextComponent>
  );
};

export const DefaultAuthGuard = Template.bind({});
DefaultAuthGuard.args = {
  paths: {
    login: 'login',
    logout: 'logout',
    unauthorised: 'unauthorised',
  },
};
