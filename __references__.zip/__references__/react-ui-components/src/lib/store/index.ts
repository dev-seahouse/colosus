export { default as getApplicationReducers } from './getApplicationReducers';
export { reduxConfig } from './slices';
export * from './getApplicationReducers';
export * from './hooks';
export * from './createStore';

export { actions as ACTIONS } from './slices';
