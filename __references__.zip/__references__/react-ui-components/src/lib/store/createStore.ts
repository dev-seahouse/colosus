import { configureStore, ReducersMapObject } from '@reduxjs/toolkit';
import { getApplicationReducers, reduxConfig } from '../store';

export type CreateStoreProps = {
  reducers?: ReducersMapObject;
};

export function createStore({ reducers }: CreateStoreProps) {
  return configureStore({
    middleware: (getDefaultMiddleware) =>
      getDefaultMiddleware({
        // There are some actions that are non serialisable
        serializableCheck: reduxConfig.reduxSerializableConfig,
      }),
    reducer: {
      ...getApplicationReducers(),
      ...reducers,
    },
  });
}

export default createStore;
export type RootState = ReturnType<ReturnType<typeof createStore>['getState']>;
export type AppDispatch = ReturnType<
  ReturnType<typeof createStore>['dispatch']
>;
