import type { TypedUseSelectorHook } from 'react-redux';
import { useDispatch, useSelector } from 'react-redux';
import { LayoutDefinition } from '../types';
import { AppDispatch, RootState } from './createStore';
import { ContextPanelStore } from './slices/contextPanel.slice';
import { DialogStore } from './slices/dialog.slice';
import { MessageStore } from './slices/message.slice';
import { SettingsStore } from './slices/settings.slice';

export const useAppDispatch: () => AppDispatch = useDispatch;
export const useAppSelector: TypedUseSelectorHook<RootState> = useSelector;

export function useLayoutSelector<T extends LayoutDefinition>(name: string) {
  return useSettingsSelector().current.layouts[name] as T;
}

export function useSettingsSelector() {
  return useAppSelector((state) => {
    return state['bambu/settings'] as SettingsStore;
  });
}

export function useDialogSelector() {
  return useAppSelector((state) => {
    return state['bambu/dialog'] as DialogStore;
  });
}

export function useContextPanelSelector() {
  return useAppSelector((state) => {
    return state['bambu/contextPanel'] as ContextPanelStore;
  });
}

export function useMessageSelector() {
  return useAppSelector((state) => {
    return state['bambu/message'] as MessageStore;
  });
}
