import { render } from '@testing-library/react';

import Component from './Actions';

describe(Component.name, () => {
  test.todo('test this');
  // it('should render successfully', () => {
  //   const { baseElement } = render(<Component />);
  //   expect(baseElement).toBeTruthy();
  // });
});
