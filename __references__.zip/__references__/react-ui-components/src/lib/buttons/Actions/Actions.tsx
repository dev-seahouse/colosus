import { ReactNode } from 'react';
import { makeStyles } from 'tss-react/mui';
import { useMemoDeepCompare } from '../../hooks';
import { BaseComponent, ComponentColor } from '../../types';
import Button, { ButtonProps } from '../Button';
import IconButton, { IconButtonProps } from '../IconButton';
import { mostReadable, tinycolor } from '@bambu/js-core';

type StyleProps = {
  count: number;
};

const useStyles = makeStyles<StyleProps>()((theme, { count }) => {
  const columnTemplate = Array(count).fill('auto').join(' ');
  return {
    root: {
      display: 'grid',
      gridTemplateColumns: columnTemplate,
      gap: theme.spacing(1),
      alignItems: 'center',

      [theme.breakpoints.down('sm')]: {
        gridTemplateColumns: 'auto',
        justifyItems: 'end',
        alignItems: 'start',
      },
    },
    action: {},
    action_iconButton: {},
    action_button: {
      [theme.breakpoints.down('sm')]: {
        width: '100%',
      },
    },
    action_color_inherit: {},
    action_color_default: {},
    action_color_action: {},
    action_color_disabled: {},
    action_color_primary: {
      color: `${mostReadable(
        tinycolor(theme.palette.background.paper),
        [
          theme.palette.primary.light,
          theme.palette.primary.main,
          theme.palette.primary.dark,
        ],
        {}
      )?.toHex8String()}`,
    },
    action_color_secondary: {
      color: `${mostReadable(
        tinycolor(theme.palette.background.paper),
        [
          theme.palette.secondary.light,
          theme.palette.secondary.main,
          theme.palette.secondary.dark,
        ],
        {}
      )?.toHex8String()}`,
    },
    action_color_error: {
      color: `${mostReadable(
        tinycolor(theme.palette.background.paper),
        [
          theme.palette.error.light,
          theme.palette.error.main,
          theme.palette.error.dark,
        ],
        {}
      )?.toHex8String()}`,
    },
    action_color_info: {
      color: `${mostReadable(
        tinycolor(theme.palette.background.paper),
        [
          theme.palette.info.light,
          theme.palette.info.main,
          theme.palette.info.dark,
        ],
        {}
      )?.toHex8String()}`,
    },
    action_color_success: {
      color: `${mostReadable(
        tinycolor(theme.palette.background.paper),
        [
          theme.palette.success.light,
          theme.palette.success.main,
          theme.palette.success.dark,
        ],
        {}
      )?.toHex8String()}`,
    },
    action_color_warning: {
      color: `${mostReadable(
        tinycolor(theme.palette.background.paper),
        [
          theme.palette.warning.light,
          theme.palette.warning.main,
          theme.palette.warning.dark,
        ],
        {}
      )?.toHex8String()}`,
    },
  };
});

export interface ActionsProps
  extends BaseComponent<
    'span',
    Partial<ReturnType<typeof useStyles>['classes']>
  > {
  actions: (
    | Omit<ButtonProps, 'children'>
    | IconButtonProps
    | (() => ReactNode)
  )[];
  variant?: 'iconButton' | 'button';
}

export function Actions({
  className,
  style,
  classes: classesProp,
  variant = 'iconButton',
  actions,
}: ActionsProps) {
  const { classes, cx } = useStyles(
    {
      count: actions.length,
    },
    {
      props: {
        classes: classesProp,
      },
    }
  );

  const renderedActions = useMemoDeepCompare(() => {
    return actions.map((action) => {
      const ActionComponent: any =
        variant === 'iconButton' ? IconButton : Button;
      const actionColor: ComponentColor = (action as any).color || 'primary';

      return typeof action !== 'function' ? (
        <ActionComponent
          key={action.key || action.title || action.name}
          color={variant === 'iconButton' ? 'inherit' : actionColor}
          variant={action.variant || 'text'}
          {...action}
          className={cx(
            classes.action,
            classes[`action_${variant}`],
            classes[`action_color_${actionColor}`],
            (action as any).className
          )}
          children={action.title}
        />
      ) : (
        action()
      );
    });
  }, [actions, variant]);

  return (
    <div className={cx(classes.root, className)} style={style}>
      {renderedActions}
    </div>
  );
}

export default Actions;
