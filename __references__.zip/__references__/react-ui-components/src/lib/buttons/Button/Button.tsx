import {
  Button as NativeButton,
  ButtonProps as NativeProps,
} from '@mui/material';
import { makeStyles } from 'tss-react/mui';
import Icon from '../../icons/Icon';
import { ComponentColor } from '../../types';

const useStyles = makeStyles()((theme) => {
  return {
    root: {},
    variantPill: {
      borderRadius: '500px',
    },
    noContentMargin: {
      '& .MuiButton-startIcon, & .MuiButton-endIcon': {
        marginLeft: 0,
        marginRight: 0,
      },
    },
  };
});

// eslint-disable-next-line @typescript-eslint/no-empty-interface
export interface ButtonProps
  extends Omit<NativeProps, 'startIcon' | 'endIcon' | 'color' | 'variant'> {
  /**
   * The icon to display.
   */
  icon?: string;
  /**
   * The positioning of the icon
   */
  iconPosition?: 'start' | 'end';
  /**
   * Overrides the classes defined in the component
   */
  classes?: Partial<ReturnType<typeof useStyles>['classes']>;
  /**
   * The color of the component
   */
  color?: ComponentColor;
  /**
   * The variant of the button to show
   */
  variant?: NativeProps['variant'] | 'pill';
}

export function Button({
  className,
  children,
  variant = 'contained',
  icon,
  iconPosition = 'start',
  style,
  color = 'primary',
  size = 'medium',
  classes: classesProp,
  ...rest
}: ButtonProps) {
  const { classes, cx } = useStyles(undefined, {
    props: {
      classes: classesProp,
    },
  });

  return (
    <NativeButton
      className={cx(
        classes.root,
        className,
        !children && classes.noContentMargin,
        variant === 'pill' && classes.variantPill
      )}
      style={style}
      variant={variant === 'pill' ? 'contained' : variant}
      color={color as NativeProps['color']}
      size={size}
      startIcon={icon && iconPosition === 'start' && <Icon>{icon}</Icon>}
      endIcon={icon && iconPosition === 'end' && <Icon>{icon}</Icon>}
      {...rest}
    >
      {children}
    </NativeButton>
  );
}

export default Button;
