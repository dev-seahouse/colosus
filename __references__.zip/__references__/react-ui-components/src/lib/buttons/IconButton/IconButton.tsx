import {
  IconButton as NativeButton,
  IconButtonProps as NativeProps,
  Tooltip,
} from '@mui/material';
import { makeStyles } from 'tss-react/mui';
import Icon from '../../icons/Icon';

import { ComponentColor, ComponentSize } from '../../types';

type StyleProps = {
  size: ComponentSize;
  color: ComponentColor;
};

const useStyles = makeStyles<StyleProps>()((theme, { size, color }) => {
  // As we want width and height to be equal same we need to parse size
  const sizes: {
    [key: string]: string;
  } = {
    inherit: '1.3em',
    small: theme.typography.pxToRem(20 + 8),
    medium: theme.typography.pxToRem(24 + 8),
    large: theme.typography.pxToRem(36 + 8),
  };

  let palette: {
    main: string;
    contrastText?: string;
  } | null = null;
  if (color === 'disabled') {
    palette = {
      main: theme.palette.action.disabled,
      contrastText: theme.palette.getContrastText(theme.palette.action.active),
    };
  } else if (color === 'action') {
    palette = {
      main: theme.palette.action.active,
      contrastText: theme.palette.getContrastText(theme.palette.action.active),
    };
  } else if (color !== 'inherit') {
    palette = theme.palette[color];
  }

  return {
    root: {
      cursor: 'default',
    },
    icon: {},
    iconBtn: {
      width: sizes[size],
      height: sizes[size],
    },
    root_text: {
      color: palette?.main ? `${palette.main} !important` : undefined,
    },
    root_contained: {
      backgroundColor: palette?.main ? `${palette.main} !important` : undefined,
      color: palette?.contrastText
        ? `${palette.contrastText} !important`
        : undefined,
    },
    root_outlined: {
      borderWidth: 'thin',
      borderStyle: 'solid',
      borderColor: palette?.main ? `${palette.main} !important` : undefined,
      color: palette?.main ? `${palette.main} !important` : undefined,
    },
  };
});

export interface IconButtonProps
  extends Omit<NativeProps, 'size' | 'color' | 'title' | 'icon'> {
  /**
   * The text provided here is used as both the tooltip and the aria-label
   */
  title?: string;
  /**
   * Specify the color of the icon
   */
  color?: ComponentColor;
  /**
   * The size of the control
   */
  size?: ComponentSize;
  /**
   * The icon to display.
   */
  icon?: string;
  /**
   * The variant of the button
   */
  variant?: 'text' | 'contained' | 'outlined';
  /**
   * Overrides the classes defined in the component
   */
  classes?: Partial<ReturnType<typeof useStyles>['classes']>;
}

export function IconButton({
  className,
  title,
  icon,
  style,
  color = 'primary',
  size = 'medium',
  variant = 'text',
  id,
  classes: classesProp,
  ...rest
}: IconButtonProps) {
  const { classes, cx } = useStyles(
    {
      size,
      color,
    },
    {
      props: {
        classes: classesProp,
      },
    }
  );

  return (
    <Tooltip title={title || ''}>
      {
        // Span is required here for the tooltip to work correctly
      }
      <span id={id} className={cx(classes.root)}>
        <NativeButton
          className={cx(classes.iconBtn, classes[`root_${variant}`], className)}
          aria-label={title}
          style={style}
          color="inherit"
          {...rest}
        >
          <Icon size={size} color="inherit" className={cx(classes.icon)}>
            {icon}
          </Icon>
        </NativeButton>
      </span>
    </Tooltip>
  );
}

export default IconButton;
