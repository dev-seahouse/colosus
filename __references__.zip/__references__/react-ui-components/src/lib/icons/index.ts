export { default as Icon } from './Icon/Icon';
export * from './Icon';
