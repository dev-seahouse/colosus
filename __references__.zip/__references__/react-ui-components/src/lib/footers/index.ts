export { default as Footer } from './Footer/Footer';
export * from './Footer';
