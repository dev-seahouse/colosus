import { Meta, Story } from '@storybook/react';
import { Footer as Component, FooterProps } from './Footer';

const meta: Meta = {
  component: Component,
  argTypes: {
    children: {
      control: {
        type: 'text',
      },
    },
  },
  parameters: {
    controls: { expanded: true },
  },
};

export default meta;

const Template: Story<FooterProps> = (args) => <Component {...args} />;

export const Footer = Template.bind({});
Footer.args = {};
