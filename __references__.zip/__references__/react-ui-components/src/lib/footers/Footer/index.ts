export { default as Footer } from './Footer';
export * from './Footer';
