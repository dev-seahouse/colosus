import { Meta, Story } from '@storybook/react';
import {
  EntityViewForm as Component,
  EntityViewFormProps,
} from './EntityViewForm';

const meta: Meta = {
  component: Component,
  argTypes: {},
  parameters: {
    controls: { expanded: true },
  },
};

export default meta;

const Template: Story<EntityViewFormProps> = (args) => <Component {...args} />;

export const EntityViewForm = Template.bind({});
EntityViewForm.args = {};
