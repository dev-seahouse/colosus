import { CSSObject } from '@emotion/react';
import { I18NArguments } from '@bambu/js-core';
import { Typography } from '@mui/material';
import {
  FormEvent,
  ReactNode,
  useContext,
  useEffect,
  useRef,
  useState,
} from 'react';
import { makeStyles } from 'tss-react/mui';
import { Button } from '../../buttons';
import { Error } from '../../errors';
import { LocalizationContext } from '../../i18n';
import { Loader } from '../../progress';
import { BaseComponent, ComponentAlignmentHorizontal } from '../../types';
import EntityView, {
  EntityViewProps,
  EntityViewRef,
} from '../EntityView/EntityView';
import Form from '../Form';

type StyleProps = {
  alignTitle: ComponentAlignmentHorizontal;
};
const useStyles = makeStyles<StyleProps>()((theme, { alignTitle }) => {
  const headerAlignment =
    alignTitle === 'center'
      ? alignTitle
      : alignTitle === 'left'
      ? 'flex-start'
      : 'flex-end';
  return {
    root: {
      display: 'flex',
      flexDirection: 'column',
      width: theme.spacing(48),
      maxWidth: '100%',
      overflow: 'hidden',
    },
    header: {
      flexShrink: 0,
      flexGrow: 0,
      display: 'flex',
      flexDirection: 'column',
      alignItems: headerAlignment,
      textAlign: alignTitle,
    },
    form: {
      display: 'flex',
      flexDirection: 'column',
      flexShrink: 1,
      flexGrow: 1,
      maxHeight: '100%',
      overflow: 'hidden',
    },
    form_dense: {
      flexGrow: 0,
    },
    entityView: {
      flexShrink: 0,
      overflow: 'auto',
    },
    title: {
      ...(theme.typography.h6 as CSSObject),
      textTransform: 'uppercase',

      marginTop: theme.spacing(1),
      marginBottom: theme.spacing(3),

      [theme.breakpoints.up('sm')]: {
        marginTop: theme.spacing(2),
        marginBottom: theme.spacing(4),
      },
    },
    spacer: {
      minHeight: theme.spacing(1),
      flexGrow: 1,
    },
    spacer_dense: {
      flexGrow: 0,
      flexShrink: 1,
    },
    actions: {
      flexShrink: 1,
      flexGrow: 0,
    },
    footer: {
      paddingTop: theme.spacing(1),
      flexGrow: 0,
      flexShrink: 0,
      display: 'flex',
      flexDirection: 'column',
    },
    error: {
      width: '100%',
      borderRadius: theme.shape.borderRadius,
      borderColor: theme.palette.error.main,
      borderStyle: 'solid',
      borderWidth: 'thin',
      marginBottom: theme.spacing(0.5),
      padding: theme.spacing(0.5),
    },
  };
});

export interface EntityViewFormProps
  extends Omit<
    BaseComponent<'div', Partial<ReturnType<typeof useStyles>['classes']>>,
    'onSubmit'
  > {
  model: EntityViewProps['model'];
  onSubmit: (event: FormEvent, callback?: (err?: unknown) => void) => void;
  variant?: 'filled' | 'outlined' | 'standard';
  dense?: boolean;
  title?: string;
  header?: ReactNode;
  footer?: ReactNode;
  submit?: string | ReactNode;
  alignTitle?: ComponentAlignmentHorizontal;
  errors?: I18NArguments[] | null;
  onChange?: (data: any) => void;
  value?: any;
  processing?: boolean;
  readonly?: boolean;
}

export function EntityViewForm({
  className,
  style,
  classes: classesProp,
  onSubmit,
  model,
  variant = 'standard',
  dense = true,
  title = '',
  header,
  footer,
  submit = 'submit',
  alignTitle = 'left',
  errors,
  onChange,
  value,
  processing = false,
  readonly = false,
}: EntityViewFormProps) {
  const { classes, cx } = useStyles(
    {
      alignTitle,
    },
    {
      props: {
        classes: classesProp,
      },
    }
  );

  const entityViewRef = useRef<EntityViewRef>(null);
  const [canSubmit, setCanSubmit] = useState(false);
  const [isProcessing, setIsProcessing] = useState(processing);
  const { t } = useContext(LocalizationContext);

  const errorRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (errors && errors.length > 0) {
      // Set focus to the error div for screen readers
      errorRef?.current?.focus();
    }
  }, [errors]);

  const resolvedProcessing = isProcessing || processing;

  return (
    <div className={cx(classes.root, className)} style={style}>
      {header}
      <div className={cx(classes.header)}>
        {title && (
          <Typography
            variant="h1"
            component="div"
            className={cx(classes.title)}
          >
            {t(title)}
          </Typography>
        )}
        {errors && errors.length > 0 && (
          <div ref={errorRef} className={cx(classes.error)}>
            <Error size="small">{t(...errors[0])}</Error>
          </div>
        )}
      </div>
      <Form
        className={cx(classes.form, dense && classes.form_dense)}
        onSubmit={(e) => {
          e.preventDefault();
          setIsProcessing(true);
          entityViewRef?.current?.handleSubmit(e, onSubmit, (err) => {
            setIsProcessing(false);
            if (!err) {
              entityViewRef.current?.resetForm();
            }
          });
        }}
      >
        <EntityView
          value={value}
          className={cx(classes.entityView)}
          onChange={(data) => {
            setCanSubmit(entityViewRef?.current?.isValid() || false);
            onChange && onChange(data);
          }}
          readonly={readonly}
          ref={entityViewRef}
          model={model}
          dense={dense}
          editorVariant={variant}
        />

        <div className={cx(classes.spacer, dense && classes.spacer_dense)} />

        <div className={cx(classes.actions)}>
          {!resolvedProcessing ? (
            typeof submit === 'string' ? (
              <Button type="submit" fullWidth disabled={!canSubmit || readonly}>
                {t(submit)}
              </Button>
            ) : (
              submit
            )
          ) : (
            <Loader variant="circular" />
          )}
        </div>
      </Form>

      <div className={cx(classes.footer)}>{footer}</div>
    </div>
  );
}

export default EntityViewForm;
