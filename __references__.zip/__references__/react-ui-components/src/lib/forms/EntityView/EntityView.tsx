import {
  FormEvent,
  FormEventHandler,
  forwardRef,
  useCallback,
  useEffect,
  useImperativeHandle,
  useMemo,
} from 'react';
import { makeStyles } from 'tss-react/mui';
import { useForm } from '../../hooks';
import { BaseComponent } from '../../types';
import { Field, isComponentField, Model } from '../../utilities';
import { getComponent } from './fields';
import { FieldComponentProps } from './types/field-component.interface';

export type EntityViewRef = {
  validate: Model['validate'] | undefined;
  isValid: (fields?: string | string[]) => boolean;
  handleSubmit: (
    event: FormEvent,
    data: any,
    callback?: (err?: unknown) => void
  ) => void;
  resetForm: () => void;
};

type StyleProps = {
  dense: boolean;
  gridTemplateAreas: string;
};

const useStyles = makeStyles<StyleProps>()(
  (theme, { dense, gridTemplateAreas }) => {
    return {
      root: {
        display: 'grid',
        width: '100%',
        minHeight: dense ? 'auto' : '100%',
        gap: theme.spacing(1),
        paddingTop: theme.spacing(1),
        paddingBottom: theme.spacing(1),
        gridTemplateAreas: gridTemplateAreas,

        [theme.breakpoints.down('sm')]: {
          gridTemplateAreas: 'unset',
          gridTemplateColumns: '100%',
        },
      },
      componentFieldWrapper: {
        width: '100%',
        [theme.breakpoints.down('sm')]: {
          gridArea: 'unset !important',
        },
      },
    };
  }
);

export interface EntityViewProps<T = any>
  extends Omit<
    BaseComponent<'span', Partial<ReturnType<typeof useStyles>['classes']>>,
    'onChange'
  > {
  value?: T;
  model: Model;
  readonly?: boolean;
  dense?: boolean;
  editorVariant?: FieldComponentProps['editorVariant'];
  onChange?: (value: Partial<T>) => void;
}

type EntityViewGridLayout = {
  rows: number;
  columns: number;
  layout: string[][];
  gridAreas: string[];
  gridTemplateAreas: string;
};

export const EntityView = forwardRef<
  EntityViewRef,
  EntityViewProps<Record<string, any>>
>(
  (
    {
      className,
      style,
      classes: classesProp,
      model,
      dense = false,
      editorVariant = 'outlined',
      readonly = false,
      value,
      onChange,
    },
    ref
  ) => {
    const {
      form,
      handleChange,
      errors: validationErrors,
      validate,
      isValid,
      handleSubmit,
      resetForm,
    } = useForm(value || model.generateModel(), model.validate);

    const onHandleSubmit = useCallback(
      (e: FormEvent, onSubmit?: FormEventHandler, callback?: () => void) => {
        if (isValid()) {
          handleSubmit(e, onSubmit, callback);
        }
      },
      [handleSubmit, isValid]
    );

    useImperativeHandle(
      ref,
      () => ({
        validate: validate,
        isValid: isValid,
        handleSubmit: onHandleSubmit,
        resetForm: resetForm,
      }),
      [validate, isValid, onHandleSubmit, resetForm]
    );

    useEffect(() => {
      onChange && onChange(form);
      // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [form]);

    const gridLayout: EntityViewGridLayout = useMemo(() => {
      // Extract columns/rows and fields
      const layout = model.layout.reduce(
        (acc: EntityViewGridLayout, row) => {
          if (row.length > acc.columns) {
            acc.columns = row.length;
          }
          // Extract the ID of the field
          acc.layout.push(row.map((r) => r));
          row.forEach((f) => {
            acc.gridAreas.push(f);
          });
          return acc;
        },
        {
          rows: model.layout.length,
          columns: 0,
          layout: [],
          gridTemplateAreas: '',
          gridAreas: [],
        }
      );

      // Define the grid template areas
      layout.gridTemplateAreas = layout.layout
        .map((l) => {
          return `'${Array.from({
            ...l,
            length: layout.columns,
          })
            .map((c) => c || '.')
            .join(' ')}'`;
        })
        .join(' ');

      // Make sure the grid areas are unique
      layout.gridAreas = layout.gridAreas.filter(
        (v, i) => !layout.gridAreas.includes(v, i + 1)
      );

      return layout;
    }, [model]);

    const { classes, cx } = useStyles(
      {
        dense,
        gridTemplateAreas: gridLayout.gridTemplateAreas,
      },
      {
        props: {
          classes: classesProp,
        },
      }
    );

    // Generate the controls separately as they may change based on the values
    const fields = useMemo(() => {
      return gridLayout.gridAreas.map((fieldName) => {
        const field: Field = model.fields[fieldName];
        if (isComponentField(field)) {
          return (
            <div
              key={field.id}
              className={cx(classes.componentFieldWrapper)}
              style={{
                gridArea: fieldName,
              }}
            >
              {field.render()}
            </div>
          );
        } else {
          const Component = getComponent(field);
          return (
            <Component
              key={`${field.type}|${field.label}`}
              className={cx(classes.componentFieldWrapper)}
              field={field}
              dense={dense}
              editorVariant={editorVariant}
              value={form[field.id]}
              onChange={handleChange}
              readonly={readonly || field.readonly}
              errors={validationErrors[field.id]}
              {...field.componentProps}
              style={{
                ...field.componentProps?.style,
                gridArea: fieldName,
              }}
            />
          );
        }
      });
      // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [
      gridLayout.gridAreas,
      model.fields,
      form,
      handleChange,
      validationErrors,
    ]);

    return (
      <div className={cx(classes.root, className)} style={style}>
        {fields}
      </div>
    );
  }
);

export default EntityView;
