import { Meta, Story } from '@storybook/react';
import { Container } from '../../containers';
import { createModel } from '../../utilities';
import { EntityView as Component, EntityViewProps } from './EntityView';
import {
  createEmailConstraint,
  createMatchConstraint,
  createNameConstraint,
  createPasswordConstraint,
  createURLConstraint,
} from './validations';

const meta: Meta = {
  component: Component,
  argTypes: {
    editorVariant: {
      control: 'radio',
      options: ['filled', 'standard', 'outlined'],
    },
  },
  parameters: {
    controls: {
      expanded: true,
    },
  },
};

export default meta;

const fullFeatureModel = {
  name: 'application',
  icon: 'display_settings',
  identityField: 'guid',
  fields: {
    name: {
      id: 'name',
      type: 'string',
      description: 'The name of this application',
      validations: [createNameConstraint()],
    },
    clienttype: {
      id: 'clienttype',
      label: 'Client Type',
      type: 'string',
      description: 'The type of this application',
    },
    privacyuri: {
      id: 'privacyuri',
      label: 'Privacy URL',
      type: 'url',
      description:
        'A link to the privacy policy that is applied to the application',
      validations: [createURLConstraint(true)],
    },
    defaultscope: {
      id: 'defaultscope',
      label: 'Default Scope',
      type: 'string',
      description: 'The authorisation scope to use if one is not provided',
    },
    hascredentials: {
      id: 'hascredentials',
      label: 'Has Credentials',
      type: 'boolean',
      readonly: true,
      description:
        'Indicates if client credentials have been created for this application',
    },
    description: {
      id: 'description',
      type: 'string',
      maxLength: 2048,
      description: 'The description for this application',
    },
    logouri: {
      id: 'logouri',
      label: 'Logo URL',
      type: 'url',
      description: 'The logo to display for this application',
      validations: [createURLConstraint(true)],
    },
    requiretermsaccepted: {
      id: 'requiretermsaccepted',
      label: 'Require Terms Accepted',
      type: 'boolean',
      default: true,
      description:
        'When registering for the application, must the user accept the terms and conditions',
    },
    companyid: {
      id: 'companyid',
      label: 'Organisation',
      type: 'string',
      description: 'The organisation that has ownership of this application',
    },
    websiteuri: {
      id: 'websiteuri',
      label: 'Website URL',
      type: 'url',
      description:
        'The default url to redirect to after user authorisation if a redirect_uri has not been set',
      validations: [createURLConstraint(true)],
    },
    backgrounduri: {
      id: 'backgrounduri',
      label: 'Background URL',
      type: 'url',
      description:
        'The background image to use when displaying this application',
      validations: [createURLConstraint(true)],
    },
    redirectionuris: {
      id: 'redirectionuris',
      label: 'RedirectionURLs',
      type: 'string',
      description:
        'The list of URIs that can be redirect to during authorisation',
    },
    billingemail: {
      id: 'billingemail',
      label: 'Billing Email',
      type: 'email',
      description:
        'The email address for the billing contact for this application',
      validations: [createEmailConstraint()],
    },
    adminemail: {
      id: 'adminemail',
      label: 'Admin Email',
      type: 'email',
      description:
        'The email address for the administrative contact for this application',
      validations: [createEmailConstraint()],
    },
    initialroleid: {
      id: 'initialroleid',
      label: 'Initial Role',
      type: 'string',
      description:
        'The role that a user should be added to when registering for an account',
    },
    termsuri: {
      id: 'termsuri',
      label: 'Terms URL',
      type: 'url',
      description:
        'A url to the terms and conditions that govern this application',
      validations: [createURLConstraint(true)],
    },
  },
};

const Template: Story<EntityViewProps> = (args) => {
  const baseModel = {
    name: 'register',
    fields: {
      username: {
        type: 'string',
        label: 'Display Name',
        required: true,
        description: 'This name will be seen by other users',
        componentProps: {
          autoFocus: true,
        },
        validations: [createNameConstraint()],
      },
      email: {
        type: 'email',
        required: true,
        validations: [createEmailConstraint()],
      },
      password: {
        type: 'password',
        required: true,
        minLength: 8,
        validations: [createPasswordConstraint()],
      },
      confirmPassword: {
        type: 'password',
        required: true,
        validations: [
          createMatchConstraint({
            matchFieldID: 'password',
          }),
        ],
      },
      acceptTandC: {
        type: 'boolean',
        required: true,
        label: 'Terms',
        componentProps: {
          style: {
            border: '1px solid white',
            borderRadius: 4,
            paddingLeft: 8,
          },
        },
      },
    },
  };

  const simpleModel = createModel(baseModel);

  const complicatedModel = createModel({
    ...baseModel,
    layout: [
      ['username', 'email'],
      ['password', 'confirmPassword'],
      ['acceptTandC'],
    ],
  });

  const complexModel = createModel({
    ...baseModel,
    layout: [
      ['username', 'email', 'acceptTandC'],
      ['password', 'confirmPassword', 'acceptTandC'],
    ],
  });

  let model = null;
  switch (args.datatype) {
    case 'complicated':
      model = complicatedModel;
      break;
    case 'complex':
      model = complexModel;
      break;
    case 'full':
      model = createModel({
        ...fullFeatureModel,
        layout: [
          // Info Header
          ['name', 'description'],
          ['companyid', 'description'],
          ['privacyuri', 'description'],
          ['websiteuri', 'description'],
          // Image Header
          ['logouri', 'backgrounduri'],
          // Contact Header
          ['billingemail', 'adminemail'],
          // Auth header
          ['clienttype', 'redirectionuris'],
          ['defaultscope', 'redirectionuris'],
          ['initialroleid', 'redirectionuris'],
          ['requiretermsaccepted', 'termsuri'],
          ['hascredentials'],
        ],
        listLayout: ['logouri', 'name', 'description', 'websiteuri'],
      });
      break;
    default:
      model = simpleModel;
  }

  return (
    <Container>
      <Component
        style={{
          overflow: 'auto',
        }}
        {...args}
        model={model}
      />
    </Container>
  );
};

export const EntityView = Template.bind({});
EntityView.args = {
  readonly: false,
  dense: true,
  editorVariant: 'outlined',
};

export const EntityViewComplicated = Template.bind({});
EntityViewComplicated.args = {
  readonly: false,
  dense: true,
  editorVariant: 'outlined',
  datatype: 'complicated',
};

export const EntityViewComplex = Template.bind({});
EntityViewComplex.args = {
  readonly: false,
  dense: true,
  editorVariant: 'outlined',
  datatype: 'complex',
};

export const EntityViewFullFeature = Template.bind({});
EntityViewFullFeature.args = {
  readonly: false,
  dense: true,
  editorVariant: 'outlined',
  datatype: 'full',
};
