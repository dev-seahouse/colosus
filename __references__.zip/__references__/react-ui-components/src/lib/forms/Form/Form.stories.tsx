import { Meta, Story } from '@storybook/react';
import { Form as Component, FormProps } from './Form';

const meta: Meta = {
  component: Component,
  argTypes: {},
  parameters: {
    controls: { expanded: true },
  },
};

export default meta;

const Template: Story<FormProps> = (args) => <Component {...args} />;

export const Form = Template.bind({});
Form.args = {};
