import { FormEventHandler } from 'react';
import { makeStyles } from 'tss-react/mui';
import { ContainerComponent } from '../../types';

const useStyles = makeStyles()((/*theme*/) => {
  return {
    root: {
      overflow: 'hidden',
      display: 'flex',
      flexDirection: 'column',
      maxWidth: '100%',
    },
  };
});

// eslint-disable-next-line @typescript-eslint/no-empty-interface
export interface FormProps
  extends Omit<
    ContainerComponent<
      'form',
      Partial<ReturnType<typeof useStyles>['classes']>
    >,
    'onSubmit'
  > {
  onSubmit: FormEventHandler;
}

export function Form({
  className,
  style,
  classes: classesProp,
  children,
  onSubmit,
}: FormProps) {
  const { classes, cx } = useStyles(undefined, {
    props: {
      classes: classesProp,
    },
  });

  return (
    <form
      className={cx(classes.root, className)}
      style={style}
      onSubmit={onSubmit}
    >
      {children}
    </form>
  );
}

export default Form;
