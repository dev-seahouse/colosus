import {
  Card as MuiCard,
  CardProps as MuiCardProps,
  CardActions,
  CardContent,
  Typography,
} from '@mui/material';
import { makeStyles } from 'tss-react/mui';
import { Actions, ActionsProps } from '../../buttons';
import { BaseComponent } from '../../types';
import CardHeader, { CardHeaderProps } from '../CardHeader';

const useStyles = makeStyles()((theme) => {
  return {
    root: {
      width: '100%',
      display: 'flex',
      flexDirection: 'column',
      overflow: 'hidden',
    },
    contentWrapper: {
      flexGrow: 1,
      flexShrink: 1,
      display: 'flex',
      flexDirection: 'column',
      width: '100%',
      overflow: 'hidden',
      padding: 0,
    },
    cardContent: {
      flexShrink: 1,
      flexGrow: 1,

      [theme.breakpoints.down('sm')]: {
        paddingTop: theme.spacing(1),
        paddingBottom: theme.spacing(1),
      },
    },
    description: {
      overflow: 'hidden',
      display: '-webkit-box',
      WebkitLineClamp: '3',
      WebkitBoxOrient: 'vertical',
    },
    cardActions: {
      marginLeft: theme.spacing(1),
    },
    actionWrapper: {
      width: '100%',
      display: 'flex',
      flexDirection: 'row',
      justifyContent: 'space-between',
    },
    actions: {
      [theme.breakpoints.down('sm')]: {
        alignItems: 'end',
      },
    },
    primaryActions: {},
    secondaryActions: {},
  };
});

export interface CardProps
  extends Omit<
    BaseComponent<'span', Partial<ReturnType<typeof useStyles>['classes']>>,
    'onClick'
  > {
  raised?: boolean;
  square?: boolean;
  elevation?: number;
  thumbnailImage?: CardHeaderProps['thumbnailImage'];
  headerActions?: CardHeaderProps['actions'];
  title: CardHeaderProps['title'];
  subtitle?: CardHeaderProps['subtitle'];
  emphasisText?: CardHeaderProps['emphasisText'];
  primaryActions?: ActionsProps['actions'];
  secondaryActions?: ActionsProps['actions'];
  showTitle?: boolean;
  onClick?: MuiCardProps['onClick'];
}

export function Card({
  className,
  style,
  classes: classesProp,
  square = false,
  elevation = 1,
  title,
  subtitle,
  emphasisText,
  thumbnailImage,
  headerActions,
  primaryActions,
  secondaryActions,
  showTitle = true,
  children,
  onClick,
}: CardProps) {
  const { classes, cx } = useStyles(undefined, {
    props: {
      classes: classesProp,
    },
  });

  const hasActions = Boolean(primaryActions || secondaryActions);

  const content =
    children && typeof children === 'string' ? (
      <CardContent className={cx(classes.cardContent)}>
        <Typography
          className={cx(classes.description)}
          variant="body2"
          color="textSecondary"
          component="p"
        >
          {children}
        </Typography>
      </CardContent>
    ) : (
      children
    );

  return (
    <MuiCard
      className={cx(classes.root, className)}
      style={style}
      square={square}
      elevation={elevation}
      onClick={onClick}
    >
      {showTitle && (
        <CardHeader
          title={title}
          subtitle={subtitle}
          emphasisText={emphasisText}
          thumbnailImage={thumbnailImage}
          actions={headerActions}
        />
      )}

      <div className={cx(classes.contentWrapper)}>{content}</div>

      {hasActions && (
        <CardActions className={cx(classes.cardActions)} disableSpacing>
          <div className={cx(classes.actionWrapper)}>
            {primaryActions ? (
              <Actions
                className={cx(classes.actions, classes.primaryActions)}
                actions={primaryActions}
                variant="button"
              />
            ) : (
              <div />
            )}
            {secondaryActions && (
              <Actions
                className={cx(classes.actions, classes.secondaryActions)}
                actions={secondaryActions}
              />
            )}
          </div>
        </CardActions>
      )}
    </MuiCard>
  );
}

export default Card;
