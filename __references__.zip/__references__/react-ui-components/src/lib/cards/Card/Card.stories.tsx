import { Typography } from '@mui/material';
import { Meta, Story } from '@storybook/react';
import { Card as Component, CardProps } from './Card';

const meta: Meta = {
  component: Component,
  argTypes: {},
  parameters: {
    controls: { expanded: true },
  },
};

export default meta;

const Template: Story<CardProps> = (args) => <Component {...args} />;

export const Card = Template.bind({});
Card.args = {
  title: 'Card Title',
  subtitle: 'Card Subtitle',
  emphasisText: 'Card Emphasis',
  children: `Let's make a nice big leafy tree. In your world you have total and absolute power. This is your world, whatever makes you happy you can put in it. Go crazy. We wash our brush with odorless thinner. If I paint something, I don't want to have to explain what it is.

  Painting should do one thing. It should put happiness in your heart. You can bend rivers. But when I get home, the only thing I have power over is the garbage. We'll throw some old gray clouds in here just sneaking around and having fun. I get carried away with this brush cleaning. Let's put some happy little clouds in our world.`,
  thumbnailImage: 'assets/images/placeholders/image-light.svg',
  headerActions: [
    () => {
      return <Typography>Custom Action</Typography>;
    },
    {
      title: 'Settings',
      icon: 'settings',
      onClick() {
        console.log('clicked');
      },
    },
    {
      title: 'Export',
      icon: 'download',
      color: 'primary',
      onClick() {
        console.log('clicked');
      },
    },
  ],
  primaryActions: [
    () => {
      return <Typography>Custom Action</Typography>;
    },
    {
      title: 'Settings',
      icon: 'settings',
      onClick() {
        console.log('clicked');
      },
    },
    {
      title: 'Export',
      icon: 'download',
      color: 'primary',
      onClick() {
        console.log('clicked');
      },
    },
  ],
  secondaryActions: [
    () => {
      return <Typography>Custom Action</Typography>;
    },
    {
      title: 'Settings',
      icon: 'settings',
      onClick() {
        console.log('clicked');
      },
    },
    {
      title: 'Export',
      icon: 'download',
      color: 'primary',
      onClick() {
        console.log('clicked');
      },
    },
  ],
};

export const StandardCard = Template.bind({});
StandardCard.args = {
  title: 'Card Title',
  subtitle: 'Card Subtitle',
  emphasisText: 'Card Emphasis',
  children: `Let's make a nice big leafy tree. In your world you have total and absolute power. This is your world, whatever makes you happy you can put in it. Go crazy. We wash our brush with odorless thinner. If I paint something, I don't want to have to explain what it is.

  Painting should do one thing. It should put happiness in your heart. You can bend rivers. But when I get home, the only thing I have power over is the garbage. We'll throw some old gray clouds in here just sneaking around and having fun. I get carried away with this brush cleaning. Let's put some happy little clouds in our world.`,
  thumbnailImage: 'assets/images/placeholders/image-light.svg',
  headerActions: [
    {
      title: 'Settings',
      icon: 'settings',
      onClick() {
        console.log('clicked');
      },
    },
  ],
  primaryActions: [
    {
      title: 'Settings',
      onClick() {
        console.log('clicked');
      },
    },
    {
      title: 'Export',
      color: 'primary',
      onClick() {
        console.log('clicked');
      },
    },
  ],
  secondaryActions: [
    {
      title: 'Settings',
      icon: 'settings',
      onClick() {
        console.log('clicked');
      },
    },
    {
      title: 'Export',
      icon: 'download',
      color: 'primary',
      onClick() {
        console.log('clicked');
      },
    },
  ],
};
