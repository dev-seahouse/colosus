import { Typography } from '@mui/material';
import { Meta, Story } from '@storybook/react';
import { CardHeader as Component, CardHeaderProps } from './CardHeader';

const meta: Meta = {
  component: Component,
  argTypes: {},
  parameters: {
    controls: { expanded: true },
  },
};

export default meta;

const Template: Story<CardHeaderProps> = (args) => <Component {...args} />;

export const CardHeader = Template.bind({});
CardHeader.args = {
  title: 'Card Title',
  subtitle: 'Card Subtitle',
  emphasisText: 'Card Emphasis',
  thumbnailImage: 'assets/images/placeholders/image-light.svg',
  actions: [
    () => {
      return <Typography>Custom Action</Typography>;
    },
    {
      title: 'Settings',
      icon: 'settings',
      onClick() {
        console.log('clicked');
      },
    },
    {
      title: 'Export',
      icon: 'download',
      color: 'primary',
      onClick() {
        console.log('clicked');
      },
    },
  ],
};
