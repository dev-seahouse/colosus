import {
  CardHeader as MuiCardHeader,
  CardHeaderProps as MuiCardHeaderProps,
  Typography,
} from '@mui/material';
import { makeStyles } from 'tss-react/mui';
import { Actions, ActionsProps } from '../../buttons';
import { Avatar } from '../../media';
import { BaseComponent } from '../../types';
import { useTheme } from '@emotion/react';
import { Theme } from '@mui/material';

const useStyles = makeStyles()((theme) => {
  return {
    root: {
      '& .MuiCardHeader-content': {
        overflow: 'hidden',
      },
    },
    titleWrapper: {
      overflow: 'hidden',
      marginRight: theme.spacing(2),
    },
    emphasisText: {
      color: theme.palette.primary.main,
      textTransform: 'uppercase',
    },
  };
});

export interface CardHeaderProps
  extends Omit<
    BaseComponent<'div', Partial<ReturnType<typeof useStyles>['classes']>>,
    'title'
  > {
  title: string;
  subtitle?: MuiCardHeaderProps['subheader'];
  emphasisText?: string;
  thumbnailImage?: string;
  actions?: ActionsProps['actions'];
}

export function CardHeader({
  className,
  style,
  classes: classesProp,
  title,
  subtitle,
  emphasisText,
  thumbnailImage,
  actions,
}: CardHeaderProps) {
  const theme: Theme = useTheme() as Theme;
  const { classes, cx } = useStyles(undefined, {
    props: {
      classes: classesProp,
    },
  });

  return (
    <MuiCardHeader
      className={cx(classes.root, className)}
      style={style}
      avatar={
        thumbnailImage ? (
          <Avatar
            title={title}
            src={thumbnailImage}
            backgroundColor={theme.palette.background.default}
          />
        ) : null
      }
      title={
        <div className={cx(classes.titleWrapper)}>
          <Typography
            className={cx(classes.emphasisText)}
            gutterBottom={false}
            noWrap={true}
            display="block"
            variant="subtitle1"
            component="h3"
          >
            {emphasisText}
          </Typography>
          <Typography noWrap={true} display="block" variant="h6" component="h3">
            {title}
          </Typography>
        </div>
      }
      subheader={
        <Typography variant="caption" component="p">
          {subtitle}
        </Typography>
      }
      action={actions ? <Actions actions={actions} /> : null}
    />
  );
}

export default CardHeader;
