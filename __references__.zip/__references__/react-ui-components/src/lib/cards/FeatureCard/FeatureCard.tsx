import { CardContent, CardMedia, Typography } from '@mui/material';
import { makeStyles } from 'tss-react/mui';
import Card, { CardProps } from '../Card';
import CardHeader from '../CardHeader';

const useStyles = makeStyles()((theme) => {
  return {
    root: {
      width: '100%',
      display: 'flex',
      flexDirection: 'column',
    },
    cardHeader: {
      overflow: 'hidden',
      '& .MuiCardHeader-content': {
        overflow: 'hidden',
      },
    },
    title: {
      fontWeight: 'bold',
    },
    cardActions: {},
    cardMedia: {
      width: '100%',
      aspectRatio: '16 / 9',
    },
    contentWrapper: {
      display: 'flex',
      flexDirection: 'column',
      height: '100%',
      width: '100%',
      overflow: 'hidden',
    },
    cardContent: {
      flexGrow: 1,
      flexShrink: 1,
    },
    description: {
      overflow: 'hidden',
      display: '-webkit-box',
      WebkitLineClamp: '3',
      WebkitBoxOrient: 'vertical',
    },
  };
});

export interface FeatureCardProps extends CardProps {
  imageSrc: string;
  imageAltText?: string;
  variant?: 'titleProminent' | 'imageProminent';
}

export function FeatureCard({
  className,
  style,
  classes: classesProp,
  imageSrc,
  imageAltText,
  variant = 'imageProminent',
  children,
  title,
  subtitle,
  emphasisText,
  thumbnailImage,
  headerActions,
  ...rest
}: FeatureCardProps) {
  const { classes, cx } = useStyles(undefined, {
    props: {
      classes: classesProp,
    },
  });

  const content =
    children && typeof children === 'string' ? (
      <Typography
        className={cx(classes.description)}
        variant="body2"
        color="textSecondary"
        component="p"
      >
        {children}
      </Typography>
    ) : (
      children
    );

  return (
    <Card
      className={cx(classes.root, className)}
      style={style}
      showTitle={variant === 'titleProminent'}
      title={title}
      subtitle={subtitle}
      emphasisText={emphasisText}
      thumbnailImage={thumbnailImage}
      headerActions={headerActions}
      {...rest}
    >
      <CardMedia
        className={cx(classes.cardMedia)}
        image={imageSrc || 'assets/images/placeholders/image-light.svg'}
        title={imageAltText}
      />

      {variant === 'imageProminent' && (
        <CardHeader
          title={title}
          subtitle={subtitle}
          emphasisText={emphasisText}
          thumbnailImage={thumbnailImage}
          actions={headerActions}
        />
      )}

      <CardContent className={cx(classes.cardContent)}>
        <div className={cx(classes.contentWrapper)}>{content}</div>
      </CardContent>
    </Card>
  );
}

export default FeatureCard;
