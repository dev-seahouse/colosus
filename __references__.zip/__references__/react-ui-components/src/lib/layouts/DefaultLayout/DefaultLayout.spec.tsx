import { render } from '@testing-library/react';

import Component from './DefaultLayout';

describe(Component.name, () => {
  test.todo(`Test ${Component.name}`);
  // it('should render successfully', () => {
  //   const { baseElement } = render(<Component />);
  //   expect(baseElement).toBeTruthy();
  // });
});
