import { Theme } from '@mui/material';
import { ThemeProvider } from '@mui/material/styles';
import { useEffect } from 'react';
import { useDispatch } from 'react-redux';
import { Outlet } from 'react-router-dom';
import { makeStyles } from 'tss-react/mui';
import { StateDialog } from '../../dialogs';
import { useApplication } from '../../hooks';
import { LayoutContainerProps } from '../../modules';
import { ACTIONS, useLayoutSelector } from '../../store';
import { ContainerComponent, LayoutDefinition } from '../../types';

const useStyles = makeStyles<
  DefaultLayoutDefinitionProps & {
    mainTheme?: Theme;
  }
>()((/*theme*/) => {
  return {
    root: {},
  };
});

export type DefaultLayoutDefinitionProps = LayoutDefinition<'default'> & {
  theme: {
    main: string;
    dialog: string;
  };
};

export const DefaultLayoutDefaults: DefaultLayoutDefinitionProps = {
  name: 'default',
  theme: {
    main: 'defaultLight',
    dialog: 'defaultLight',
  },
};

export type DefaultLayoutProps = LayoutContainerProps<
  DefaultLayoutDefinitionProps,
  Partial<ReturnType<typeof useStyles>['classes']>
>;

export function DefaultLayout({
  className,
  style,
  classes: classesProp,
  layoutConfig = DefaultLayoutDefaults,
}: DefaultLayoutProps) {
  const dispatch = useDispatch();
  const currentLayoutSettings = useLayoutSelector<DefaultLayoutDefinitionProps>(
    layoutConfig.name
  );
  const { themes = {} } = useApplication();

  useEffect(() => {
    if (!currentLayoutSettings) {
      dispatch(ACTIONS.settings.resetLayout(layoutConfig));
    } else {
      dispatch(ACTIONS.settings.setDefault(layoutConfig));
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [layoutConfig]);

  const layoutProps = currentLayoutSettings || layoutConfig;

  const definedTheme = layoutProps ? themes[layoutProps.theme.main] : undefined;

  const { classes, cx } = useStyles(
    {
      ...layoutProps,
      mainTheme: definedTheme,
    },
    {
      props: {
        classes: classesProp,
      },
    }
  );

  const { theme } = layoutProps;

  return (
    <ThemeProvider theme={themes[theme.main]}>
      <div className={cx(classes.root, className)} style={style}>
        <ThemeProvider theme={themes[theme.dialog]}>
          <StateDialog />
        </ThemeProvider>

        <Outlet />
      </div>
    </ThemeProvider>
  );
}

export default DefaultLayout;
