import { Meta, Story } from '@storybook/react';
import { Provider } from 'react-redux';
import { createStore } from '../../store';
import {
  DefaultLayout as Component,
  DefaultLayoutDefaults,
  DefaultLayoutProps,
} from './DefaultLayout';

const meta: Meta = {
  component: Component,
  argTypes: {},
  parameters: {
    controls: { expanded: true },
  },
};

export default meta;

const Template: Story<DefaultLayoutProps> = (args) => {
  const store = createStore({});
  return (
    <Provider store={store}>
      <Component {...args} />
    </Provider>
  );
};

export const DefaultLayout = Template.bind({});
DefaultLayout.args = {
  layoutConfig: DefaultLayoutDefaults,
  children: 'Default Layout does not include an app router',
};
