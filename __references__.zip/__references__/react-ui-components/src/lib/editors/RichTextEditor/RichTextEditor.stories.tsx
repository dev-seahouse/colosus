import { Meta, Story } from '@storybook/react';
import {
  RichTextEditor as Component,
  RichTextEditorProps,
} from './RichTextEditor';

const meta: Meta = {
  component: Component,
  argTypes: {},
  parameters: {
    controls: { expanded: true },
  },
};

export default meta;

const Template: Story<RichTextEditorProps> = (args) => <Component {...args} />;

export const RichTextEditor = Template.bind({});
RichTextEditor.args = {
  value: 'This is a rich text editor',
};

export const RichTextEditorSingleline = Template.bind({});
RichTextEditorSingleline.args = {
  value: 'This is a rich text editor in single line, enter will not work',
  multiline: false,
};

export const RichTextEditorBalloon = Template.bind({});
RichTextEditorBalloon.args = {
  value: 'This is a rich text editor, select text to format',
  variant: 'balloon',
};

export const RichTextEditorBalloonBlock = Template.bind({});
RichTextEditorBalloonBlock.args = {
  value: 'This is a rich text editor, select text to format',
  variant: 'balloonBlock',
};

export const RichTextEditorInline = Template.bind({});
RichTextEditorInline.args = {
  value: 'This is a rich text editor, select text to format',
  variant: 'balloon',
};
