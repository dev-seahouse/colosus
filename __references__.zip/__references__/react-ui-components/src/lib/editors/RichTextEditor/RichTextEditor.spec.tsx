import { render } from '@testing-library/react';

// import Component from './RichTextEditor';

describe('RichTextEditor', () => {
  test.todo(`Test RichTextEditor`);
  // it('should render successfully', () => {
  //     const { baseElement } = render(<Component />);
  //     expect(baseElement).toBeTruthy();
  // });
});
