import { EditorConfig } from '@ckeditor/ckeditor5-core/src/editor/editorconfig';
import {
  BalloonBlockEditor,
  BalloonEditor,
  ClassicEditor,
  DecoupledEditor,
  InlineEditor,
} from '@bambu/references-ckeditor5-custom';
import { CKEditor } from '@ckeditor/ckeditor5-react';
import { _ } from '@bambu/js-core';
import { InputBaseComponentProps } from '@mui/material';
import { forwardRef, useEffect, useMemo, useRef } from 'react';
import { makeStyles } from 'tss-react/mui';

type StyleProps = {
  rows: number;
  multiline: boolean;
};

const useStyles = makeStyles<StyleProps>()((theme, { rows, multiline }) => {
  return {
    root: {
      width: '100%',
      height: 'auto',
      '& .ck': {
        minHeight: 'inherit',
        outline: 'none',
      },
      '& .ck.ck-editor__editable_inline>:last-child': {
        marginTop: 0,
        marginBottom: 0,
      },
      '& .ck.ck-editor__editable_inline>:first-of-type': {
        marginBottom: 0,
        marginTop: 0,
      },
      '& .ck.ck-editor__editable:not(.ck-editor__nested_editable).ck-focused': {
        border: 'none!important',
        boxShadow: 'none!important',
      },
      '& .ck.ck-content': {
        color: theme.palette.common.black,
      },
    },
    rows: multiline
      ? {
          '& .ck.ck-content': {
            minHeight: theme.spacing(rows * 2.1),
            overflowY: 'auto',
          },
        }
      : {},
    multiline: !multiline
      ? {
          '& .ck.ck-editor__editable_inline': {
            overflow: 'hidden',
          },
        }
      : {},
  };
});

export interface BaseRichTextEditorProps
  extends Omit<InputBaseComponentProps, 'onChange'> {
  /**
   * Allow multiline editing, false to disable multiline
   */
  multiline?: boolean;
  /**
   * Configuration for the Editor
   */
  config?: EditorConfig;
  /**
   * Number of rows for multiline editing
   */
  rows?: number;
  onChange?: (e: Event, value: InputBaseComponentProps['value']) => void;
}

export type RichTextEditorProps =
  | RichTextEditorClassicProps
  | RichTextEditorBallonProps
  | RichTextEditorBallonBlockProps
  | RichTextEditorDecoupledProps
  | RichTextEditorInlineProps;

export interface RichTextEditorClassicProps extends BaseRichTextEditorProps {
  variant?: 'classic';
}

export interface RichTextEditorBallonProps extends BaseRichTextEditorProps {
  variant: 'balloon';
}

export interface RichTextEditorBallonBlockProps
  extends BaseRichTextEditorProps {
  variant: 'balloonBlock';
}

export interface RichTextEditorDecoupledProps extends BaseRichTextEditorProps {
  variant: 'decoupled';
}

export interface RichTextEditorInlineProps extends BaseRichTextEditorProps {
  variant: 'inline';
}

export const RichTextEditor = forwardRef(
  (
    {
      className,
      style,
      classes: classesProp,
      variant = 'classic',
      value,
      config,
      multiline = true,
      onChange,
      rows = 5,
      ...rest
    }: RichTextEditorProps,
    ref
  ) => {
    const { classes, cx } = useStyles(
      {
        rows,
        multiline,
      },
      {
        props: {
          classes: classesProp,
        },
      }
    );

    // TODO: Allow variants with superbuild
    const Editor = useMemo(() => {
      switch (variant) {
        case 'balloon':
          return BalloonEditor;
        case 'balloonBlock':
          return BalloonBlockEditor;
        case 'decoupled':
          return DecoupledEditor;
        case 'inline':
          return InlineEditor;
        default:
          return ClassicEditor;
      }
    }, [variant]);

    // TODO: Type this once superbuild is ready
    const editorRef = useRef<
      | BalloonEditor
      | BalloonBlockEditor
      | ClassicEditor
      | DecoupledEditor
      | InlineEditor
      | null
    >(null);

    useEffect(() => {
      if (!editorRef || !ref || !editorRef.current?.sourceElement) {
        return;
      }
      const sourceElement = editorRef.current.sourceElement as HTMLInputElement;
      if (typeof ref === 'function') {
        ref(sourceElement);
      } else {
        ref.current = sourceElement;
      }
    }, [ref]);

    useEffect(() => {
      if (editorRef.current) {
        if (value !== editorRef.current.getData()) {
          editorRef.current.setData(value || '');
        }
      }
      // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [value]);

    const derivedConfig = useMemo(() => {
      // Return the config merged with settings for multi and single line entry
      return _.merge(
        multiline
          ? {}
          : {
              toolbar: ['bold', 'italic'],
              restrictedEditing: {
                allowedCommands: ['bold', 'italic'],
                allowedAttributes: [],
              },
            },
        config
      );
    }, [config, multiline]);

    return (
      <div
        className={cx(classes.root, classes.multiline, classes.rows, className)}
        style={style}
      >
        <CKEditor
          {...rest}
          editor={Editor}
          data={value}
          isReadOnly={true}
          config={derivedConfig}
          onReady={(editor: any) => {
            editorRef.current = editor;
            if (editor) {
              if (!multiline) {
                editor.editing.view.document.on(
                  'keydown',
                  (evt: any, data: any) => {
                    if (data.keyCode === 13) {
                      data.stopPropagation();
                      data.preventDefault();
                      evt.stop();
                    }
                  },
                  { priority: 'highest' }
                );
              }
              editor.setData(value || '');
            }
          }}
          onChange={(e: any, editor: any) => {
            const v = editor.getData();
            onChange && onChange(e, v);
          }}
        />
      </div>
    );
  }
);

export default RichTextEditor;
