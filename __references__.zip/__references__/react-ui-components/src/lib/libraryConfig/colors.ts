export default {
  primary: '#7A48FF',
  secondary: '#031926',
  complimentary: '#77aca2',
};
