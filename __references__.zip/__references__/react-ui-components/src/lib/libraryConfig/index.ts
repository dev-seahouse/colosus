import colors from './colors';

const appSettings = {
  environment: 'dev',
  name: 'bambu React Library',
  description: `The bambu React Library.`,
  keywords: 'RAD MVP Production ready protoype',
  featureImage: 'assets/images/backgrounds/templates.jpg',
  frontEndDocs:
    'https://dev-docs.bambu.com/dev/libs/react/storybook/index.html',
  apiDocs: '',
  sourceDocs: '',
  website: '',
  repo: '',
  favIcon: 'assets/logos/favicon-96x96.png',
  logo: 'assets/logos/bambu_logo.png',
  company_name: 'bambu',
  company_logo: 'assets/logos/bambu_logo.png',
  company_url: 'https://bambu.com',
  ga_tag_id: 'gtag',
  colors: colors,
  themeMode: 'light',
};

export { appSettings };
