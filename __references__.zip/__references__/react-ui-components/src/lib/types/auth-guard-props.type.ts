export type AuthGuardProps = {
  roles: string[];
} & Record<string, any>;
