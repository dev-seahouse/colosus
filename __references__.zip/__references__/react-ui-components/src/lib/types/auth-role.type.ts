export type AuthRole = {
  id: string;
  code: string;
  name: string;
};
