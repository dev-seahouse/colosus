import faInit from './fa-init';

let initialised = false;
export default () => {
  if (!initialised) {
    initialised = true;
    faInit();
  }
};
