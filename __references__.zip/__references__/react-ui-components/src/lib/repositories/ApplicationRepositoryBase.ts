import { DtoType } from '@bambu/js-core';
import { createModelRepository, RepositoryFactory } from '../utilities';
import { axios, AxiosInstance } from '../services';

export type RepositoryProps = {
  axios?: AxiosInstance;
  baseURL: string;
};

export type IApplicationRepositories = Record<string, IApplicationRepository>;
export type RepositoryGenerator<T extends DtoType> = (
  baseURL: string,
  axios: AxiosInstance
) => RepositoryFactory<T>;

export type IApplicationRepository = {
  getDefinitions: () => Record<string, RepositoryFactory>;
  getDefinition: (name: string) => RepositoryFactory;
  addDefinition<T extends DtoType>(
    name: string,
    generator: RepositoryGenerator<T>
  ): RepositoryFactory<T>;
};

export abstract class ApplicationRepositoryBase
  implements IApplicationRepository
{
  protected readonly axios;
  protected readonly baseURL;
  private readonly definitions: Record<string, RepositoryFactory<any>>;

  constructor(args: RepositoryProps) {
    this.baseURL = args.baseURL;
    if (args.axios) {
      this.axios = args.axios;
    } else {
      this.axios = axios;
    }
    this.definitions = this.createDefinitions();
  }

  protected abstract createDefinitions(): Record<
    string,
    RepositoryFactory<any>
  >;

  getDefinitions(): Record<string, RepositoryFactory<DtoType>> {
    return this.definitions;
  }

  getDefinition<T extends DtoType>(name: string) {
    return (this.definitions as any)[name] as ReturnType<
      typeof createModelRepository<T>
    >;
  }

  addDefinition<T extends DtoType>(
    name: string,
    generator: RepositoryGenerator<T>
  ): RepositoryFactory<T> {
    const factory = generator(this.baseURL, this.axios);
    this.definitions[name] = factory;
    return factory;
  }
}
