import { I18NArguments } from '@bambu/js-core';
import { useContext, useEffect, useState } from 'react';
import { LocalizationContext } from '../../i18n/LocalizationProvider';

function useLocalization(text: string): string;
function useLocalization(args: I18NArguments): string;
function useLocalization(args: string | I18NArguments | undefined): string;
function useLocalization(text: string | I18NArguments | undefined) {
  if (!text) {
    text = '';
  }
  const params = typeof text === 'string' ? ([text] as [string]) : text;
  const translationText = (params && params[0]) || '';
  const localization = useContext(LocalizationContext);
  const [translation, setTranslation] = useState(translationText);

  useEffect(() => {
    setTranslation(localization.t(...params));
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [text, localization]);

  return translation;
}

export default useLocalization;
