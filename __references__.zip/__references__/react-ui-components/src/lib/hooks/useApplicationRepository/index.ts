import { DtoType } from '@bambu/js-core';
import { useContext, useEffect, useState } from 'react';
import { of } from 'rxjs';
import { AppContext } from '../../application';
import { RepositoryFactory } from '../../utilities';
import useMemoDeepCompare from '../useMemoDeepCompare';
import useObservable from '../useObservable';

function useApplicationRepository<T extends DtoType = any>(
  repositoryName: string,
  dataDefinition: string
) {
  const { repositories = {} } = useContext(AppContext);

  const { useRepository, repositoryDescriptor } = useMemoDeepCompare(() => {
    const repository = (repositories as any)[repositoryName];
    if (!repository) {
      const repositoryNames = Object.keys(repositories).join(', ');
      throw new Error(
        `The application repository '${repositoryName}' does not exist in this application.  Try one of [${repositoryNames}]`
      );
    }
    const dataRepository: RepositoryFactory<T> =
      repository.getDefinition(dataDefinition);
    if (!dataRepository) {
      const repositoryNames = Object.keys(repository.getDefinitions()).join(
        ', '
      );
      throw new Error(
        `The data definition for '${dataDefinition}' does not exist in the repository '${repositoryName}'.  Try one of [${repositoryNames}]`
      );
    }

    return {
      useRepository: dataRepository.useRepository,
      repositoryDescriptor: dataRepository.getDescriptor(),
    };
  }, [repositories, repositoryName, dataDefinition]);

  const [repo, data] = useRepository([
    repositories,
    repositoryName,
    dataDefinition,
  ]);

  const [repoData, setRepoData] = useState(data);
  useEffect(() => {
    setRepoData(data);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [repo]);

  useObservable(repo?.getObservable() || of(data), setRepoData);

  return {
    repository: repo,
    repositoryDescriptor: repositoryDescriptor,
    dataState: repoData,
  };
}

export default useApplicationRepository;
