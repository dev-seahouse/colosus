import { axios } from '../../services';

function useAxios() {
  return axios;
}

export default useAxios;
