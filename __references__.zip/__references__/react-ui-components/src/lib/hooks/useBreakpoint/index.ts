import { useEffect, useState } from 'react';
import usePrevious from '../usePrevious';

function useBreakpoint(
  func: (isLarger: boolean, width: number) => void,
  breakpoint: number,
  deps: any[] = []
) {
  const [width, setWidth] = useState(window.innerWidth);
  const previousWidth = usePrevious<number>(width);

  useEffect(() => {
    const handleWindowResize = () => {
      setWidth(window.innerWidth);
    };
    window.addEventListener('resize', handleWindowResize);
    return () => {
      window.removeEventListener('resize', handleWindowResize);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [...deps, breakpoint]);

  useEffect(() => {
    if (previousWidth === undefined) {
      // Always trigger on a first update
      func(width > breakpoint, width);
    } else {
      // Only trigger if we have crossed the threshold
      if (
        (previousWidth < breakpoint && width >= breakpoint) ||
        (previousWidth >= breakpoint && width < breakpoint)
      ) {
        func(width > breakpoint, width);
      }
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [width]);

  useEffect(() => {
    // As the actual breakpoint has changed we need to trigger
    func(width > breakpoint, width);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [breakpoint]);
}

export default useBreakpoint;
