import { matchRoutes, useLocation } from 'react-router-dom';
import { RouteDefinition } from '../../types';

function useCurrentPath<RouteType extends RouteDefinition>(
  routes: RouteType[]
): [string, RouteType[]] {
  const location = useLocation();
  const matchedRoutes = matchRoutes(routes, location);

  return [
    matchedRoutes && matchedRoutes.length > 0
      ? matchedRoutes[0].pathname
      : location.pathname,
    matchedRoutes?.map((r) => r.route) as RouteType[],
  ];
}

export default useCurrentPath;
