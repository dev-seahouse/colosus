import { useEffect, useRef, useState } from 'react';
import io from 'socket.io-client';

type message = {
  type: string;
  message: string;
};

function useWebsockets(
  host: string,
  namespace: string,
  events: {
    [key: string]: (event: string, data: any) => void;
  }
) {
  const socket = useRef<ReturnType<typeof io> | null>(null);
  const [socketID, setSocketID] = useState<string | null>(null);

  const [connected, setConnected] = useState<boolean>(
    socket.current?.connected || false
  );
  const [error, setError] = useState<string | null>(null);

  function emitWSEvent(event: string, payload: Record<any, any>) {
    socket.current &&
      socket.current.emit(event, {
        ...payload,
        socketID: socketID,
        timestamp: Date.now(),
      });
  }

  useEffect(() => {
    if (socket.current) {
      Object.keys(events).forEach((e) => socket.current?.off(e));
      socket.current.close();
    }

    if (host) {
      const ws = io(host + `/${namespace}`, {
        autoConnect: false,
        transports: ['websocket'],
      });
      ws.on('connect', () => {
        setConnected(true);
        setSocketID(ws.id);
        setError(null);
      });
      ws.on('disconnect', (value) => {
        setConnected(false);
        setError(null);
        setSocketID(null);
        ws.close();
      });
      ws.on('connect_error', (err) => {
        setError(err.message);
        setConnected(false);
        setSocketID(null);
        ws.close();
      });
      ws.on('error', (err) => {
        setError(err.message);
      });
      Object.keys(events).forEach((e) => {
        ws.on(e, (value) => {
          events[e](e, value);
        });
      });
      ws.connect();
      socket.current = ws;
    } else {
      socket.current = null;
    }
    return () => {
      if (socket.current) {
        Object.keys(events).forEach((e) => socket.current?.off(e));
        socket.current.close();
      }
    };
  }, [host, namespace]);

  return {
    host: host,
    namespace: namespace,
    connected: connected,
    socketID: socketID,
    error: error,
    emitEvent: emitWSEvent,
  };
}

export default useWebsockets;
