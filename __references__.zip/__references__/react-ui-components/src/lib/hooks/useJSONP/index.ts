import { generateHash } from '@bambu/js-core';
import { useEffect, useMemo, useState } from 'react';
import { Observable } from 'rxjs';

export type UseJSONPProps<DataType = any> = {
  src: string;
  callback: (data: DataType) => void;
  jsonPFn: string;
};

type ScriptState = 'initialising' | 'loaded' | 'error' | 'aborted';

type JsonPBaseResponse = {
  status: 200 | 400;
  responseType: 'jsonp' | 'error';
  originalEvent: Event;
};

type JsonPOKResponse<DataType = any> = JsonPBaseResponse & {
  status: 200;
  responseType: 'jsonp';
  response: DataType;
};

type JsonPErrorResponse = JsonPBaseResponse & {
  status: 400;
  responseType: 'error';
};

type JsonPResponse<DataType = any> =
  | JsonPErrorResponse
  | JsonPOKResponse<DataType>;

function useJSONP<DataType = any>({
  src,
  callback,
  jsonPFn,
}: UseJSONPProps<DataType>): [
  Observable<JsonPResponse<DataType>>,
  ScriptState
] {
  const [scriptState, setScriptState] = useState<ScriptState>('initialising');

  const observable = useMemo(() => {
    if (src) {
      let jsonPCallback = (window as any)[jsonPFn];
      if (!jsonPCallback) {
        jsonPCallback = (window as any)[jsonPFn] = (data: any) => {
          setScriptState('loaded');
          (window as any)[jsonPFn].data = data;
        };
      }

      const script = document.createElement('script');
      script.type = 'text/javascript';
      script.src = src;
      setScriptState('initialising');

      return new Observable<JsonPResponse<DataType>>((subscriber) => {
        const handler = (e: Event) => {
          setScriptState('loaded');
          const status = e.type === 'error' ? 400 : 200;
          const responseData = jsonPCallback.data;

          if (status === 200) {
            subscriber.next({
              status,
              responseType: 'jsonp',
              response: responseData,
              originalEvent: e,
            });
            subscriber.complete();
          } else {
            subscriber.error({
              type: 'error',
              status,
              originalEvent: e,
            });
          }
        };

        script.onload = (script as any).onerror = handler;
        const head = document.getElementsByTagName('head')[0];
        head.insertBefore(script, head.firstChild);
      });
    } else {
      setScriptState('error');
      return new Observable<JsonPResponse<DataType>>((subscriber) => {
        subscriber.error({
          type: 'error',
          status: 400,
          originalEvent: {
            type: 'error',
            message: 'no source defined',
          },
        });
      });
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [src, callback, jsonPFn]);

  return [observable, scriptState];
}

export default useJSONP;
