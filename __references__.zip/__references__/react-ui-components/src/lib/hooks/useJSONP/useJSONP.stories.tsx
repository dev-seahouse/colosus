import { Meta, Story } from '@storybook/react';
import { useState } from 'react';
import { Container } from '../../containers';
import useObservable from '../useObservable';
import useJSONP, { UseJSONPProps } from './index';

const UseJsonPHook = ({ src, jsonPFn }: UseJSONPProps) => {
  const [data, setData] = useState<any>(null);

  const [observable, state] = useJSONP({
    src,
    jsonPFn,
    callback: setData,
  });
  useObservable(observable, setData);

  return (
    <Container>
      <div>Script State: {state}</div>
      <div>Script Data: {JSON.stringify(data)}</div>
    </Container>
  );
};
UseJsonPHook.displayName = 'UseJsonP';

const meta: Meta = {
  component: UseJsonPHook,
  argTypes: {},
  parameters: {
    controls: { expanded: true },
  },
};

export default meta;

const Template: Story<UseJSONPProps> = (args) => <UseJsonPHook {...args} />;

export const UseJsonPHookDemo = Template.bind({});
UseJsonPHookDemo.args = {
  src: 'http://earthquake.usgs.gov/earthquakes/feed/v1.0/summary/all_day.geojsonp',
  jsonPFn: 'eqfeed_callback',
};
