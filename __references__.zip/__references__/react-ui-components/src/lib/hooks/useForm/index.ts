import { I18NArguments, _ } from '@bambu/js-core';
import { FormEvent, SyntheticEvent, useCallback, useState } from 'react';

function useForm<T>(
  initialState: T,
  validate?: (
    data: T,
    field?: keyof T | (keyof T)[],
    errors?: Partial<Record<keyof T, I18NArguments[]>>
  ) => Record<keyof T, I18NArguments[] | undefined>,
  onSubmit?: (form?: T) => void
) {
  const [form, setForm] = useState<T>(initialState);
  const [errors, setErrors] = useState<
    Partial<Record<keyof T, I18NArguments[]>>
  >({});
  const handleChange = useCallback(
    (event: SyntheticEvent, newValue?: Partial<T>) => {
      if (event) {
        // eslint-disable-next-line @typescript-eslint/no-explicit-any
        const target = event.target as any;
        event.persist && event.persist();
        let value = target.value;
        // Checkboxes and dates are handled differently
        if (target.type === 'checkbox') {
          value = target.checked;
        } else if (target.type === 'datetime-local' || target.type === 'date') {
          value = value && value.length > 0 ? new Date(value).getTime() : null;
        }
        let validationForm = form;
        const fieldName = target.name;
        setForm((_form) => {
          // @ts-expect-error setIn is a mixin added
          validationForm = _.setIn({ ..._form }, fieldName, value);
          return validationForm;
        });
        setErrors((previousErrors) => {
          return validate
            ? validate(validationForm, fieldName, previousErrors)
            : {};
        });
      } else if (newValue) {
        let validationForm = form;
        const fieldNames: (keyof T)[] = [];

        Object.keys(newValue).forEach((key) => {
          fieldNames.push(key as keyof T);
          setForm((_form) => {
            // @ts-expect-error setIn is a mixin added
            validationForm = _.setIn({ ..._form }, key, newValue[key]);
            return validationForm;
          });
          setErrors((previousErrors) => {
            return validate
              ? validate(validationForm, fieldNames, previousErrors)
              : {};
          });
        });
      }
    },
    // eslint-disable-next-line react-hooks/exhaustive-deps
    []
  );

  const resetForm = useCallback(() => {
    if (!_.isEqual(initialState, form)) {
      setForm(initialState);
      setErrors({});
    }
  }, [form, initialState]);

  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  const setInForm = useCallback((name: keyof T, value: any) => {
    let validationForm = form;
    setForm((_form) => {
      // @ts-expect-error setIn is a mixin added
      validationForm = _.setIn(_form, name, value);
      return validationForm;
    });
    setErrors((previousErrors) => {
      return validate ? validate(validationForm, name, previousErrors) : {};
    });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const handleSubmit = useCallback(
    (
      event: FormEvent,
      afterSubmit?: (event: FormEvent, callback?: () => void) => void,
      callback?: () => void
    ) => {
      if (event) {
        event.preventDefault();
      }
      if (onSubmit) {
        onSubmit(form);
      }
      if (afterSubmit) {
        afterSubmit(event, callback);
      }
    },
    [onSubmit, form]
  );

  const checkIsValid = useCallback(
    (fields?: keyof T | (keyof T)[]) => {
      return validate
        ? Object.entries(validate(form, fields)).flatMap(
            ([key, entry]) => entry
          ).length === 0
        : false;
    },
    [form, validate]
  );

  return {
    form,
    handleChange,
    handleSubmit,
    resetForm,
    setForm,
    setInForm,
    modified: !_.isEqual(form, initialState),
    errors: errors,
    validate: validate,
    isValid: checkIsValid,
  };
}

export default useForm;
