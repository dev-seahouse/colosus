/* eslint-disable react-hooks/exhaustive-deps */
import { useRef, useEffect } from 'react';

function usePrevious<T>(value: T, deps: any[] = []) {
  const ref = useRef<T>();

  useEffect(() => {
    ref.current = value;
  }, [value, ...deps]);

  return ref.current;
}

export default usePrevious;
