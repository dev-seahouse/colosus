import { Typography } from '@mui/material';
import { Meta, Story } from '@storybook/react';
import { useRef } from 'react';
import { Container } from '../../containers';
import useMouse from './index';

type UseMouseProps = {
  debounce: number;
};

const UseMouseHook = ({ debounce }: UseMouseProps) => {
  const containerRef = useRef(null);
  const {
    x,
    y,
    screenX,
    screenY,
    pageX,
    pageY,
    offsetX,
    offsetY,
    clientX,
    clientY,
  } = useMouse(containerRef, {
    debounce: debounce,
  });

  return (
    <Container ref={containerRef}>
      <Typography>{`X:${x}, Y:${y}`}</Typography>
      <Typography>{`screenX:${screenX}, screenY:${screenY}`}</Typography>
      <Typography>{`pageX:${pageX}, pageY:${pageY}`}</Typography>
      <Typography>{`offsetX:${offsetX}, offsetY:${offsetY}`}</Typography>
      <Typography>{`clientX:${clientX}, clientY:${clientY}`}</Typography>
    </Container>
  );
};

const meta: Meta = {
  component: UseMouseHook,
  argTypes: {},
  parameters: {
    controls: { expanded: true },
  },
};

export default meta;

const Template: Story<UseMouseProps> = (args) => <UseMouseHook {...args} />;

export const UseMouseHookDemo = Template.bind({});
UseMouseHookDemo.args = {
  debounce: 0,
};
