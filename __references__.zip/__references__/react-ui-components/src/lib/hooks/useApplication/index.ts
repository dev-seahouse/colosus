import { useContext } from 'react';
import { AppContext } from '../../application';

function useApplication() {
  return useContext(AppContext);
}

export default useApplication;
