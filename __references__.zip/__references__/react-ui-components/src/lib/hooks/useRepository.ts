import { DataRepository, DtoObserverState, DtoType, _ } from '@bambu/js-core';
import { useEffect, useMemo, useState } from 'react';

function useRepository<T extends DtoType>(
  repository: DataRepository<T>,
  deps: any[] = [],
  debug?: string
): [DataRepository<T>, DtoObserverState<T>] {
  const [data, setData] = useState<DtoObserverState<T>>(repository.getState());
  // Note the repository is a mutable object so comparisons directly wont work.  We check the URL instead
  const repoURL = repository.getBaseURL();

  const memoisedRepo = useMemo(() => {
    return repository;
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [repoURL]);

  useEffect(() => {
    setData(memoisedRepo.getState());
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [repoURL]);

  if (debug) {
    debug = `useRepository - ${debug}:${memoisedRepo.getBaseURL()}`;
  }

  useEffect(() => {
    if (debug) {
      console.log(`${debug}: Subscribe`);
    }
    const observable = memoisedRepo.getObservable();
    const subscription = observable.subscribe((result) => {
      setData((state) => {
        if (!_.isEqual(state, result)) {
          if (debug) {
            const updatedProps = Object.entries(result as any).reduce(
              (acc: any, [key, value]) => {
                if (!_.isEqual((state as any)[key], value)) {
                  acc[key] = {
                    from: (state as any)[key],
                    to: value,
                  };
                }
                return acc;
              },
              {} as T
            );
            if (Object.keys(updatedProps).length > 0) {
              console.log(`${debug}:`, updatedProps);
            }
          }
          return result;
        }
        if (debug) {
          console.log(`${debug}: No changes`);
        }
        return state;
      });
    });
    return () => {
      if (debug) {
        console.log(`${debug}: Unsubscribe`);
      }
      subscription.unsubscribe();
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [...deps]);

  return [memoisedRepo, data];
}

export default useRepository;
