import { _ } from '@bambu/js-core';
import { useMemo, useRef } from 'react';

export function useMemoDeepCompare<T>(
  callback: () => T,
  dependencies: unknown[] = [],
  comparator?: (previous: unknown[], next: unknown[]) => boolean,
  debug?: string
) {
  const previousValue = useRef<T>(undefined as T);
  const previousRef = useRef<unknown[]>([]);
  const previous = previousRef.current;

  return useMemo(() => {
    const isEqual = comparator
      ? // If a custom comparator has been provided use it
        comparator(previous, dependencies)
      : // Otherwise do a deep compare on each item
        // finding the first non matching item
        !dependencies.find((d, index) => !_.isEqual(d, previous[index]));

    if (!isEqual) {
      if (debug) {
        const updatedProps = Object.entries(dependencies as any).reduce(
          (acc: any, [key, value]) => {
            if (!_.isEqual((previous as any)[key], value)) {
              acc[key] = {
                from: (previous as any)[key],
                to: value,
              };
            }
            return acc;
          },
          {} as T
        );
        if (Object.keys(updatedProps).length > 0) {
          console.info(`${debug}:`, updatedProps);
        }
      }
      previousRef.current = dependencies;
      previousValue.current = callback();
    }
    return previousValue.current;
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [dependencies, comparator]);
}

export default useMemoDeepCompare;
