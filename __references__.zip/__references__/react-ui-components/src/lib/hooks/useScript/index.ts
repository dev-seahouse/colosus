import { useEffect, useState } from 'react';

type ScriptStatus = 'loading' | 'idle' | 'ready' | 'error';

function useScript(src: string) {
  const [status, setStatus] = useState<ScriptStatus>(src ? 'loading' : 'idle');

  useEffect(() => {
    if (!src) {
      setStatus('idle');
      return () => {
        // Nothing to do here
      };
    }

    // Check if it already exists
    let script = document.querySelector<HTMLScriptElement>(
      `script[src="${src}"]`
    );
    if (!script) {
      // Does not exist so create it
      script = document.createElement('script');
      script.src = src;
      script.async = true;
      script.setAttribute('data_status', 'loading');
      document.body.appendChild(script);

      // Store the status so we can read from other instances of the hook
      const setAttribute = (event: Event) => {
        script?.setAttribute(
          'data-status',
          event.type === 'load' ? 'ready' : 'error'
        );
      };

      script.addEventListener('load', setAttribute);
      script.addEventListener('error', setAttribute);
    } else {
      // Exists so get the status
      setStatus(script.getAttribute('data-status') as ScriptStatus);
    }

    const setState = (event: Event) => {
      setStatus(event.type === 'load' ? 'ready' : 'error');
    };

    script.addEventListener('load', setState);
    script.addEventListener('error', setState);

    return () => {
      if (script) {
        script.removeEventListener('load', setState);
        script.removeEventListener('error', setState);
      }
    };
  }, [src]);

  return status;
}

export default useScript;
