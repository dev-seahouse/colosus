import {
  DataRepository,
  DataRepositoryProps,
  DtoObserverState,
  DtoType,
} from '@bambu/js-core';
import { useMemo, useState } from 'react';
import useIsomorphicLayoutEffect from '../useIsomorphicLayoutEffect';

export type useObservableRepositoryProps<T extends DtoType> =
  DataRepositoryProps<T>;

export function useObservableRepository<T extends DtoType>(
  props: useObservableRepositoryProps<T>,
  deps: any[] = []
): [repository: DataRepository<T>, data: DtoObserverState<T>] {
  const repository = useMemo<DataRepository<T>>(() => {
    return new DataRepository<T>(props);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [deps]);

  // TODO: Populate with initial state;
  const [data, setData] = useState<DtoObserverState<T>>(repository.getState());

  useIsomorphicLayoutEffect(() => {
    const subscription = repository.getObservable().subscribe((result) => {
      setData(result);
    });
    return () => {
      subscription.unsubscribe();
    };
  }, deps);

  return [repository, data];
}

export default useObservableRepository;
