import useMemoDeepCompare from '../useMemoDeepCompare';

export default function useTraceProps(props: unknown[], prefix = '') {
  useMemoDeepCompare(
    () => {
      // Nothing to do, handled by the deep compare
    },
    props,
    undefined,
    prefix
  );
}
