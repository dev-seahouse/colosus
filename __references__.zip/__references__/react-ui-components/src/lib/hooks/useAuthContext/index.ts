import { useContext } from 'react';
import { AppContext } from '../../application';

function useAuthContext() {
  const { getAuthContext } = useContext(AppContext);
  const { auth } = getAuthContext();
  return auth;
}

export default useAuthContext;
