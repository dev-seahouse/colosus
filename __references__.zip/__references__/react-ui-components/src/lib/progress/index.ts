export { default as Loader } from './Loader';
export * from './Loader';

export { default as LottieLoader } from './LottieLoader';
export * from './LottieLoader';

export { default as SuspenseLoader } from './SuspenseLoader';
export * from './SuspenseLoader';
