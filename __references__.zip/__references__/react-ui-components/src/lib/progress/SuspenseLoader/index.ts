export { SuspenseLoader as default } from './SuspenseLoader';
export * from './SuspenseLoader';
