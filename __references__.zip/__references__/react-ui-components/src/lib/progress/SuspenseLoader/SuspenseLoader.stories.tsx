import { Meta, Story } from '@storybook/react';
import {
  SuspenseLoader as Component,
  SuspenseLoaderProps,
} from './SuspenseLoader';

const meta: Meta = {
  component: Component,
  argTypes: {},
  parameters: {
    controls: { expanded: true },
  },
};

export default meta;

const Template: Story<SuspenseLoaderProps> = (args) => <Component {...args} />;

export const SuspenseLoader = Template.bind({});
SuspenseLoader.args = {};
