import { makeStyles } from 'tss-react/mui';
import { Suspense } from 'react';
import { ContainerComponent } from '../../types';
import Loader from '../Loader';

const useStyles = makeStyles()((/*theme*/) => {
  return {
    root: {},
  };
});

// eslint-disable-next-line @typescript-eslint/no-empty-interface
export interface SuspenseLoaderProps
  extends ContainerComponent<
    'div',
    Partial<ReturnType<typeof useStyles>['classes']>
  > {
  // TODO Custom Props HERE
}

export function SuspenseLoader({
  className,
  style,
  classes: classesProp,
  children,
}: SuspenseLoaderProps) {
  const { classes, cx } = useStyles(undefined, {
    props: {
      classes: classesProp,
    },
  });

  return (
    <Suspense fallback={<Loader variant="circular" />}>{children}</Suspense>
  );
}

export default SuspenseLoader;
