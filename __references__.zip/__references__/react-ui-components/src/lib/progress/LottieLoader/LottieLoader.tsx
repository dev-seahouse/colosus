import React, { useMemo } from 'react';
import { makeStyles } from 'tss-react/mui';
import defaultLottie from '../../assets/lottie/file-not-found.json';
import { useHookWithRefCallback, useScript } from '../../hooks';
import useMeasure from '../../hooks/useMeasure';
import { BaseComponent } from '../../types';

const useStyles = makeStyles()((/*theme*/) => {
  return {
    root: {
      alignSelf: 'center',
      height: '100%',
      width: '100%',
      display: 'flex',
      flexGrow: 1,
      flexShrink: 1,
      flexDirection: 'column',
      alignItems: 'center',
      justifyContent: 'center',
      overflow: 'hidden',
    },
  };
});

export interface LottieLoaderProps
  extends BaseComponent<
    'span',
    Partial<ReturnType<typeof useStyles>['classes']>
  > {
  src: string;
  defaultSrc?: string | Record<string, any>;
}

export function LottieLoader({
  className,
  style,
  classes: classesProp,
  src,
  defaultSrc = defaultLottie,
}: LottieLoaderProps) {
  const { classes, cx } = useStyles(undefined, {
    props: {
      classes: classesProp,
    },
  });

  const parseLottie = (lottie: string | Record<string, any>) => {
    return typeof lottie === 'string' ? lottie : JSON.stringify(lottie);
  };

  const [ref, { width, height }] = useMeasure<HTMLDivElement>();

  const lottieSrc = useMemo(() => {
    return parseLottie(src || defaultSrc);
  }, [src, defaultSrc]);

  const scriptStatus = useScript(
    'https://unpkg.com/@lottiefiles/lottie-player@latest/dist/lottie-player.js'
  );

  const [lottieRef] = useHookWithRefCallback<any>(
    (ref) => {
      if (ref && scriptStatus === 'ready' && !src) {
        ref.src = lottieSrc;
      }
    },
    [scriptStatus, lottieSrc]
  );

  const LottiePlayer = React.createElement('lottie-player', {
    ref: lottieRef,
    src: lottieSrc,
    background: 'transparent',
    speed: 1,
    style: {
      width,
      height,
    },
    loop: true,
    autoplay: true,
  });

  return (
    <div className={cx(classes.root, className)} style={style} ref={ref}>
      {scriptStatus === 'ready' && LottiePlayer}
    </div>
  );
}

export default LottieLoader;
