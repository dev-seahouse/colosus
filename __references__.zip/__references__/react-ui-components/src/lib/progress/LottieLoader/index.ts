export { LottieLoader as default } from './LottieLoader';
export * from './LottieLoader';
