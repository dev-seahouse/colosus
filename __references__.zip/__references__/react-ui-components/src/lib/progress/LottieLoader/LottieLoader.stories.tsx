import { Meta, Story } from '@storybook/react';
import { LottieLoader as Component, LottieLoaderProps } from './LottieLoader';

const meta: Meta = {
  component: Component,
  argTypes: {},
  parameters: {
    controls: { expanded: true },
  },
};

export default meta;

const Template: Story<LottieLoaderProps> = (args) => <Component {...args} />;

export const LottieLoader = Template.bind({});
LottieLoader.args = {};
