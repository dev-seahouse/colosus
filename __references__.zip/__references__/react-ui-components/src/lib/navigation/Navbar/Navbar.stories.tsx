import { Meta, Story } from '@storybook/react';
import { Container } from '../../containers';
import { Navbar as Component, NavbarProps } from './Navbar';

const meta: Meta = {
  component: Component,
  argTypes: {},
  parameters: {
    controls: { expanded: true },
  },
};

export default meta;

const NavTestComponent = () => {
  return <div>Nav Content Component</div>;
};

const defaultNav = Array.from(Array(20).keys()).map((index) => {
  return {
    title:
      index === 0
        ? 'A long label that takes more space than the nav'
        : `Item ${index}`,
    icon: 'dashboard',
    navigation: true,
    path: `/${index}`,
    component: NavTestComponent,
    caseSensitive: true,
    routes:
      index % 2 === 0
        ? Array.from(Array(5).keys()).map((j) => {
            return {
              title: `Item ${index}/${j}`,
              icon: 'dashboard',
              navigation: true,
              path: `/${index}/${j}`,
              component: NavTestComponent,
              caseSensitive: true,
              routes:
                j % 2 === 0
                  ? Array.from(Array(3).keys()).map((k) => {
                      return {
                        title: `Item ${index}/${j}/${k}`,
                        icon: 'dashboard',
                        navigation: true,
                        path: `/${index}/${j}/${k}`,
                        component: NavTestComponent,
                        caseSensitive: true,
                      };
                    })
                  : undefined,
            };
          })
        : undefined,
  };
});

const Template: Story<NavbarProps> = ({ orientation, ...rest }) => {
  return (
    <Container
      style={{
        width: 280,
        height: '100%',
        display: 'flex',
      }}
    >
      <Component orientation={orientation} {...rest} />
    </Container>
  );
};

export const Navbar = Template.bind({});
Navbar.args = {
  routes: defaultNav,
  orientation: 'vertical',
};
