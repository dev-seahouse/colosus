import { alpha } from '@mui/material';
import { useMemo } from 'react';
import { makeStyles } from 'tss-react/mui';
import { BaseComponent, RouteDefinition } from '../../types';
import HorizontalNavbar from './components/HorizontalNavbar';
import VerticalNavbar from './components/VerticalNavbar';

const useStyles = makeStyles()((theme) => {
  return {
    root: {
      flexGrow: 1,
      overflow: 'auto',

      borderColor: 'transparent',
      transition: theme.transitions.create(['border-color'], {
        easing: theme.transitions.easing.easeInOut,
        duration: theme.transitions.duration.shorter,
      }),

      '&::-webkit-scrollbar': {
        backgroundColor: 'transparent',
        borderRadius: theme.spacing(1),
        width: theme.spacing(0.5),
        border: `${theme.spacing(0.5)} solid transparent`,
      },

      '&::-webkit-scrollbar, &::-webkit-scrollbar-thumb, &::-webkit-scrollbar-corner':
        {
          borderRightStyle: 'inset',
          borderRightWidth: 'calc(100vw + 100vh)',
          borderColor: 'inherit',
        },

      '&:hover': {
        transition: theme.transitions.create(['border-color'], {
          easing: theme.transitions.easing.easeInOut,
          duration: theme.transitions.duration.shorter,
        }),
        borderColor: alpha(
          (theme.palette.primary as any).compliment ||
            theme.palette.action.focus,
          1 - (theme?.palette.action.disabledOpacity || 0.38)
        ),
      },

      '&:hover::-webkit-scrollbar': {
        backgroundColor: theme.palette.primary[theme.palette.mode],
      },

      '&::-webkit-scrollbar-thumb': {
        borderColor: 'inherit',
        backgroundClip: 'content-box',
        borderRadius: theme.spacing(1) || 8,
      },
    },
  };
});

export interface NavbarProps
  extends BaseComponent<
    'div',
    Partial<ReturnType<typeof useStyles>['classes']>
  > {
  routes: RouteDefinition[];
  orientation?: 'horizontal' | 'vertical';
  itemVariant?: 'rounded' | 'square';
  showLabel?: boolean;
  showIconButton?: boolean;
}

export function Navbar({
  className,
  style,
  classes: classesProp,
  routes,
  orientation = 'vertical',
  itemVariant = 'rounded',
  showLabel = true,
  showIconButton = true,
}: NavbarProps) {
  const { classes, cx } = useStyles(undefined, {
    props: {
      classes: classesProp,
    },
  });

  const NavbarWrapper = useMemo(() => {
    return orientation === 'horizontal' ? HorizontalNavbar : VerticalNavbar;
  }, [orientation]);

  return (
    <div className={cx(classes.root, className)} style={style}>
      <NavbarWrapper
        routes={routes}
        itemVariant={itemVariant}
        showIconButton={showIconButton}
        showLabel={showLabel}
      />
    </div>
  );
}

export default Navbar;
