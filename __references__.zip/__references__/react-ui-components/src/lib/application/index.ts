export { default as App } from './App/App';
export * from './App';

export { default as AppRouter } from './AppRouter/AppRouter';
export * from './AppRouter';
