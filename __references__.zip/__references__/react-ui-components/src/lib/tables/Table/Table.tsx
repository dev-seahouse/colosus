import { makeStyles } from 'tss-react/mui';
import { BaseComponent } from '../../types';

import { Table as MUITable, TableContainer } from '@mui/material';
import {
  ForwardedRef,
  useContext,
  useEffect,
  useImperativeHandle,
  useMemo,
} from 'react';
import {
  Column,
  Row,
  TableInstance,
  useFlexLayout,
  useGlobalFilter,
  usePagination,
  useRowSelect,
  useSortBy,
  useTable,
} from 'react-table';
import { ReactComponent } from 'tss-react/tools/ReactComponent';
import { useDeepCompareEffect, useMemoDeepCompare } from '../../hooks';
import { LocalizationContext } from '../../i18n';
import { Loader } from '../../progress';
import { Field } from '../../utilities';
import EmptyTableView, {
  EmptyTableViewProps,
} from './components/EmptyTableView';
import TableBody, { TableBodyProps } from './components/TableBody';
import TableBodySelectCell from './components/TableBodySelectCell';
import TableFooter, {
  PageSize,
  TableFooterProps,
} from './components/TableFooter';
import TableHeader from './components/TableHeader';
import TableHeaderSelectCell from './components/TableHeaderSelectCell';
import {
  createReactTableColumns,
  TableCanSelectRow,
} from './utilities/createTableColumns';

// eslint-disable-next-line @typescript-eslint/no-explicit-any
const useStyles = makeStyles()((theme, props, classes: any) => {
  return {
    root: {
      overflow: 'hidden',
      width: '100%',
      height: '100%',
      display: 'flex',
      flexDirection: 'column',
      flexGrow: 1,
      flexShrink: 1,
    },
    root_variant_condensed: {},
    root_variant_regular: {},
    root_variant_expanded: {},
    table: {
      tableLayout: 'auto',
      width: '100%',
      flexGrow: 1,
      flexShrink: 1,

      [`& .${classes.loaderWrapper}`]: {
        opacity: 0,
        transition: theme.transitions.create(['opacity'], {
          easing: theme.transitions.easing.easeIn,
          duration: theme.transitions.duration.short,
        }),
      },

      [`& .${classes.tableBody}`]: {
        opacity: 1,
        transition: theme.transitions.create(['opacity'], {
          easing: theme.transitions.easing.easeIn,
          duration: theme.transitions.duration.short,
        }),
      },
    },
    table_updating: {
      height: '100%',

      [`& .${classes.loaderWrapper}`]: {
        opacity: 1,
      },
      [`& .${classes.tableBody}`]: {
        opacity: 0,
      },
    },
    tableScroll: {
      height: '100%',
      overflowY: 'auto',
    },
    tableHeader: {
      flexShrink: 0,
      flexGrow: 0,
      position: 'sticky',
      top: 0,
      zIndex: 1,
    },
    tableBody: {
      flexShrink: 0,
      flexGrow: 1,
      minHeight: theme.spacing(8),
      zIndex: 0,
    },
    tableFooterToolbar: {
      flexShrink: 0,
      flexGrow: 0,
      zIndex: 1,
    },
    loaderWrapper: {},
  };
});

export interface TableRef<DataType> {
  onSearchChange: (search: string | null) => void;
}

// eslint-disable-next-line @typescript-eslint/no-explicit-any
export interface TableProps<DataType extends object = any>
  extends BaseComponent<
    'div',
    Partial<ReturnType<typeof useStyles>['classes']>
  > {
  /**
   * The variant for the table.
   * condensed - will attempt to use as little space as possible for each row
   * regular - will default render each row removing extra data as required (such as reducing multi line to single line)
   * expanded - will show all data
   */
  variant?: TableBodyProps<DataType>['variant'];
  /**
   * The columns definitions for each column
   */
  columns: Field[];
  /**
   * The data to display
   */
  data: DataType[];
  /**
   * Array to use for initial sorting
   */
  sortBy?: {
    id: keyof DataType;
    desc?: boolean;
  }[];
  /**
   * Icon to display when required for the items in the table
   */
  entityIcon?: string;
  /**
   * The name of the items each row is representing
   */
  entityName?: string;
  /**
   * If the table is currently undergoing an update or not
   */
  updating?: boolean;
  /**
   * If provided will filter the rows finding rows where any
   * cell contains the filter text
   */
  globalFilter?: string;
  /**
   * Sets if the rows can be selected
   */
  selectable?: boolean;
  /**
   * If the table is selectable determines if an individual row is also selectable
   * @param data the data in the row being selected
   * @returns true if selectable, false otherwise
   */
  canSelectRow?: TableCanSelectRow<DataType>;

  tableRef?: ForwardedRef<TableRef<DataType>>;

  totalCount?: number;
  index?: number;
  pageSize?: number;

  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  getRowID?: (data: DataType, relativeIndex: number, parent?: any) => string;
  onSelectionChange?: (data: DataType[]) => void;
  onRowClick?: TableBodyProps<DataType>['onRowClick'];
  onRefresh?: TableFooterProps['onRefreshClick'];
  onFirstPage?: TableFooterProps['onFirstPageClick'];
  onPreviousPage?: TableFooterProps['onPreviousPageClick'];
  onNextPage?: TableFooterProps['onNextPageClick'];
  onLastPage?: TableFooterProps['onLastPageClick'];
  onPageSizeChange?: TableFooterProps['onPageSizeChange'];

  EmptyTableComponent?: ReactComponent<EmptyTableViewProps>;
}

// const TABLE_SETTINGS_ID = 'icat_table';
// /**
//  * Register the Table Settings with the settings provider
//  * so they can be managed by the user
//  * @type {[type]}
//  */
// registerSettings({
//   name : TABLE_SETTINGS_ID,
//   sectionName : 'userInterface',
//   label : 'table',
//   icon : 'table',
//   getInstanceSettingsID : ({match})=>{
//     return CryptoJS.MD5(match.path).toString();
//   },
//   fields : [
//     {
//       id : 'density',
//       type : 'select',
//       default : 'regular',
//       options : [{
//         id : 'condensed'
//       },{
//         id : 'regular',
//       },{
//         id : 'expanded',
//       }]
//     }, {
//       id : 'rowsPerPage',
//       type : 'select',
//       default : 10,
//       options : [
//         {
//           id : '10',
//           value : 10,
//         },{
//           id : '25',
//           value : 25,
//         },{
//           id : '50',
//           value : 50,
//         },{
//           id : '100',
//           value : 100,c
//         }
//       ]
//     }
//   ]
// });

// eslint-disable-next-line @typescript-eslint/no-explicit-any
export function Table<DataType extends object = any>({
  className,
  style,
  classes: classesProp,
  variant = 'condensed',
  columns,
  data = [],
  index,
  totalCount,
  pageSize,
  entityName,
  entityIcon,
  updating = false,
  sortBy = [],
  globalFilter,
  selectable = true,
  onRefresh,
  onFirstPage,
  onPreviousPage,
  onNextPage,
  onLastPage,
  getRowID,
  onRowClick,
  EmptyTableComponent = EmptyTableView,
  canSelectRow = () => true,
  onSelectionChange,
  onPageSizeChange,
  tableRef,
}: TableProps<DataType>) {
  const { classes, cx } = useStyles(undefined, {
    props: {
      classes: classesProp,
    },
  });

  if (!columns || columns.length === 0) {
    console.warn('column definitions not provided');
  }

  // Set the limits so we can display to the user
  index = index || 0;
  totalCount = totalCount || data.length;
  pageSize = pageSize || data.length;

  const { t } = useContext(LocalizationContext);

  entityName = entityName || t('rows');

  const columnDefinitions: Column<DataType>[] = useMemoDeepCompare(() => {
    return createReactTableColumns(columns, variant, canSelectRow);
  }, [columns, variant]);

  const sortByFields = useMemoDeepCompare(() => {
    return sortBy || [];
  }, [sortBy]);

  const globalFilterText = useMemo(() => {
    return globalFilter || undefined;
  }, [globalFilter]);

  const sortTypes = useMemo(() => {
    return {};
  }, []);

  const filterTypes = useMemo(() => {
    return {};
  }, []);

  const {
    getTableProps,
    getTableBodyProps,
    headerGroups,
    prepareRow,
    setGlobalFilter,
    page,
    selectedFlatRows,
    setPageSize,
    state: {
      // pageIndex,
      pageSize: tablePageSize,
      // pageCount
    },
  } = useTable<DataType>(
    {
      columns: columnDefinitions,
      data,
      getRowID,
      initialState: {
        sortBy: sortByFields,
        globalFilter: globalFilterText,
        selectedRowIds: {},

        // Pagination State
        manualPagination: true,
        pageSize: pageSize || 10,
        //pageIndex,
        //pageCount,
        //autoResetPage,
        //paginateExpandedRows
      },
      // useSortBy hook properties
      sortTypes: sortTypes,
      // useGlobalFilter hook properties
      filterTypes: filterTypes,
      // useRowSelect hook properties
      autoResetGlobalFilter: false,
      autoResetSelectedRows: false,
      // eslint-disable-next-line @typescript-eslint/no-explicit-any
    } as any,
    useFlexLayout,
    useGlobalFilter,
    useSortBy,
    // TODO: Implement pagination queries from server side
    usePagination,
    useRowSelect,
    // TODO: Implement column order
    // useColumnOrder,
    // TODO: Implement resize columns
    // useResizeColumn,
    // TODO: Implement column filters
    // useFilters,
    (hooks) => {
      if (!selectable) {
        return;
      }

      // If selectable add a column to allow the user to interact
      hooks.allColumns.push((columns) => [
        {
          id: 'table_selection',
          Header: TableHeaderSelectCell,
          Cell: TableBodySelectCell,
          disableSortBy: true,
          defaultCanSort: false,
          width: 56,
          maxWidth: 56,
        },
        ...columns,
      ]);
    }
  ) as TableInstance<DataType> & {
    // Extra properties due to plugins
    page: Row<DataType>[];
    setGlobalFilter: (filter?: string) => void;
    setPageSize: (size: number) => void;
    selectedFlatRows: DataType[];
    // TODO: type state correctly
    state: any;
  };

  useEffect(() => {
    setGlobalFilter(globalFilterText);
  }, [globalFilterText, setGlobalFilter]);

  useEffect(() => {
    setPageSize(pageSize || 10);
  }, [pageSize]);

  useDeepCompareEffect(() => {
    onSelectionChange && onSelectionChange(selectedFlatRows);
  }, [selectedFlatRows]);

  useImperativeHandle(
    tableRef,
    () => {
      return {
        onSearchChange: (search: string | null) => {
          setGlobalFilter(search || '');
        },
      };
    },
    [setGlobalFilter]
  );

  return (
    <TableContainer
      className={cx(classes.root, `root_variant_${variant}`, className)}
      style={style}
    >
      {data && data.length > 0 && (
        <>
          <div className={cx(classes.tableScroll)}>
            <MUITable
              className={cx(classes.table, updating && classes.table_updating)}
              {...getTableProps()}
            >
              <TableHeader
                className={cx(classes.tableHeader)}
                headerGroups={headerGroups}
              />
              {updating && (
                <tbody className={cx(classes.loaderWrapper)}>
                  <tr>
                    <td colSpan={columns.length}>
                      <Loader variant="circular" />
                    </td>
                  </tr>
                </tbody>
              )}
              {!updating && (
                <TableBody
                  className={cx(classes.tableBody)}
                  onRowClick={onRowClick}
                  prepareRow={(r) => {
                    prepareRow(r);
                    (r as any).canSelect = canSelectRow;
                  }}
                  page={page}
                  variant={variant}
                  {...getTableBodyProps()}
                />
              )}
            </MUITable>
          </div>
          <TableFooter
            className={cx(classes.tableFooterToolbar)}
            pageCount={data.length}
            totalCount={totalCount}
            index={index}
            pageSize={tablePageSize}
            entityName={entityName}
            onRefreshClick={() => {
              onRefresh && onRefresh();
            }}
            onFirstPageClick={() => {
              onFirstPage && onFirstPage();
            }}
            onPreviousPageClick={() => {
              onPreviousPage && onPreviousPage();
            }}
            onNextPageClick={() => {
              onNextPage && onNextPage();
            }}
            onLastPageClick={() => {
              onLastPage && onLastPage();
            }}
            onPageSizeChange={(size: PageSize | null) => {
              setPageSize(size?.value || 10);
              onPageSizeChange && onPageSizeChange(size);
            }}
          />
        </>
      )}

      {(!data || data.length === 0) && (
        <EmptyTableComponent
          getStateParams={() => ({
            updating: updating,
            entityIcon: entityIcon,
            entityName: entityName || '',
          })}
        />
      )}
    </TableContainer>
  );
}

export default Table;
