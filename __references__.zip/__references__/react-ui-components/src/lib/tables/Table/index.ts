export { Table as default } from './Table';
export * from './Table';
