import { render } from '@testing-library/react';

import Component from './Table';

describe('Table', () => {
  it('should render successfully', () => {
    const { baseElement } = render(<Component data={[]} columns={[]} />);
    expect(baseElement).toBeTruthy();
  });
});
