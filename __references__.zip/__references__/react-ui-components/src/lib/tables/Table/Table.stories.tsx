import { Meta, Story } from '@storybook/react';
import { Table as Component, TableProps } from './Table';

type TestDataType = {
  column1: string;
  column2: number;
  column3: boolean | undefined;
};

const data: TestDataType[] = [
  {
    column1: 'Boolean is true',
    column2: 123,
    column3: true,
  },
  {
    column1: `We'll put a happy little bush here.I spend a lot of time walking around in the woods and talking to trees, and squirrels, and little rabbits and stuff.You create the dream - then you bring it into your world.`,
    column2: 123,
    column3: false,
  },
  {
    column1: 'Boolean is undefined',
    column2: 123,
    column3: undefined,
  },
];

const meta: Meta = {
  component: Component,
  argTypes: {
    data: {
      control: 'select',
      options: ['None', 'Single', 'Page', 'MultiPage'],
      defaultValue: 'None',
      mapping: {
        None: [] as TestDataType[],
        Single: [data[0]] as TestDataType[],
        Page: [...data.slice(0, 10)] as TestDataType[],
        MultiPage: [...data] as TestDataType[],
      },
    },
  },
  parameters: {
    controls: { expanded: true },
  },
};

export default meta;

const Template: Story<TableProps> = (args) => {
  const { data, ...rest } = args;
  return (
    <Component
      {...rest}
      columns={[
        {
          id: 'column1',
          type: 'string',
          label: 'Column 1 Label',
        },
        {
          id: 'column2',
          type: 'number',
          label: 'Column 2 Label',
        },
        {
          id: 'column3',
          type: 'boolean',
          label: 'Column 3 Label',
        },
      ]}
      data={data}
    />
  );
};

export const Table = Template.bind({});
Table.args = {
  variant: 'regular',
  data: 'MultiPage',
  updating: false,
  onRowClick: (row) => {
    console.log('row clicked', row);
  },
  sortBy: [
    {
      id: 'column1',
    },
    {
      id: 'column2',
      desc: true,
    },
  ],
  globalFilter: 'happy',
  selectable: true,
  canSelectRow: (row, index) => {
    return index !== 2;
  },
} as Omit<TableProps<TestDataType>, 'data' | 'columns'> & {
  data: 'MultiPage' | 'None' | 'Page' | 'Single';
} as any;
