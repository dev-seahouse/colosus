import { DataRepository } from '@bambu/js-core';
import { render } from '@testing-library/react';

import Component from './RepositoryTable';

describe('RepositoryTable', () => {
  it('should render successfully', () => {
    const { baseElement } = render(
      <Component
        model={{
          fields: {},
          name: 'a test model',
          identityField: 'id',
          layout: [],
          listLayout: [],
          primaryTextField: 'name',
          title: 'a test model title',
          validate: () => ({}),
          generateModel: () => ({}),
        }}
        repository={
          new DataRepository({
            baseURL: 'https://test.com',
            dtoPath: 'a dto path',
          })
        }
      />
    );
    expect(baseElement).toBeTruthy();
  });
});
