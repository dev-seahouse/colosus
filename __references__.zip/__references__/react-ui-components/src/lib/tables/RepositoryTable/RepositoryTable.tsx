import { DataRepository, DtoType } from '@bambu/js-core';
import { useCallback, useLayoutEffect, useMemo } from 'react';
import { makeStyles } from 'tss-react/mui';
import { useRepository } from '../../hooks';
import { Field, Model } from '../../utilities';
import Table, { TableProps } from '../Table';
import { PageSize } from '../Table/components/TableFooter';

const useStyles = makeStyles()((/*theme*/) => {
  return {
    root: {},
  };
});

export interface RepositoryTableProps<DataType extends DtoType>
  extends Omit<TableProps, 'columns' | 'data'> {
  model: Model;
  repository: DataRepository<DataType>;
}

export interface RepositoryTableRef<DataType> {
  onSearchChange: (search: string | null) => void;
}

export function RepositoryTable<DataType extends DtoType>({
  className,
  style,
  classes: classesProp,
  repository,
  model,
  onRowClick,
  onSelectionChange,
  tableRef,
}: RepositoryTableProps<DataType>) {
  const { classes, cx } = useStyles(undefined, {
    props: {
      classes: classesProp,
    },
  });

  const [stateRepo, dataState] = useRepository(repository, [model]);
  const fieldDefinitions: Field[] = useMemo(() => {
    return model.listLayout.map((fieldID) => {
      return model.fields[fieldID];
    });
  }, [model]);

  useLayoutEffect(() => {
    const subscription = refreshData();
    return () => {
      subscription.unsubscribe();
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [model]);

  const { index, pageSize, totalCount } = dataState.page;

  const refreshData = useCallback(() => {
    return stateRepo
      .findAll({
        offset: index,
        // TODO: Page size needs to come from the table props (user selected)
        limit: pageSize || 25,
      })
      .subscribe();
  }, [stateRepo, index, pageSize]);

  const onFirstPage = useCallback(() => {
    stateRepo
      .findAll({
        offset: 0,
        limit: pageSize,
      })
      .subscribe();
  }, [pageSize, stateRepo]);

  const onPreviousPage = useCallback(() => {
    stateRepo
      .findAll({
        offset: index - pageSize,
        limit: pageSize,
      })
      .subscribe();
  }, [index, pageSize, stateRepo]);

  const onNextPage = useCallback(() => {
    stateRepo
      .findAll({
        offset: index + pageSize,
        limit: pageSize,
      })
      .subscribe();
  }, [index, pageSize, stateRepo]);

  const onLastPage = useCallback(() => {
    stateRepo
      .findAll({
        offset: totalCount - pageSize,
        limit: pageSize,
      })
      .subscribe();
  }, [pageSize, stateRepo, totalCount]);

  const onPageSizeChange = useCallback(
    (size: PageSize | null) => {
      return stateRepo
        .findAll({
          offset: index,
          limit: size?.value || 10,
        })
        .subscribe();
    },
    [stateRepo, index]
  );

  return (
    <Table
      className={cx(classes.root, className)}
      tableRef={tableRef}
      style={style}
      columns={fieldDefinitions}
      data={dataState.page.data}
      totalCount={dataState.page.totalCount}
      index={dataState.page.index}
      pageSize={dataState.page.pageSize}
      entityName={model.pluralTitle}
      entityIcon={model.icon}
      getRowID={(d: DataType) => {
        return (d as any)[model.identityField];
      }}
      updating={dataState.listing}
      onRefresh={() => {
        refreshData();
      }}
      onSelectionChange={onSelectionChange}
      onRowClick={onRowClick}
      onFirstPage={onFirstPage}
      onPreviousPage={onPreviousPage}
      onNextPage={onNextPage}
      onLastPage={onLastPage}
      onPageSizeChange={onPageSizeChange}
    />
  );
}

export default RepositoryTable;
