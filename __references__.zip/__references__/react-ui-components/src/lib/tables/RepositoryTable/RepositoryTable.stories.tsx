import { DtoType, getQueryParams } from '@bambu/js-core';
import { Meta, Story } from '@storybook/react';
import { createModelFields, createModelRepository } from '../../utilities';
import { RepositoryTable as Component } from './RepositoryTable';

const POKE_URL = 'https://pokeapi.co/api/v2';

const meta: Meta = {
  component: Component,
  argTypes: {},
  parameters: {
    controls: { expanded: true },
  },
};

export default meta;

class PokemonDto {
  id!: string;
  name!: string;
  url!: string;
  base_experience!: number;
  height!: number;
  is_default!: boolean;
  location_encounters: string;
  order: number;
  weight: number;
}

const repositoryDefinition = createModelRepository<PokemonDto & DtoType>({
  baseURL: POKE_URL,
  dtoPath: 'pokemon',
  model: {
    name: 'Pokémon',
    identityField: 'id',
    icon: 'catching_pokemon',
    fields: createModelFields<PokemonDto>({
      name: {
        type: 'string',
      },
      url: {
        type: 'string',
      },
      base_experience: {
        type: 'number',
      },
      height: {
        type: 'number',
      },
      is_default: {
        type: 'boolean',
      },
      location_encounters: {
        type: 'string',
      },
      order: {
        type: 'number',
      },
      weight: {
        type: 'number',
      },
    }),

    //   height: {
    //     id: 'height',
    //     type: 'number',
    //   },
    //   id: {
    //     id: 'id',
    //     type: 'number',
    //   },
    //   is_default: {
    //     id: 'is_default',
    //     type: 'boolean',
    //   },
    //   location_encounters: {
    //     id: 'location_encounters',
    //     type: 'url',
    //   },
    //   order: {
    //     id: 'order',
    //     type: 'number',
    //   },
    //   weight: {
    //     id: 'weight',
    //     type: 'number',
    //   },

    //   // TODO: This is a complex type
    //   // {
    //   //   "name": "venusaur",
    //   //   "url": "https://pokeapi.co/api/v2/pokemon-species/3/"
    //   // }
    //   species: {
    //     id: 'species',
    //     type: 'string',
    //   },

    //   // TODO: This is an array
    //   abilities: {
    //     id: 'abilities',
    //     type: 'string',
    //   },
    //   // TODO: This is an array
    //   forms: {
    //     id: 'forms',
    //     type: 'string',
    //   },
    //   // TODO: This is an array
    //   game_indices: {
    //     id: 'game_indices',
    //     type: 'string',
    //   },
    //   // TODO: This is an array
    //   held_items: {
    //     id: 'held_items',
    //     type: 'string',
    //   },
    //   // TODO: This is an array
    //   moves: {
    //     id: 'moves',
    //     type: 'string',
    //   },
    //   // TODO: This is an array
    //   past_types: {
    //     id: 'past_types',
    //     type: 'string',
    //   },

    //   // TODO: This is complex object
    //   sprites: {
    //     id: 'sprites',
    //     type: 'string',
    //   },

    //   // TODO: This is an array
    //   stats: {
    //     id: 'stats',
    //     type: 'string',
    //   },

    //   // TODO: This is an array
    //   types: {
    //     id: 'types',
    //     type: 'string',
    //   },
    // },

    listLayout: ['name', 'url'],
    layout: [
      ['name'],
      ['base_experience'],
      ['height'],
      ['id'],
      ['is_default'],
      ['location_encounters'],
      ['order'],
      ['weight'],
    ],
  },
  transforms: {
    // {"count":1154,"next":"https://pokeapi.co/api/v2/pokemon?offset=20&limit=20","previous":null,"results":[{"name":"bulbasaur","url":"https://pokeapi.co/api/v2/pokemon/1/"},{"name":"ivysaur","url":"https://pokeapi.co/api/v2/pokemon/2/"},{"name":"venusaur","url":"https://pokeapi.co/api/v2/pokemon/3/"},{"name":"charmander","url":"https://pokeapi.co/api/v2/pokemon/4/"},{"name":"charmeleon","url":"https://pokeapi.co/api/v2/pokemon/5/"},{"name":"charizard","url":"https://pokeapi.co/api/v2/pokemon/6/"},{"name":"squirtle","url":"https://pokeapi.co/api/v2/pokemon/7/"},{"name":"wartortle","url":"https://pokeapi.co/api/v2/pokemon/8/"},{"name":"blastoise","url":"https://pokeapi.co/api/v2/pokemon/9/"},{"name":"caterpie","url":"https://pokeapi.co/api/v2/pokemon/10/"},{"name":"metapod","url":"https://pokeapi.co/api/v2/pokemon/11/"},{"name":"butterfree","url":"https://pokeapi.co/api/v2/pokemon/12/"},{"name":"weedle","url":"https://pokeapi.co/api/v2/pokemon/13/"},{"name":"kakuna","url":"https://pokeapi.co/api/v2/pokemon/14/"},{"name":"beedrill","url":"https://pokeapi.co/api/v2/pokemon/15/"},{"name":"pidgey","url":"https://pokeapi.co/api/v2/pokemon/16/"},{"name":"pidgeotto","url":"https://pokeapi.co/api/v2/pokemon/17/"},{"name":"pidgeot","url":"https://pokeapi.co/api/v2/pokemon/18/"},{"name":"rattata","url":"https://pokeapi.co/api/v2/pokemon/19/"},{"name":"raticate","url":"https://pokeapi.co/api/v2/pokemon/20/"}]}
    pagedResult(data: any) {
      // In this case we use the prev and next fields to discover which page we are on
      const previousParams = getQueryParams(data.previous || '');
      const nextParams = getQueryParams(data.next || '');
      const prevOffset = previousParams.offset
        ? Number(previousParams.offset)
        : 0;
      const prevLimit = previousParams.limit ? Number(previousParams.limit) : 0;
      const nextOffset = nextParams.offset ? Number(nextParams.offset) : 0;
      const nextLimit = nextParams.limit ? Number(nextParams.limit) : 0;

      const baseURL = POKE_URL;

      return {
        data: data.results.map((p: PokemonDto) => {
          return {
            ...p,
            id: p.url.split('/').at(-2),
          };
        }),
        totalCount: data.count,
        index: prevOffset + prevLimit,
        pageSize: prevLimit || data.results.length,
        pageInfo: {
          hasNextPage: Boolean(data.next),
          hasPreviousPage: Boolean(data.previous),
          nextPage: data.next
            ? `${baseURL}?offset=${nextOffset}&limit=${nextLimit}`
            : undefined,
          previousPage: data.next
            ? `${baseURL}?offset=${prevOffset}&limit=${prevLimit}`
            : undefined,
        },
      };
    },
  },
});

const Template: Story<PokemonDto> = (args) => {
  const descriptor = repositoryDefinition.getDescriptor();

  const [repository, data] = repositoryDefinition.useRepository([]);

  return <Component {...args} model={descriptor} repository={repository} />;
};

export const RepositoryTable = Template.bind({});
RepositoryTable.args = {};
