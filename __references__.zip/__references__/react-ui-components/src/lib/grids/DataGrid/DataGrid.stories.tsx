import { Meta, Story } from '@storybook/react';
import { DataGrid as Component, DataGridProps } from './DataGrid';

const meta: Meta = {
  component: Component,
  argTypes: {},
  parameters: {
    controls: { expanded: true },
  },
};

export default meta;

const Template: Story<DataGridProps> = (args) => <Component {...args} />;

export const DataGrid = Template.bind({});
DataGrid.args = {};
