import { DtoType } from '@bambu/js-core';
import { ReactNode } from 'react';
import { makeStyles } from 'tss-react/mui';
import { ErrorWrapper } from '../../errors';
import { Loader } from '../../progress';
import { BaseComponent } from '../../types';

type StyleProps = {
  columns: number;
  gap: number;
};

const useStyles = makeStyles<StyleProps>()((theme, { columns, gap = 1 }) => {
  const columnTemplate = Array(columns).fill('minmax(0, 1fr)').join(' ');
  const mdColumnTemplate = Array(columns).fill('minmax(0, 1fr)').join(' ');

  return {
    root: {
      width: '100%',
      height: '100%',
    },
    errorWrapper: {
      flexGrow: 0,
    },
    gridWrapper: {
      width: '100%',
      height: '100%',
      display: 'grid',
      gridTemplateColumns: columnTemplate,
      gridTemplateRows: 'auto auto auto',
      gap: theme.spacing(gap),
      padding: theme.spacing(0.25),

      [theme.breakpoints.down('md')]: {
        gridTemplateColumns: mdColumnTemplate,
      },

      [theme.breakpoints.down('sm')]: {
        gridTemplateColumns: 'minmax(0, 1fr)',
      },
    },
  };
});

export interface DataGridProps<DataType extends DtoType>
  extends BaseComponent<
    'span',
    Partial<ReturnType<typeof useStyles>['classes']>
  > {
  errors?: {
    message: string;
  }[];
  data: DataType[];
  columns?: number;
  itemComponent: (data: DataType) => ReactNode;
  loading?: boolean;
  gap?: number;
}

export function DataGrid<DataType extends DtoType>({
  className,
  style,
  classes: classesProp,
  errors = [],
  data = [],
  columns = 3,
  gap = 1,
  itemComponent,
  loading = false,
}: DataGridProps<DataType>) {
  const { classes, cx } = useStyles(
    {
      columns,
      gap,
    },
    {
      props: {
        classes: classesProp,
      },
    }
  );

  return (
    <div className={cx(classes.root, className)} style={style}>
      {errors && errors.length > 0 && (
        <ErrorWrapper
          className={cx(classes.errorWrapper)}
          errors={errors}
          variant="condensed"
        />
      )}
      {loading && <Loader variant="circular" />}
      {!loading && (
        <div className={cx(classes.gridWrapper)}>{data.map(itemComponent)}</div>
      )}
    </div>
  );
}

export default DataGrid;
