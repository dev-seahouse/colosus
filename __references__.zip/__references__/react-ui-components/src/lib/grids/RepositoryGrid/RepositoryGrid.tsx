import { DataRepository, DtoObserverState, DtoType } from '@bambu/js-core';
import { useContext, useEffect, useMemo, useState } from 'react';
import { makeStyles } from 'tss-react/mui';
import { useObservable } from '../../hooks';
import { LocalizationContext } from '../../i18n';
import { Field, Model } from '../../utilities';
import DataGrid, { DataGridProps } from '../DataGrid';

const useStyles = makeStyles()((/*theme*/) => {
  return {
    root: {},
  };
});

// eslint-disable-next-line @typescript-eslint/no-empty-interface
export interface RepositoryGridProps<DataType extends DtoType>
  extends Omit<DataGridProps<DataType>, 'errors' | 'data' | 'loading'> {
  model: Model;
  repository: DataRepository<DataType>;
}

export function RepositoryGrid<DataType extends DtoType>({
  className,
  style,
  classes: classesProp,
  repository,
  model,
  itemComponent,
  ...rest
}: RepositoryGridProps<DataType>) {
  const { classes, cx } = useStyles(undefined, {
    props: {
      classes: classesProp,
    },
  });

  const { t } = useContext(LocalizationContext);
  const [dataState, setDataState] = useState<DtoObserverState<DataType>>(
    repository.getState()
  );

  useObservable<DtoObserverState<DataType>>(
    repository.getObservable(),
    setDataState,
    []
  );

  useEffect(() => {
    repository.findAll();
  }, [repository]);

  return (
    <DataGrid
      className={cx(classes.root, className)}
      style={style}
      errors={dataState.errors.map((e) => ({
        message: t(...e),
      }))}
      data={dataState.page.data}
      itemComponent={itemComponent}
      loading={dataState.listing}
      {...rest}
    />
  );
}

export default RepositoryGrid;
