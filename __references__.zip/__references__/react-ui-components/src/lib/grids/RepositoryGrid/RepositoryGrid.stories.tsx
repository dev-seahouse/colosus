import { Meta, Story } from '@storybook/react';
import {
  RepositoryGrid as Component,
  RepositoryGridProps,
} from './RepositoryGrid';

const meta: Meta = {
  component: Component,
  argTypes: {},
  parameters: {
    controls: { expanded: true },
  },
};

export default meta;

const Template: Story<RepositoryGridProps> = (args) => <Component {...args} />;

export const RepositoryGrid = Template.bind({});
RepositoryGrid.args = {};
