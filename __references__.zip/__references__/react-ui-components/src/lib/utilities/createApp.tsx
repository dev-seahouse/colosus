/*global gtag*/

import { useEffect } from 'react';
import { App, AppProps } from '../application';
import { IApplicationRepositories } from '../repositories';
import axios, { AxiosInstance } from '../services/axiosService';

// export function reportWebVitals({
//     name,
//     delta,
//     value,
//     id
// }){
//     if (gtag !== undefined) {
//         gtag('event', name, {
//             value : delta,
//             metric_id : id,
//             metric_value : value,
//             metric_delta : delta,
//             nonInteraction  :true,
//             transport : 'beacon'
//         });
//     }
// }

export interface ApplicationConfig {
  name: string;
  logo: string;
  description?: string;
  featureImage?: string;
  environment?: string;
  author: {
    name: string;
    logo: string;
    url: string;
  };
}

export interface CreateAppProps<
  ComponentProps extends Record<string, any> = Record<string, any>,
  CustomProps extends Record<string, any> = Record<string, any>
> extends AppProps<ComponentProps, CustomProps> {
  configureAxios?: (
    axios: AxiosInstance,
    config: ApplicationConfig,
    custom: CustomProps
  ) => () => void;
  createRepositories?: (
    config: ApplicationConfig,
    custom: CustomProps,
    axios: AxiosInstance
  ) => IApplicationRepositories;
}

export type AppContainerProps = Omit<
  AppProps,
  'store' | 'modules' | 'themes' | 'routes' | 'config'
>;

export function createApp<
  CustomProps extends Record<string, any> = Record<string, any>
>(props: CreateAppProps<Record<string, any>, CustomProps>) {
  const { createRepositories, configureAxios, ...appWrapperProps } = props;
  let repositories: IApplicationRepositories | undefined = undefined;
  if (createRepositories) {
    repositories = createRepositories(
      props.config,
      props.custom || ({} as CustomProps),
      axios
    );
  }
  const AppContainer = ({
    DefaultComponent = props.DefaultComponent,
    defaultComponentProps = props.defaultComponentProps,
    ...rest
  }: AppContainerProps) => {
    useEffect(() => {
      if (configureAxios) {
        return configureAxios(
          axios,
          props.config,
          props.custom || ({} as CustomProps)
        );
      }
      return () => {
        // Nothing to do here
      };
    }, []);

    return (
      <App
        {...appWrapperProps}
        DefaultComponent={DefaultComponent}
        defaultComponentProps={defaultComponentProps}
        {...rest}
        repositories={repositories}
      />
    );
  };

  return AppContainer;
}

export default createApp;
