function localStore(key: string, value?: any) {
  if (value !== undefined) {
    // Set the local storage
    localStorage.setItem(key, JSON.stringify(value));
  }
  return JSON.parse(localStorage.getItem(key) || 'null');
}

export default localStore;
