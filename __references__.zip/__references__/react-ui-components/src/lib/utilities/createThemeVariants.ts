import {
  ColorPalette,
  createColorPalette,
  ThemeDeclaration,
  tinycolor,
  _,
} from '@bambu/js-core';
import { createTheme, ThemeOptions } from '@mui/material/styles';

const greys = {
  '50': '#fafafa',
  '100': '#f5f5f5',
  '200': '#eeeeee',
  '300': '#e0e0e0',
  '400': '#bdbdbd',
  '500': '#9e9e9e',
  '600': '#757575',
  '700': '#616161',
  '800': '#424242',
  '900': '#212121',
  A100: '#d5d5d5',
  A200: '#aaaaaa',
  A400: '#303030',
  A700: '#616161',
};

export function createThemeVariants(
  theme: ThemeDeclaration,
  overrides: Partial<ThemeOptions> = {}
) {
  const { name, palette: basePalette, mode = 'light' } = theme;
  const mainPalette = createColorPalette(basePalette);
  const tint = (basePalette.tint as number) || 0;
  const severityTint = Math.min(10, 100 - tint);

  const backgrounds = {
    light:
      mode === 'light'
        ? {
            paper: (basePalette as any).background?.paper || '#ffffff',
            default: (basePalette as any).background?.default || '#fafafa',
          }
        : {
            paper: '#ffffff',
            default: '#fafafa',
          },
    dark:
      mode === 'dark'
        ? {
            paper: (basePalette as any).background?.paper || '#424242',
            default: (basePalette as any).background?.default || '#303030',
          }
        : {
            paper: '#424242',
            default: '#303030',
          },
  };

  return {
    [name]: createTheme(
      _.merge(
        {},
        defaultThemeOptions,
        {
          palette: mainPalette,
        },
        {
          ...requiredThemeOptions,
        },
        {
          ...overrides,
          palette: {
            mode: mode,
            background: {
              paper: tinycolor(backgrounds[mode].paper)
                .mix(mainPalette.secondary[mode], severityTint)
                .toHex8String(),
              default: tinycolor(backgrounds[mode].default)
                .mix(mainPalette.secondary[mode], severityTint)
                .toHex8String(),
            },
            grey: Object.entries(greys).reduce(
              (acc: Record<string, string>, [key, color]) => {
                acc[key] = tinycolor(color)
                  .mix(mainPalette.secondary[mode], severityTint)
                  .toHex8String();
                return acc;
              },
              {}
            ),
          },
        },
        {
          mixins: extendThemeWithMixins(mainPalette),
        }
      )
    ),
    [`${name}Dark`]: createTheme(
      _.merge(
        {},
        defaultThemeOptions,
        {
          palette: Object.entries(mainPalette).reduce(
            (acc: any, [key, swatch]) => {
              acc[key] = {
                main: swatch?.light,
              };
              return acc;
            },
            {}
          ),
        },
        {
          ...requiredThemeOptions,
        },
        {
          ...overrides,
          palette: {
            mode: 'dark',
            background: {
              paper: tinycolor(backgrounds.dark.paper)
                .mix(mainPalette.secondary.dark, severityTint)
                .toHex8String(),
              default: tinycolor(backgrounds.dark.default)
                .mix(mainPalette.secondary.dark, severityTint)
                .toHex8String(),
            },
            grey: Object.entries(greys).reduce(
              (acc: Record<string, string>, [key, color]) => {
                acc[key] = tinycolor(color)
                  .mix(mainPalette.secondary.dark, severityTint)
                  .toHex8String();
                return acc;
              },
              {}
            ),
          },
        },
        {
          mixins: extendThemeWithMixins(mainPalette),
        }
      )
    ),
    [`${name}Light`]: createTheme(
      _.merge(
        {},
        defaultThemeOptions,
        {
          palette: Object.entries(mainPalette).reduce(
            (acc: any, [key, swatch]) => {
              acc[key] = {
                main: swatch?.dark,
              };
              return acc;
            },
            {}
          ),
        },
        {
          ...requiredThemeOptions,
        },
        {
          ...overrides,
          palette: {
            mode: 'light',
            background: {
              paper: tinycolor(backgrounds.light.paper)
                .mix(mainPalette.secondary.light, severityTint)
                .toHex8String(),
              default: tinycolor(backgrounds.light.default)
                .mix(mainPalette.secondary.light, severityTint)
                .toHex8String(),
            },
            grey: Object.entries(greys).reduce(
              (acc: Record<string, string>, [key, color]) => {
                acc[key] = tinycolor(color)
                  .mix(mainPalette.secondary.light, severityTint)
                  .toHex8String();
                return acc;
              },
              {}
            ),
          },
        },
        {
          mixins: extendThemeWithMixins(mainPalette),
        }
      )
    ),
  };
}

/**
 * THEME DEFAULTS
 */
export const defaultThemeOptions: Partial<ThemeOptions> = {
  typography: {
    fontFamily: ['Muli', 'Roboto', 'Helvetica', 'Arial', 'sans-serif'].join(
      ','
    ),
    fontWeightLight: 300,
    fontWeightRegular: 400,
    fontWeightMedium: 600,
  },
};

export const requiredThemeOptions: Partial<ThemeOptions> = {
  typography: {
    htmlFontSize: 10,
    fontSize: 10,
    // body1       : {
    //   fontSize: '1.4rem',
    // },
    // body2       : {
    //   fontSize: '1.4rem',
    // }
  },
};

export function extendThemeWithMixins(palette: ColorPalette) {
  return {
    border: (width = 1) => ({
      borderWidth: width,
      borderStyle: 'solid',
      borderColor: (palette as any)['divider'],
    }),
    borderLeft: (width = 1) => ({
      borderLeftWidth: width,
      borderStyle: 'solid',
      borderColor: (palette as any)['divider'],
    }),
    borderRight: (width = 1) => ({
      borderRightWidth: width,
      borderStyle: 'solid',
      borderColor: (palette as any)['divider'],
    }),
    borderTop: (width = 1) => ({
      borderTopWidth: width,
      borderStyle: 'solid',
      borderColor: (palette as any)['divider'],
    }),
    borderBottom: (width = 1) => ({
      borderBottomWidth: width,
      borderStyle: 'solid',
      borderColor: (palette as any)['divider'],
    }),
  };
}
