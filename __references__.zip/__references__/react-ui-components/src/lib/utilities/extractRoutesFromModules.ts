import { _ } from '@bambu/js-core';
import { IndexRouteDefinition, ModuleConfig, RouteDefinition } from '../types';

/**
 * Extracts the routes that can be used with react router from
 * the modules that have been specified
 * @param modules The modules to extract the routes for
 * @returns the route definitions from the modules
 */
export function extractRoutesFromModules(modules: ModuleConfig<any, any>[]) {
  const accumulator: RouteDefinition[] = [];
  // Top level modules must provide a layout
  const errors = modules
    .filter((m) => m.enabled)
    .map((m) => {
      if (!m.layout) {
        return `${m.name} is a top level module so must provide a layout`;
      }
      return null;
    })
    .filter((i) => i);
  if (errors.length > 0) {
    throw new Error(errors.join('/n'));
  }

  extractRoutesRecursive(accumulator, modules);
  return accumulator;
}

function extractRoutesRecursive(
  accumulator: RouteDefinition[],
  module: ModuleConfig<any, any> | ModuleConfig<any, any>[]
) {
  if (Array.isArray(module)) {
    // This is an array of modules, so iterate through each
    module
      .filter((m) => m.enabled)
      .forEach((m) => extractRoutesRecursive(accumulator, m));
  } else {
    extractRoutesFromModule(accumulator, module);
  }
}

function extractRoutesFromModule(
  accumulator: RouteDefinition[],
  module: ModuleConfig<any, any>,
  currentRoute?: RouteDefinition,
  currentPath = ''
) {
  let route: RouteDefinition;
  const parentPath =
    currentPath === '' || currentPath === '/' ? '' : `${currentPath}/`;
  const moduleTitle = module.title || module.name;
  const modulePath = `${module.path || _.camelCase(moduleTitle)}`;
  const absolutePath = `${parentPath}${modulePath}`;

  if (module.layout && !module.isChildLayout) {
    // This route contains a layout so will be a top level route
    route = {
      title: moduleTitle,
      icon: module.icon || undefined,
      navigation: module.navigation || false,
      component: module.layout || null,
      componentProps: module.layoutComponentProps || undefined,
      auth: module.auth || undefined,
      routes: module.component
        ? [
            {
              title: moduleTitle,
              icon: module.icon || undefined,
              navigation: module.navigation || false,
              component: module.component || undefined,
              componentProps: module.componentProps || undefined,
              auth: module.auth || undefined,
              routes: undefined,
              index: true,
            } as IndexRouteDefinition,
          ]
        : // If the module has routes we will need to include them
        module.routes
        ? []
        : undefined,
      path: modulePath,
      absolutePath: absolutePath,
      index: false,
    };
    accumulator.push(route);
  } else if (module.layout && module.isChildLayout) {
    // This route contains a layout but is intended to be a child layout
    route = {
      title: moduleTitle,
      icon: module.icon || undefined,
      navigation: module.navigation || false,
      component: module.layout || null,
      componentProps: module.layoutComponentProps || undefined,
      auth: module.auth || undefined,
      routes: module.component
        ? [
            {
              title: moduleTitle,
              icon: module.icon || undefined,
              navigation: module.navigation || false,
              component: module.component || undefined,
              componentProps: module.componentProps || undefined,
              auth: module.auth || undefined,
              routes: undefined,
              index: true,
            } as IndexRouteDefinition,
          ]
        : // If the module has routes we will need to include them
        module.routes
        ? []
        : undefined,
      path: modulePath,
      absolutePath: absolutePath,
      index: false,
    };
    if (currentRoute) {
      if (!currentRoute.routes) {
        currentRoute.routes = [];
      }
      currentRoute.routes.push(route);
    } else {
      accumulator.push(route);
    }
  } else {
    // The route is added in to the hierarchy
    route = {
      title: moduleTitle,
      icon: module.icon || undefined,
      navigation: module.navigation || false,
      component: module.component,
      componentProps: module.componentProps || undefined,
      auth: module.auth || undefined,
      routes: undefined,
      path: modulePath,
      absolutePath: absolutePath,
      index: false,
    };
    if (currentRoute) {
      if (!currentRoute.routes) {
        currentRoute.routes = [];
      }
      currentRoute.routes.push(route);
    } else {
      accumulator.push(route);
    }
  }

  // Add the explicit routes
  if (module.routes) {
    if (!route.routes) {
      route.routes = [];
    }
    route.routes.push(...cloneRoutes(module.routes));
  }
  // Add the submodule routes
  if (module.modules) {
    (module.modules as ModuleConfig[]).forEach((m) => {
      extractRoutesFromModule(accumulator, m, route, absolutePath);
    });
  }
}

export function cloneRoutes(routes: RouteDefinition[]): RouteDefinition[] {
  return routes.map((r) => {
    return {
      title: r?.title,
      icon: r?.icon,
      navigation: r?.navigation || false,
      path: r.path,
      component: r.component,
      componentProps: r.componentProps,
      routes: r.routes ? cloneRoutes(r.routes) : undefined,
      auth: r.auth,
      index: r.index,
      caseSensitive: r.caseSensitive,
    } as RouteDefinition;
  });
}

export default extractRoutesFromModules;
