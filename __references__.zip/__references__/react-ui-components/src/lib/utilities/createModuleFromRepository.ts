import { _ } from '@bambu/js-core';
import { JSXElementConstructor } from 'react';
import {
  LayoutContainerProps,
  ModuleConfig,
  ModuleConfigFunction,
} from '../modules';
import { IApplicationRepositories } from '../repositories';
import { ApplicationConfig } from './createApp';

export type RepositoryModuleProps<
  LayoutComponentProps extends LayoutContainerProps,
  LayoutComponent extends JSXElementConstructor<LayoutComponentProps> = JSXElementConstructor<LayoutComponentProps>,
  Repository extends string = string,
  Definition extends string = string
> = ModuleConfig<undefined, LayoutComponentProps, LayoutComponent> & {
  name: Repository;
  definition: Definition;
};

export function createModuleFromRepository<
  LayoutComponentProps extends LayoutContainerProps,
  LayoutComponent extends JSXElementConstructor<LayoutComponentProps> = JSXElementConstructor<LayoutComponentProps>,
  Repository extends string = string,
  Definition extends string = string
>(
  repositoryName: Repository,
  repositoryDefinition: Definition,
  layout: LayoutComponent,
  layoutComponentProps?: LayoutComponentProps,
  overrides?: Partial<
    RepositoryModuleProps<
      LayoutComponentProps,
      LayoutComponent,
      Repository,
      Definition
    >
  >
): ModuleConfigFunction<undefined, LayoutComponentProps, LayoutComponent> {
  return (
    repositories: IApplicationRepositories,
    config?: {
      application?: ApplicationConfig;
      custom?: any;
    }
  ) => {
    const repository = repositories[repositoryName];
    if (!repository) {
      throw new Error(
        `The application repository '${repositoryName}' does not exist in this application`
      );
    }
    const dataDefinition = repository.getDefinition(repositoryDefinition);
    if (!dataDefinition) {
      console.error('use one of ', Object.keys(repository.getDefinitions()));
      throw new Error(
        `The data definition for '${repositoryDefinition}' does not exist in the repository '${repositoryName}'`
      );
    }

    const dataDescriptor = dataDefinition.getDescriptor();
    const { icon, name, pluralTitle } = dataDescriptor;

    const repositoryDefaultProps = {
      name: name,
      title: pluralTitle,
      icon: icon,
      enabled: true,
      path: `${name}/*`,
      navigation: true,
      index: true,
      layout: layout,
      layoutComponentProps: layoutComponentProps,
      isChildLayout: true,
      routes: [
        {
          index: true,
          component: 'div',
        },
        {
          path: 'new',
          component: 'div',
        },
        {
          path: ':recordID',
          component: 'div',
        },
      ],
    };

    return _.merge(
      {},
      repositoryDefaultProps,
      overrides
    ) as RepositoryModuleProps<
      LayoutComponentProps,
      LayoutComponent,
      Repository,
      Definition
    >;
  };
}
