function redirectTo(
  url: string,
  params?: Record<string, any>,
  hashParams?: Record<string, any>
) {
  const redirect =
    url +
    (params
      ? (url.indexOf('?') ? '?' : '&') +
        Object.keys(params)
          .map((key) => `${key}=${encodeURIComponent(params[key])}`)
          .join('&')
      : '') +
    (hashParams
      ? (url.indexOf('#') ? '#' : '&') +
        Object.keys(hashParams)
          .map((key) => `${key}=${encodeURIComponent(hashParams[key])}`)
          .join('&')
      : '');

  window.location.href = redirect;
}

export default redirectTo;
