import DefaultLayout from '../layouts/DefaultLayout';
import { ReactModuleConfig } from '../types';
import { extractRoutesFromModules as sut } from './extractRoutesFromModules';

const RouteTestComponent = () => {
  return <div>nothing</div>;
};

const testModules: ReactModuleConfig<any, any>[] = [
  {
    enabled: false,
    name: 'Disabled Module',
    modules: [],
  },
  {
    enabled: true,
    name: 'No Layout Module',
    modules: [],
  },
  {
    enabled: true,
    name: 'Layout Only',
    modules: [],
    layout: DefaultLayout,
  },
  {
    enabled: true,
    name: 'Layout Only',
    modules: [],
    path: '/',
    layout: DefaultLayout,
  },
  {
    enabled: true,
    name: 'Layout and component',
    modules: [],
    path: '/',
    layout: DefaultLayout,
    component: RouteTestComponent,
  },
  {
    enabled: true,
    name: 'Explicit Routes',
    modules: [],
    layout: DefaultLayout,
    component: RouteTestComponent,
    routes: [
      {
        title: 'route 1',
        path: 'route1',
        component: RouteTestComponent,
        index: false,
      },
      {
        title: 'route 2',
        path: 'route2',
        component: RouteTestComponent,
        index: false,
        routes: [
          {
            title: 'route 2.1',
            path: 'route2.1',
            component: RouteTestComponent,
            index: false,
          },
        ],
      },
    ],
  },
  {
    enabled: true,
    name: 'Module with Component',
    modules: [],
    component: RouteTestComponent,
  },
];

describe('extractRoutesFromModules', () => {
  it('will return an empty list if no modules are provided', () => {
    expect(sut([])).toStrictEqual([]);
  });

  it('will ignore modules that are disabled', () => {
    const input: ReactModuleConfig[] = [testModules[0]];
    expect(sut(input as any)).toStrictEqual([]);
  });

  it('will throw an error if no layouts are specified', () => {
    const input: ReactModuleConfig[] = [testModules[1]];
    expect(() => sut(input as any)).toThrow(
      'No Layout Module is a top level module so must provide a layout'
    );

    expect(() => sut([testModules[2] as any, testModules[1] as any])).toThrow(
      'No Layout Module is a top level module so must provide a layout'
    );
  });

  it('will provide a base route to render layout', () => {
    const input: ReactModuleConfig[] = [testModules[2]];
    expect(sut(input as any)).toStrictEqual([
      {
        title: 'Layout Only',
        icon: undefined,
        navigation: false,
        path: 'layoutOnly',
        absolutePath: 'layoutOnly',
        component: DefaultLayout,
        componentProps: undefined,
        routes: undefined,
        auth: undefined,
        index: false,
      },
    ]);
  });

  it('will use the path provided in the module if available', () => {
    const input: ReactModuleConfig[] = [testModules[3]];
    expect(sut(input as any)).toStrictEqual([
      {
        title: 'Layout Only',
        icon: undefined,
        navigation: false,
        path: '/',
        absolutePath: '/',
        component: DefaultLayout,
        componentProps: undefined,
        routes: undefined,
        auth: undefined,
        index: false,
      },
    ]);
  });

  it('will provide a layout and index route if both a layout and component are specified', () => {
    const input: ReactModuleConfig[] = [testModules[4]];
    expect(sut(input as any)).toStrictEqual([
      {
        title: 'Layout and component',
        icon: undefined,
        navigation: false,
        path: '/',
        absolutePath: '/',
        component: DefaultLayout,
        componentProps: undefined,
        routes: [
          {
            title: 'Layout and component',
            icon: undefined,
            navigation: false,
            index: true,
            component: RouteTestComponent,
            componentProps: undefined,
            routes: undefined,
            auth: undefined,
          },
        ],
        auth: undefined,
        index: false,
      },
    ]);
  });

  it('will extract explict routes defined on the module', () => {
    const input: ReactModuleConfig[] = [testModules[5]];
    expect(sut(input as any)).toStrictEqual([
      {
        title: 'Explicit Routes',
        icon: undefined,
        navigation: false,
        path: 'explicitRoutes',
        absolutePath: 'explicitRoutes',
        component: DefaultLayout,
        componentProps: undefined,
        auth: undefined,
        index: false,
        routes: [
          {
            auth: undefined,
            componentProps: undefined,
            icon: undefined,
            navigation: false,
            title: 'Explicit Routes',
            component: RouteTestComponent,
            index: true,
            routes: undefined,
          },
          {
            auth: undefined,
            caseSensitive: undefined,
            componentProps: undefined,
            icon: undefined,
            navigation: false,
            routes: undefined,
            title: 'route 1',
            path: 'route1',
            component: RouteTestComponent,
            index: false,
          },
          {
            auth: undefined,
            caseSensitive: undefined,
            componentProps: undefined,
            icon: undefined,
            navigation: false,
            title: 'route 2',
            path: 'route2',
            component: RouteTestComponent,
            index: false,
            routes: [
              {
                auth: undefined,
                caseSensitive: undefined,
                componentProps: undefined,
                icon: undefined,
                navigation: false,
                routes: undefined,
                title: 'route 2.1',
                path: 'route2.1',
                component: RouteTestComponent,
                index: false,
              },
            ],
          },
        ],
      },
    ]);
  });

  it('will extract modules recursively', () => {
    const recursiveModules = {
      ...testModules[3],
      modules: [testModules[6]],
    };
    const input: ReactModuleConfig[] = [recursiveModules as any];
    expect(sut(input as any)).toStrictEqual([
      {
        title: 'Layout Only',
        icon: undefined,
        navigation: false,
        path: '/',
        absolutePath: '/',
        component: DefaultLayout,
        componentProps: undefined,
        auth: undefined,
        index: false,
        routes: [
          {
            title: 'Module with Component',
            icon: undefined,
            navigation: false,
            path: 'moduleWithComponent',
            absolutePath: 'moduleWithComponent',
            component: RouteTestComponent,
            componentProps: undefined,
            auth: undefined,
            index: false,
            routes: undefined,
          },
        ],
      },
    ]);
  });

  it('will ensure layouts are pulled to top level', () => {
    const recursiveModules = {
      ...testModules[3],
      modules: [
        {
          ...testModules[6],
          modules: [testModules[5]],
        },
      ],
    };
    const input: ReactModuleConfig[] = [recursiveModules as any];
    expect(sut(input as any)).toStrictEqual([
      {
        title: 'Layout Only',
        icon: undefined,
        navigation: false,
        path: '/',
        absolutePath: '/',
        component: DefaultLayout,
        componentProps: undefined,
        auth: undefined,
        index: false,
        routes: [
          {
            title: 'Module with Component',
            icon: undefined,
            navigation: false,
            path: 'moduleWithComponent',
            absolutePath: 'moduleWithComponent',
            component: RouteTestComponent,
            componentProps: undefined,
            auth: undefined,
            index: false,
            routes: undefined,
          },
        ],
      },
      {
        title: 'Explicit Routes',
        icon: undefined,
        navigation: false,
        path: 'explicitRoutes',
        absolutePath: 'moduleWithComponent/explicitRoutes',
        component: DefaultLayout,
        componentProps: undefined,
        auth: undefined,
        index: false,
        routes: [
          {
            auth: undefined,
            componentProps: undefined,
            icon: undefined,
            navigation: false,
            title: 'Explicit Routes',
            component: RouteTestComponent,
            index: true,
            routes: undefined,
          },
          {
            auth: undefined,
            caseSensitive: undefined,
            componentProps: undefined,
            icon: undefined,
            navigation: false,
            routes: undefined,
            title: 'route 1',
            path: 'route1',
            component: RouteTestComponent,
            index: false,
          },
          {
            auth: undefined,
            caseSensitive: undefined,
            componentProps: undefined,
            icon: undefined,
            navigation: false,
            title: 'route 2',
            path: 'route2',
            component: RouteTestComponent,
            index: false,
            routes: [
              {
                auth: undefined,
                caseSensitive: undefined,
                componentProps: undefined,
                icon: undefined,
                navigation: false,
                routes: undefined,
                title: 'route 2.1',
                path: 'route2.1',
                component: RouteTestComponent,
                index: false,
              },
            ],
          },
        ],
      },
    ]);
  });
});
