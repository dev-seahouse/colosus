import { DataRepository, DtoType } from '@bambu/js-core';
import { Typography } from '@mui/material';
import { Meta, Story } from '@storybook/react';
import { SyntheticEvent, useState } from 'react';
import { MemoryRouter } from 'react-router-dom';
import { catchError, of, tap } from 'rxjs';
import { Button } from '../buttons';
import { Container } from '../containers';
import { useApplicationRepository } from '../hooks';
import DefaultLayout from '../layouts/DefaultLayout';
import { ApplicationRepositoryBase } from '../repositories';
import { createTokenRefreshInterceptor } from '../services';
import createApp from './createApp';
import createModelRepository, {
  RepositoryFactory,
} from './createModelRepository';

const MOCK_URL = 'https://mocks.mock.com';
const MOCK_DTO_PATH = 'test/response';

const meta: Meta = {
  title: 'utilities/CreateApp',
  argTypes: {},
  parameters: {
    controls: { expanded: true },
    mockData: [
      {
        url: `${MOCK_URL}/${MOCK_DTO_PATH}/200`,
        method: 'GET',
        status: 200,
        response: {
          id: '200 - ID',
        },
      },
      {
        url: `${MOCK_URL}/${MOCK_DTO_PATH}/401`,
        method: 'GET',
        status: 401,
        response: () => {
          console.info('Retrieving 401');
        },
      },
      {
        url: `${MOCK_URL}/${MOCK_DTO_PATH}/404`,
        method: 'GET',
        status: 404,
        response: {
          id: '404 - ID',
        },
      },
      {
        url: `${MOCK_URL}/refresh_endpoint`,
        method: 'POST',
        status: 200,
        response: () => {
          console.info('attempting refresh');
          return {
            id: 'refreshed',
          };
        },
      },
    ],
  },
};

export default meta;

class TestApplicationRepositories extends ApplicationRepositoryBase {
  protected createDefinitions(): Record<string, RepositoryFactory<any>> {
    return {
      testEndpoint: createModelRepository<DtoType>({
        baseURL: this.baseURL,
        dtoPath: MOCK_DTO_PATH,
        axios: this.axios,
        model: {},
      }),
    };
  }
}

function TestView() {
  const [output, setOutput] = useState<string>('No Messages');
  const createButtonHandler = (
    requestType: '200' | '401' | '404',
    repository: DataRepository<DtoType>
  ) => {
    return (e: SyntheticEvent) => {
      repository
        .findOne(requestType)
        .pipe(
          catchError((err) => {
            return of({
              id: err.message,
            });
          }),
          tap((value) => {
            if (value) {
              setOutput(value?.id);
            }
          })
        )
        .subscribe();
    };
  };

  const { repository } = useApplicationRepository(
    'application',
    'testEndpoint'
  );

  return (
    <Container>
      <Typography>Click the buttons to test the axios interceptor</Typography>

      <Button onClick={createButtonHandler('200', repository)}>200</Button>
      <Button
        onClick={(e) => {
          setOutput('Check the console to see that the refresh was attempted');
          createButtonHandler('401', repository)(e);
        }}
      >
        401
      </Button>
      <Button onClick={createButtonHandler('404', repository)}>404</Button>
      <Typography>{output}</Typography>
    </Container>
  );
}

const Template: Story<any> = (args) => {
  const App = createApp({
    store: {},
    config: {
      name: 'Create App Testing',
      logo: 'a logo',
      featureImage: 'a feature image',
      author: {
        name: 'an author',
        logo: 'an author logo',
        url: 'an author url',
      },
      environment: 'storybook',
    },
    themes: [
      {
        name: 'default',
        mode: 'light',
        palette: {
          tint: 10,
          primary: '#6366F1',
          secondary: '#737373',
          background: {
            default: '#000000',
            paper: '#151515',
          },
          complimentary: '#f1ee63',
        },
      },
    ],
    modules: [
      {
        name: 'Storybook',
        title: 'Storybook Root Module',
        layout: DefaultLayout,
        enabled: true,
        path: '*',
      },
    ],
    configureAxios: (axios, config, customConfig) => {
      // create a token refresh interceptor
      const interceptors = createTokenRefreshInterceptor(
        axios,
        `${MOCK_URL}/refresh_endpoint`
      );
      return () => {
        console.info('ejecting interceptors');
        axios.interceptors.response.eject(interceptors);
      };
    },
    createRepositories: (config, customConfig, axios) => {
      return {
        application: new TestApplicationRepositories({
          baseURL: MOCK_URL,
          axios,
        }),
      };
    },
  });
  return <App Router={MemoryRouter} DefaultComponent={TestView} />;
};

export const CreateApp = Template.bind({});
CreateApp.args = {};
