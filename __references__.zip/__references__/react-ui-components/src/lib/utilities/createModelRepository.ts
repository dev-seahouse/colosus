import {
  DataRepository,
  DtoObserverState,
  DtoType,
  ObservableDataTransforms,
  _,
} from '@bambu/js-core';
import { AxiosInstance } from '../services/axiosService';

import {
  useObservableRepository,
  useObservableRepositoryProps,
} from '../hooks';
import createModel, {
  FieldDefinition,
  Model,
  ModelDefinition,
} from './createModel';

function normaliseModel(
  path: string,
  modelDefinition?: Partial<ModelDefinition>
): Model {
  const derivedName = path.split('/').pop() || path;
  return createModel(
    _.merge(
      {},
      {
        name: derivedName,
        fields: {},
      },
      modelDefinition || {}
    )
  );
}

export type RepositoryFactory<T extends DtoType = any> = {
  getDescriptor(): Model;
  useRepository: (deps?: any[]) => [DataRepository<T>, DtoObserverState<T>];
  createRepository: (
    args: Partial<useObservableRepositoryProps<T>>
  ) => [DataRepository<T>, DtoObserverState<T>];
};

export function createModelFields<T>(
  fields: Record<keyof Omit<T, 'id'>, FieldDefinition>
): Model<T & DtoType>['fields'] {
  return Object.entries(fields).reduce(
    (acc, [id, field]) => {
      acc[id as keyof T] = {
        ...(field as FieldDefinition),
        id: id,
      };
      return acc;
    },
    {
      id: {
        id: 'id',
        type: 'string',
        readonly: true,
      },
    } as Model<T & DtoType>['fields']
  );
}

function createModelRepository<T extends DtoType>(props: {
  baseURL: string;
  dtoPath: string;
  model?: Partial<Model<T>>;
  axios?: AxiosInstance;
  transforms?: ObservableDataTransforms<T>;
}) {
  // TODO: Need to resolve the differences between Model and ModelDefinition
  const descriptor = normaliseModel(
    props.dtoPath,
    props.model as Partial<ModelDefinition>
  );

  // If the model has an identityField then add a transform to convert to id
  const { transforms = {}, model } = props;
  if (model?.identityField) {
    // Redeclaring because of TS
    const identityField = model.identityField;
    if (!transforms.dtoTransforms) {
      transforms.dtoTransforms = [];
    }
    transforms.dtoTransforms.unshift((d: any) => {
      d.id = d[identityField];
      // We don't actually know if d is of type T at this point
      // as there could be other transforms
      return d;
    });
  }

  return {
    getDescriptor() {
      return descriptor;
    },
    useRepository: (deps?: any[]) => {
      return useObservableRepository<T>(
        {
          dtoPath: props.dtoPath,
          baseURL: props.baseURL,
          global: false,
          axios: props.axios,
          transforms: transforms,
        },
        deps || []
      );
    },
    createRepository: (
      args: Partial<useObservableRepositoryProps<T>>,
      deps?: any[]
    ) => {
      // eslint-disable-next-line react-hooks/rules-of-hooks
      return useObservableRepository<T>(
        _.merge(
          {},
          {
            dtoPath: props.dtoPath,
            baseURL: props.baseURL,
            global: false,
            axios: props.axios,
            transforms: transforms,
          },
          args
        ),
        deps || []
      );
    },
  };
}

export default createModelRepository;
