import DefaultLayout from '../layouts/DefaultLayout';
import { ReactModuleConfig } from '../types';
import { resolveModules as sut } from './resolveModules';

const RouteTestComponent = () => {
  return <div>nothing</div>;
};

const testModules: ReactModuleConfig<any, any, any>[] = [
  {
    enabled: false,
    name: 'Disabled Module',
    modules: [],
  },
  {
    enabled: true,
    name: 'No Layout Module',
    modules: [],
  },
  {
    enabled: true,
    name: 'Layout Only',
    modules: [],
    layout: DefaultLayout,
  },
  {
    enabled: true,
    name: 'Layout Only',
    modules: [],
    auth: ['superuser'],
    path: '/',
    layout: DefaultLayout,
  },
  {
    enabled: true,
    name: 'Layout and component',
    modules: [],
    path: '/',
    layout: DefaultLayout,
    component: RouteTestComponent,
  },
  {
    enabled: true,
    name: 'Explicit Routes',
    modules: [],
    layout: DefaultLayout,
    component: RouteTestComponent,
    routes: [
      {
        title: 'route 1',
        path: 'route1',
        component: RouteTestComponent,
        index: false,
      },
      {
        title: 'route 2',
        path: 'route2',
        component: RouteTestComponent,
        index: false,
        routes: [
          {
            title: 'route 2.1',
            path: 'route2.1',
            component: RouteTestComponent,
            index: false,
          },
        ],
      },
    ],
  },
  {
    enabled: true,
    name: 'Module with Component',
    modules: [],
    component: RouteTestComponent,
  },
];

describe('extractRoutesFromModules', () => {
  it('will return an empty list if no modules are provided', () => {
    expect(sut([])).toStrictEqual([]);
  });

  it('will ignore modules that are disabled', () => {
    const input: ReactModuleConfig[] = [testModules[0]];
    expect(sut(input)).toStrictEqual([]);
  });

  it('will propagate the auth', () => {
    const recursiveModules = {
      ...testModules[3],
      modules: [testModules[6]],
    } as ReactModuleConfig;

    const input: ReactModuleConfig[] = [recursiveModules];
    expect(sut(input)).toStrictEqual([
      {
        auth: ['superuser'],
        component: undefined,
        componentProps: undefined,
        enabled: true,
        icon: undefined,
        layout: DefaultLayout,
        layoutComponentProps: undefined,
        isChildLayout: false,
        name: 'Layout Only',
        // Note the "pluralisation"
        title: 'Layout Onlies',
        navigation: false,
        path: '/',
        fullPath: '/',
        routes: undefined,
        modules: [
          {
            auth: ['superuser'],
            component: RouteTestComponent,
            componentProps: undefined,
            enabled: true,
            icon: undefined,
            layout: undefined,
            layoutComponentProps: undefined,
            isChildLayout: false,
            // Note the "pluralisation"
            title: 'Module With Components',
            name: 'Module with Component',
            navigation: false,
            path: 'moduleWithComponent',
            fullPath: '/moduleWithComponent',
            routes: undefined,
            modules: undefined,
          },
        ],
      },
    ]);
  });
});
