import { _ } from '@bambu/js-core';
import pluralize from 'pluralize';
import { ResolvedModule } from '../modules';
import { IApplicationRepositories } from '../repositories';
import {
  isModuleConfigFunction,
  ModuleConfig,
  ReactModuleConfig,
} from '../types';
import { ApplicationConfig } from './createApp';
import { cloneRoutes } from './extractRoutesFromModules';

type ModuleResolutionConfig = {
  application?: ApplicationConfig;
  custom?: any;
};

function resolveRecursive(
  module: ReactModuleConfig,
  parentModule?: ModuleConfig,
  repositories?: IApplicationRepositories,
  config?: ModuleResolutionConfig
): ResolvedModule {
  // Resolve functional modules
  const resolvedModule = isModuleConfigFunction(module)
    ? module(repositories || {}, config)
    : module;

  const resolvedPath =
    resolvedModule.path === undefined
      ? _.camelCase(module.name)
      : resolvedModule.path;
  const parentPath = parentModule?.path
    ? parentModule.path === '/'
      ? parentModule.path
      : parentModule.path + '/'
    : '';

  const normalisedModule = {
    name: resolvedModule.name,
    icon: resolvedModule.icon,
    navigation: resolvedModule.navigation || false,
    component: resolvedModule.component,
    componentProps: resolvedModule.componentProps,
    title: resolvedModule.title || pluralize(_.startCase(module.name)),
    path: resolvedPath,
    fullPath: `${parentPath}${resolvedPath}`,
    // The AUTH is propagated to make it easier to check if the user is in ALL roles allowed for a route
    auth:
      resolvedModule.auth || parentModule?.auth
        ? [
            ...Array.from(
              new Set([
                ...(resolvedModule.auth || []),
                ...(parentModule?.auth || []),
              ])
            ),
          ]
        : undefined,
    enabled: resolvedModule.enabled,
    layout: resolvedModule.layout,
    layoutComponentProps: resolvedModule.layoutComponentProps,
    isChildLayout: Boolean(resolvedModule.isChildLayout),
    routes: resolvedModule.routes
      ? cloneRoutes(resolvedModule.routes)
      : undefined,
    // Modules are resolved after as the auth needs to be propagated
    modules: undefined,
  } as ResolvedModule;

  const childModules = resolvedModule.modules || [];

  // Resolve modules and routes
  if (childModules.length > 0) {
    normalisedModule.modules = childModules
      .map((m) => resolveRecursive(m, normalisedModule, repositories, config))
      .filter((m) => m.enabled);
  }
  return normalisedModule;
}

/**
 * Ensures that all paths, layouts, auth, and enabled properties are
 * propagated through the hierarchy
 * to make it easier to deal with in the routing logic
 */
export function resolveModules(
  modules: ReactModuleConfig<any, any>[],
  repositories?: IApplicationRepositories,
  config?: ModuleResolutionConfig
): ResolvedModule<any, any>[] {
  if (!modules || modules.length === 0) {
    return [];
  }
  return modules
    .map((m) => resolveRecursive(m, undefined, repositories, config))
    .filter((m) => m.enabled);
}

export default resolveModules;
