import { I18NArguments, Primitive } from '@bambu/js-core';
import _ from 'lodash';
import pluralize from 'pluralize';
import { ReactElement } from 'react';
import { createLengthConstraint } from '../forms/EntityView/validations';

type DynamicFieldDefinition = {
  /**
   * The default value when generating a new model
   */
  default?: null | Primitive | ((overrides: any) => Primitive) | null;
  /**
   * The description of this field
   */
  description?: string;
  /**
   * if this field should be included when generating a new model
   */
  excludeFromModel?: boolean;
  /**
   * Converts the field to a string value
   */
  format?: <T>(value: T) => string;
  /**
   * Helper to extract a value for this field,
   * useful for complex data.
   */
  // TODO: data should be typed to an object of the type that this field belongs to
  getValue?: (data: any) => any;
  /**
   * The content to display in the label for this field
   */
  label?: string;
  /**
   * The min length of the value allowed in this field
   */
  minLength?: number;
  /**
   * The max length of the value allowed in this field
   */
  maxLength?: number;
  /**
   * If this field is required or not
   */
  required?: boolean;
  /**
   * If this field is readonly or editable
   */
  readonly?: boolean;
  /**
   * The placeholder to display when displaying an editor for this field
   */
  placeholder?: string;
  /**
   * The type of this field.  Helps the framework determine
   * which editor to display when editing the field
   */
  type: string;
  /**
   * This list of validations to apply to this field
   */
  validations?: ((
    data: any,
    field: EntityField,
    value: any,
    model: Model<any>
  ) => I18NArguments | null)[];
  /**
   * Properties to pass when creating an editor for this
   * field
   */
  componentProps?: any;
};

type ComponentFieldDefinition = {
  render: () => ReactElement;
  getValue: DynamicFieldDefinition['getValue'];
};

export type FieldDefinition = DynamicFieldDefinition | ComponentFieldDefinition;

export type EntityField = DynamicFieldDefinition & {
  id: string;
};

type ComponentField = {
  render: () => ReactElement;
  id: string;
  getValue?: EntityField['getValue'];
};

export type Field = EntityField | ComponentField;

export type ModelDefinition<Fields = Record<string, FieldDefinition>> = {
  /**
   * The name of this model
   */
  name: string;
  /**
   * The field to use for the identity of this model, defaults to 'id' if not provided
   */
  identityField?: string;
  /**
   * The field to use when displaying a title for the record.
   * If not provided this will default to the first field with 'string' type
   */
  primaryTextField?: string;
  /**
   * The field to use when displaying a description for the record
   */
  secondaryTextField?: string;
  /**
   * The field to use when displaying a feature image for the record
   */
  featureImageField?: string;
  /**
   * The title of the entity, will default to the name field if not provided
   */
  title?: string;
  /**
   * The singular representation of this model, will be derived from the 'title' field
   * if not provided
   */
  singularTitle?: string;
  /**
   * The plural representation of this model, will be derived from the 'title' field
   * if not provided
   */
  pluralTitle?: string;
  /**
   * The icon to display when representing this model
   */
  icon?: string;
  /**
   * The list of field definitions in order preference
   */
  fields: Fields;
  /**
   * Orders and customises the display of fields.  If not defined will
   * display all fields in 'fields' in the order they are found
   */
  layout?: (keyof Fields)[][];
  /**
   * Used to layout the model when being displayed in a list or grid
   * alongside other similar models
   */
  listLayout?: (keyof Fields)[];

  /**
   * Validation function to use when validating the full data object, if not
   * defined will assume that the data is valid if all field validators are valid.
   *
   * If this is defined it will replace any field level validation
   */
  validate?: (
    data: Record<keyof Fields, any>,
    field: keyof Fields | (keyof Fields)[],
    errors: {
      [k in keyof Fields]?: I18NArguments[];
    }
  ) => {
    [k in keyof Fields]?: I18NArguments[];
  };

  /**
   * The list of child entities in a parent/child relationship
   */
  children?: ModelDefinition<any>[];

  /**
   * A helper function to generate a new data structure for this model
   */
  generateModel?: (
    overrides?: Partial<Record<keyof Fields, any>>
  ) => Partial<Record<keyof Fields, any>>;
};

export type Model<
  DataType = Record<string, any>,
  Fields = Record<keyof DataType, Field>
> = {
  name: string;
  identityField: string;
  primaryTextField: string;
  secondaryTextField?: string;
  featureImageField?: string;
  title: string;
  singularTitle?: string;
  pluralTitle?: string;
  icon?: string;
  fields: Fields;
  layout: (keyof Fields)[][];
  listLayout: (keyof Fields)[];
  generateModel: (
    overrides?: Partial<Record<keyof Fields, any>>
  ) => Partial<Record<keyof Fields, any>>;
  validate: (
    data: Partial<Record<keyof Fields, any>>,
    field?: keyof Fields | (keyof Fields)[],
    errors?: {
      [k in keyof Fields]?: I18NArguments[];
    }
  ) => {
    [k in keyof Fields]?: I18NArguments[];
  };
  //   children?: ModelDefinition<any>[];
};

function isComponentFieldDefinition(
  field: FieldDefinition
): field is ComponentFieldDefinition {
  return (field as ComponentFieldDefinition).render !== undefined;
}

export function isComponentField(field: Field): field is ComponentField {
  return (field as ComponentField).render !== undefined;
}

function normaliseValidations(
  field: EntityField,
  validations?: ((
    data: any,
    field: EntityField,
    value: any,
    model: Model<any>
  ) => I18NArguments | null)[]
) {
  const normalisedValidations = [...(validations || [])];

  // Add min and max validations
  if (
    (field.minLength !== null && field.minLength !== undefined) ||
    (field.maxLength !== null && field.maxLength !== undefined)
  ) {
    normalisedValidations.unshift(
      createLengthConstraint(field.minLength, field.maxLength)
    );
  }

  // Ensure required fields validate correctly
  if (field.required) {
    normalisedValidations.unshift((data, field, value, model) => {
      const { label } = field;
      return !value || (value.trim && value.trim() === '')
        ? ['{0} is required', label]
        : null;
    });
  }
  return normalisedValidations.filter((i) => i);
}

function normaliseField(key: string, field: FieldDefinition): Field {
  if (isComponentFieldDefinition(field)) {
    return {
      id: key,
      render: field.render,
      getValue: field.getValue,
    };
  } else {
    const normalisedField: EntityField = {
      type: field.type,
      id: key,
      label: field.label || _.startCase(key),
      description: field.description,
      placeholder: field.placeholder,
      required: field.required || false,
      readonly: field.readonly || false,
      format: field.format,
      getValue: field.getValue,
      excludeFromModel: field.excludeFromModel || false,
      default: field.default || null,
      validations: [],
      componentProps: field.componentProps,
      minLength: field.minLength,
      maxLength: field.maxLength,
    };
    normalisedField.validations = normaliseValidations(
      normalisedField,
      field.validations
    );
    return normalisedField;
  }
}

function createModel<
  T extends Record<string, FieldDefinition> = Record<string, FieldDefinition>
>(modelDefinition: ModelDefinition<T>): Model<Record<keyof T, Field>> {
  // Extract the layout
  const layout =
    modelDefinition.layout ||
    (Object.keys(modelDefinition.fields).map((f) => [f]) as (keyof T)[][]);

  const modelTitle = modelDefinition.title || _.startCase(modelDefinition.name);

  const fieldNames = Object.keys(modelDefinition.fields) as (keyof T)[];

  const fields = Object.entries(modelDefinition.fields).reduce(
    (
      acc: Record<keyof T, Field>,
      [key, fieldDefinition]: [a: keyof T, b: FieldDefinition]
    ) => {
      acc[key] = normaliseField(key as string, fieldDefinition);
      return acc;
    },
    {} as Record<keyof T, Field>
  );

  const model: Omit<Model<Record<keyof T, Field>>, 'validate'> & {
    validate?: (
      data: Record<keyof T, any>,
      field: keyof T | (keyof T)[],
      errors: {
        [k in keyof T]?: I18NArguments[];
      }
    ) => {
      [k in keyof T]?: I18NArguments[];
    };
  } = {
    name: modelDefinition.name,
    identityField: modelDefinition.identityField || 'id',
    primaryTextField:
      modelDefinition.primaryTextField ||
      Object.keys(fields).find(
        (field) => (fields[field] as DynamicFieldDefinition).type === 'string'
      ) ||
      '',
    secondaryTextField: modelDefinition.secondaryTextField,
    featureImageField: modelDefinition.featureImageField,
    icon: modelDefinition.icon,
    title: modelTitle,
    singularTitle:
      modelDefinition.singularTitle || pluralize.singular(modelTitle),
    pluralTitle: modelDefinition.pluralTitle || pluralize(modelTitle),
    fields: fields,
    layout: layout,
    listLayout:
      modelDefinition.listLayout ||
      layout.flatMap((l) => {
        return Array.isArray(l) ? l : [l];
      }),
    generateModel:
      modelDefinition.generateModel ||
      ((overrides?: Partial<Record<keyof T, any>>) => {
        return (
          Object.keys(fields)
            .map((fieldName) => fields[fieldName])
            .filter((field) => !isComponentField(field))
            // Typescript doesn't pick up the guard in a filter
            .map((field) => field as EntityField)
            .filter((field) => !field.excludeFromModel)
            .reduce((acc, field) => {
              acc[field.id as keyof T] =
                field.default === undefined || field.default === null
                  ? // There was not default value, so use the overrides or null
                    (overrides && overrides[field.id]) || null
                  : // Use the default, if a function call with overrides
                  typeof field.default === 'function'
                  ? field.default(overrides)
                  : field.default;
              return acc;
            }, {} as Partial<Record<keyof T, any>>)
        );
      }),
  };

  model.validate =
    modelDefinition.validate ||
    ((data, field = fieldNames, errors = {}) => {
      // If the field is not an array, make it one so that we can treat everything the same
      field = Array.isArray(field) ? field : [field];

      return field.reduce((acc, fieldName) => {
        const fieldDef = fields[fieldName];
        if (!isComponentField(fieldDef)) {
          acc[fieldName as keyof T] = (fieldDef.validations || [])
            .map((validate) => {
              return validate(data, fieldDef, data[fieldDef.id], model as any);
            })
            .filter((error) => error) as I18NArguments[];
        }
        return acc;
      }, errors);
    });

  return model as Model<Record<keyof T, Field>>;
}

export default createModel;
