import { makeStyles } from 'tss-react/mui';
import { MouseEventHandler } from 'react';
import { IconButton } from '../../buttons';
import { BaseComponent, ComponentColor, ComponentSize } from '../../types';

const useStyles = makeStyles()((/*theme*/) => {
  return {
    root: {},
  };
});

export interface CommandPanelItemProps
  extends Omit<
    BaseComponent<'span', Partial<ReturnType<typeof useStyles>['classes']>>,
    'onClick'
  > {
  icon: string;
  size?: ComponentSize;
  color?: ComponentColor;
  onClick: MouseEventHandler<HTMLButtonElement>;
  title: string;
}

export function CommandPanelItem({
  className,
  style,
  classes: classesProp,
  icon,
  size,
  color = 'inherit',
  onClick,
  title,
  ...rest
}: CommandPanelItemProps) {
  const { classes, cx } = useStyles(undefined, {
    props: {
      classes: classesProp,
    },
  });

  return (
    <div className={cx(classes.root, className)} style={style}>
      <IconButton
        icon={icon}
        size={size}
        color={color}
        onClick={onClick}
        title={title}
      />
    </div>
  );
}

export default CommandPanelItem;
