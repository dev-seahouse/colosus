import { Drawer, DrawerProps } from '@mui/material';
import { forwardRef } from 'react';
import { makeStyles } from 'tss-react/mui';

const useStyles = makeStyles()((theme) => {
  return {
    root: {
      boxSizing: 'content-box',
    },
    drawerContent: {
      display: 'flex',
      flexDirection: 'column',
      height: '100%',
      maxWidth: '100%',
      overflow: 'hidden',
    },
  };
});

export type ContextPanelPosition = 'left' | 'right' | 'top' | 'bottom' | 'none';

export interface ContextPanelProps extends DrawerProps {
  position?: ContextPanelPosition;
  open?: boolean;
  classes?: Partial<ReturnType<typeof useStyles>['classes']>;
}

export const ContextPanel = forwardRef<HTMLDivElement, ContextPanelProps>(
  (
    {
      className,
      style,
      children,
      classes: classesProp,
      position = 'bottom',
      open = false,
      PaperProps = {},
      ...rest
    }: ContextPanelProps,
    ref
  ) => {
    const { classes, cx } = useStyles(undefined, {
      props: {
        classes: classesProp,
      },
    });

    return position !== 'none' ? (
      <Drawer
        ref={ref}
        className={cx(classes.root, className)}
        style={style}
        anchor={position}
        open={open}
        variant="persistent"
        PaperProps={{
          ...PaperProps,
          style: {
            ...PaperProps.style,
            boxSizing: 'border-box',
            overflow: 'hidden',
          },
        }}
        {...rest}
      >
        <div className={cx(classes.drawerContent)}>{children}</div>
      </Drawer>
    ) : null;
  }
);

export default ContextPanel;
