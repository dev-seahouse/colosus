import { Meta, Story } from '@storybook/react';
import { ContextPanel as Component, ContextPanelProps } from './ContextPanel';

const meta: Meta = {
  component: Component,
  argTypes: {},
  parameters: {
    controls: { expanded: true },
  },
};

export default meta;

const Template: Story<ContextPanelProps> = (args) => <Component {...args} />;

export const ContextPanel = Template.bind({});
ContextPanel.args = {
  children: 'A Button',
  open: true,
  position: 'left',
};
