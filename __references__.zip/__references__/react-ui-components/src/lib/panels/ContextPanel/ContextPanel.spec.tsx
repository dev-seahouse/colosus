import { render } from '@testing-library/react';

import ContextPanel from './ContextPanel';

describe(ContextPanel.name, () => {
  it('should render successfully', () => {
    const { baseElement } = render(<ContextPanel>Some Content</ContextPanel>);
    expect(baseElement).toBeTruthy();
  });
});
