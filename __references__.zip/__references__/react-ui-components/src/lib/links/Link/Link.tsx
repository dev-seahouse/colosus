import { makeStyles } from 'tss-react/mui';
import { Link as MuiLink, LinkProps as MuiLinkProps } from '@mui/material';
import { Icon } from '../../icons';
import { ComponentColor } from '../../types';
import { tinycolor } from '@bambu/js-core';

type StyleProps = {
  color: ComponentColor;
};

const useStyles = makeStyles<StyleProps>()((theme, { color }) => {
  let palette: {
    main: string;
    light: string;
    dark: string;
    contrastText?: string;
  } | null = null;
  if (color === 'disabled') {
    palette = {
      main: theme.palette.action.disabled,
      light: theme.palette.action.disabled,
      dark: theme.palette.action.disabled,
      contrastText: theme.palette.getContrastText(theme.palette.action.active),
    };
  } else if (color === 'action') {
    palette = {
      main: theme.palette.action.active,
      light: theme.palette.action.active,
      dark: theme.palette.action.active,
      contrastText: theme.palette.getContrastText(theme.palette.action.active),
    };
  } else if (color !== 'inherit') {
    palette = theme.palette[color];
  }

  return {
    root: {
      display: 'inline-flex',
      flexDirection: 'row',
      alignItems: 'center',
      color: palette
        ? theme.palette.mode === 'dark' && tinycolor(palette.main).isDark()
          ? palette.light
          : palette.main
        : undefined,
    },
    icon: {
      fontSize: theme.spacing(2),
      marginLeft: theme.spacing(0.5),
    },
  };
});

export interface LinkProps
  extends Omit<
    MuiLinkProps,
    | 'color'
    | 'border'
    | 'borderTop'
    | 'borderRight'
    | 'borderBottom'
    | 'borderLeft'
    | 'borderRadius'
    | 'borderColor'
    | 'display'
    | 'displayPrint'
    | 'overflow'
    | 'textOverflow'
    | 'visibility'
    | 'whiteSpace'
    | 'flexBasis'
    | 'flexDirection'
    | 'flexWrap'
    | 'justifyContent'
    | 'alignItems'
    | 'alignContent'
    | 'order'
    | 'flex'
    | 'flexGrow'
    | 'flexShrink'
    | 'alignSelf'
    | 'justifyItems'
    | 'justifySelf'
    | 'gap'
    | 'columnGap'
    | 'rowGap'
    | 'gridColumn'
    | 'gridRow'
    | 'gridAutoFlow'
    | 'gridAutoColumns'
    | 'gridAutoRows'
    | 'gridTemplateColumns'
    | 'gridTemplateRows'
    | 'gridTemplateAreas'
    | 'gridArea'
    | 'bgcolor'
    | 'zIndex'
    | 'position'
    | 'top'
    | 'right'
    | 'bottom'
    | 'left'
    | 'boxShadow'
    | 'width'
    | 'height'
    | 'maxWidth'
    | 'maxHeight'
    | 'minWidth'
    | 'minHeight'
    | 'boxSizing'
    | 'm'
    | 'mt'
    | 'mr'
    | 'mb'
    | 'mx'
    | 'my'
    | 'ml'
    | 'p'
    | 'pt'
    | 'pr'
    | 'pb'
    | 'px'
    | 'py'
    | 'pl'
    | 'margin'
    | 'marginTop'
    | 'marginRight'
    | 'marginBottom'
    | 'marginLeft'
    | 'marginX'
    | 'marginY'
    | 'padding'
    | 'paddingTop'
    | 'paddingRight'
    | 'paddingBottom'
    | 'paddingLeft'
    | 'paddingX'
    | 'paddingY'
    | 'letterSpacing'
    | 'lineHeight'
    | 'textAlign'
    | 'textTransform'
    | 'typography'
    | 'fontFamily'
    | 'fontSize'
    | 'fontStyle'
    | 'fontWeight'
    | 'align'
    | 'paragraph'
  > {
  /**
   * The icon to display; set to undefined or null to hide the icon
   */
  icon?: string | 'none';
  /**
   * Classes overrides
   */
  classes?: Partial<ReturnType<typeof useStyles>['classes']>;
  /**
   * The color of the content
   */
  color?: ComponentColor;
}

export function Link({
  className,
  style,
  classes: classesProp,
  target = '_blank',
  children,
  icon,
  underline = 'hover',
  color = 'inherit',
  ...rest
}: LinkProps) {
  const { classes, cx } = useStyles(
    {
      color,
    },
    {
      props: {
        classes: classesProp,
      },
    }
  );

  if (icon === 'none') {
    icon = undefined;
  } else if (!icon) {
    icon = target === '_blank' ? 'open_in_new' : 'link';
  }
  return (
    <MuiLink
      className={cx(classes.root, className)}
      underline={underline}
      color="inherit"
      target={target}
      {...rest}
    >
      {children}
      {icon && (
        <Icon className={cx(classes.icon)} size="small">
          {icon}
        </Icon>
      )}
    </MuiLink>
  );
}

export default Link;
