import { Meta, Story } from '@storybook/react';
import { Link as Component, LinkProps } from './Link';

const meta: Meta = {
  component: Component,
  argTypes: {},
  parameters: {
    controls: { expanded: true },
  },
};

export default meta;

const Template: Story<LinkProps> = (args) => <Component {...args} />;

export const Link = Template.bind({});
Link.args = {
  href: 'https://www.bambu.com',
  target: '_blank',
  children: 'bambu',
};
