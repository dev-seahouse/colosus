import { IconButtonProps } from '@mui/material';
import { MouseEvent, useCallback, useMemo } from 'react';
import {
  NavigateOptions,
  Path,
  useNavigate,
  useResolvedPath,
} from 'react-router-dom';
import { makeStyles } from 'tss-react/mui';
import { Button, ButtonProps, IconButton } from '../../buttons';
import { BaseComponent, ComponentColor } from '../../types';
import { Link, LinkProps } from '../Link';

const useStyles = makeStyles()((/*theme*/) => {
  return {
    root: {},
  };
});

// eslint-disable-next-line @typescript-eslint/no-empty-interface
export interface BaseRouteLinkProps
  extends BaseComponent<
    'span',
    Partial<ReturnType<typeof useStyles>['classes']>
  > {
  title: string;
  to: string | Partial<Path>;
  color?: ComponentColor;
  icon?: string;
  navigationOptions?: NavigateOptions;
}

export interface RouteLinkLinkProps extends BaseRouteLinkProps {
  variant?: 'link';
  LinkProps?: Omit<LinkProps, 'href' | 'target' | 'icon' | 'color' | 'onClick'>;
  IconButtonProps?: undefined;
  ButtonProps?: undefined;
}

export interface RouteLinkIconButtonProps extends BaseRouteLinkProps {
  variant: 'iconButton';
  IconButtonProps?: Omit<IconButtonProps, 'icon' | 'color' | 'onClick'>;
  LinkProps: undefined;
  ButtonProps: undefined;
}

export interface RouteLinkButtonProps extends BaseRouteLinkProps {
  variant: 'button';
  ButtonProps?: Omit<ButtonProps, 'icon' | 'color' | 'onClick'>;
  LinkProps: undefined;
  IconButtonProps: undefined;
}

export type RouteLinkProps =
  | RouteLinkLinkProps
  | RouteLinkIconButtonProps
  | RouteLinkButtonProps;

export function RouteLink(props: RouteLinkProps) {
  const {
    className,
    style,
    classes: classesProp,
    variant = 'link',
    LinkProps,
    IconButtonProps,
    ButtonProps,
    to,
    navigationOptions,
    title,
    color,
    icon = 'link',
  } = props;

  const { classes, cx } = useStyles(undefined, {
    props: {
      classes: classesProp,
    },
  });

  const path = useResolvedPath(to);
  const navigate = useNavigate();

  const navigateTo = useCallback(
    (e: MouseEvent) => {
      e.stopPropagation();
      e.preventDefault();

      navigate(path, navigationOptions);
    },
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [path, navigationOptions]
  );

  const Component = useMemo(() => {
    switch (variant) {
      case 'button':
        return (
          <Button
            className={cx(classes.root, className)}
            style={style}
            icon={icon}
            color={color}
            {...ButtonProps}
            onClick={navigateTo}
          >
            {title}
          </Button>
        );
      case 'iconButton':
        return (
          <IconButton
            className={cx(classes.root, className)}
            style={style}
            icon={icon}
            color={color}
            {...IconButtonProps}
            title={title}
            onClick={navigateTo}
          />
        );

      default:
        return (
          <Link
            className={cx(classes.root, className)}
            style={style}
            icon={icon}
            color={color}
            {...LinkProps}
            href={path.pathname}
            onClick={navigateTo}
            target="_self"
          >
            {title}
          </Link>
        );
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [props]);

  return Component;
}

export default RouteLink;
