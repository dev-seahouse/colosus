import { Meta, Story } from '@storybook/react';
import { Route, Routes } from 'react-router-dom';
import { App } from '../../application';
import { Container } from '../../containers';
import { RouteLink as Component, RouteLinkProps } from './RouteLink';

const meta: Meta = {
  component: Component,
  argTypes: {},
  parameters: {
    controls: { expanded: true },
  },
};

export default meta;

const Template: Story<RouteLinkProps> = (args) => (
  <App
    store={{}}
    layouts={[
      {
        default: true,
        name: 'default',
        component: Container,
        layoutProps: {},
      },
    ]}
    routes={[]}
    themes={[
      {
        name: 'default',
        palette: {
          primary: 'aliceblue',
          secondary: 'grey',
        },
      },
    ]}
    logo=""
    name={`${Component.name} App`}
  >
    <Routes>
      <Route
        path="yes"
        element={<Component {...args} title="YES" to="../no" icon="check" />}
      />
      <Route
        path="no"
        element={<Component {...args} title="NO" to="../maybe" icon="close" />}
      />
      <Route
        path="*"
        element={
          <Component {...args} title="MAYBE" to="../yes" icon="question_mark" />
        }
      />
    </Routes>
  </App>
);

export const RouteLink = Template.bind({});
RouteLink.args = {
  title: 'A link title',
  to: 'yes',
};
