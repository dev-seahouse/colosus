import { Typography } from '@mui/material';
import { Meta, Story } from '@storybook/react';
import { IconButton } from '../../buttons';
import { Container } from '../../containers';
import {
  SectionHeader as Component,
  SectionHeaderProps,
} from './SectionHeader';

const meta: Meta = {
  component: Component,
  argTypes: {},
  parameters: {
    controls: { expanded: true },
  },
};

export default meta;

const Template: Story<SectionHeaderProps> = (args) => {
  return (
    <Container>
      <Component {...args} />
    </Container>
  );
};

export const SectionHeader = Template.bind({});
SectionHeader.args = {
  title: 'Section Title',
  subtitle: 'Section Sub Title',
  children: <Typography>Child controls</Typography>,
  titleAction: (
    <div
      style={{
        display: 'flex',
        flexDirection: 'row',
      }}
    >
      <IconButton
        style={{
          marginLeft: '-4px',
        }}
        size="small"
        icon="dashboard"
      />
      <Typography>something</Typography>
    </div>
  ),
  actions: [
    () => {
      return <Typography>Custom Action</Typography>;
    },
    {
      title: 'Settings',
      icon: 'settings',
      onClick() {
        console.log('clicked');
      },
    },
    {
      title: 'Export',
      icon: 'download',
      color: 'primary',
      onClick() {
        console.log('clicked');
      },
    },
  ],
};

export const SectionHeaderCondensed = Template.bind({});
SectionHeaderCondensed.args = {
  title: 'Section Title',
  subtitle: 'Section Sub Title',
  variant: 'condensed',
  children: <Typography>Child controls</Typography>,
  titleAction: (
    <div
      style={{
        display: 'flex',
        flexDirection: 'row',
      }}
    >
      <IconButton
        style={{
          marginLeft: '-4px',
        }}
        size="small"
        icon="dashboard"
      />
      <Typography>something</Typography>
    </div>
  ),
  actions: [
    () => {
      return <Typography>Custom Action</Typography>;
    },
    {
      title: 'Settings',
      icon: 'settings',
      onClick() {
        console.log('clicked');
      },
    },
    {
      title: 'Export',
      icon: 'download',
      color: 'primary',
      onClick() {
        console.log('clicked');
      },
    },
  ],
};

export const SectionHeaderBare = Template.bind({});
SectionHeaderBare.args = {
  title: 'Section Title',
};

export const SectionHeaderNoChildren = Template.bind({});
SectionHeaderNoChildren.args = {
  title: 'Section Title',
  subtitle: 'Section Sub Title',
  children: <Typography>Child controls</Typography>,
  actions: [
    () => {
      return <Typography>Custom Action</Typography>;
    },
    {
      title: 'Settings',
      icon: 'settings',
      onClick() {
        console.log('clicked');
      },
    },
    {
      title: 'Export',
      icon: 'download',
      color: 'primary',
      onClick() {
        console.log('clicked');
      },
    },
  ],
};

export const SectionHeaderNoActions = Template.bind({});
SectionHeaderNoActions.args = {
  title: 'Section Title',
  subtitle: 'Section Sub Title',
  children: <Typography>Child controls</Typography>,
};
