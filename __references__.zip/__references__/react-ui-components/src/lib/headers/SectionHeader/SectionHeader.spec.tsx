import { render } from '@testing-library/react';

import Component from './SectionHeader';

describe(Component.name, () => {
  it('should render successfully', () => {
    const { baseElement } = render(<Component />);
    expect(baseElement).toBeTruthy();
  });
});
