import { mostReadable, tinycolor } from '@bambu/js-core';
import {
  Button,
  ButtonProps,
  ComponentSize,
  ComponentColor,
  ContainerComponent,
  IconButton,
  Icon,
} from '../../';
import { IconButtonProps, Typography } from '@mui/material';
import { Variant } from '@mui/material/styles/createTypography';
import { ReactNode } from 'react';
import { makeStyles } from 'tss-react/mui';

const useStyles = makeStyles()((theme) => {
  return {
    root: {
      display: 'flex',
      flexDirection: 'row',
      width: '100%',
      boxSizing: 'border-box',
      marginBottom: theme.spacing(2),
      paddingBottom: theme.spacing(2),
    },
    root_inherit: {},
    root_small: {},
    root_large: {},
    root_medium: {},
    root_condensed: {},
    root_prominent: {
      [theme.breakpoints.down('md')]: {
        flexDirection: 'column',
      },
    },
    titleWrapper: {
      flexGrow: 1,
      flexShrink: 1,
    },
    icon: {
      marginRight: theme.spacing(2),
    },
    title: {
      display: 'flex',
      flexDirection: 'row',
      alignItems: 'center',
    },
    titleText: {
      display: '-webkit-box',
      WebkitLineClamp: 2,
      lineClamp: 2,
      WebkitBoxOrient: 'vertical',
      overflow: 'hidden',
      textOverflow: 'ellipsis',
    },
    contentWrapper: {
      marginTop: theme.spacing(1),
    },
    actionWrapper: {
      flexGrow: 0,
      flexShrink: 0,
      display: 'flex',
      flexDirection: 'row',
      alignItems: 'center',
      paddingLeft: theme.spacing(2),

      [theme.breakpoints.down('md')]: {
        flexDirection: 'column',
        paddingLeft: 0,

        '& > *': {
          marginRight: 0,
          marginBottom: theme.spacing(1),
        },
        '& > *:last-child': {
          marginRight: 0,
          marginBottom: 0,
        },
      },
    },
    actionWrapper_condensed: {
      justifyContent: 'center',
    },
    actionWrapper_prominent: {
      '& > *': {
        marginRight: theme.spacing(2),
      },
      '& > *:last-child': {
        marginRight: 0,
      },
      [theme.breakpoints.down('md')]: {
        paddingTop: theme.spacing(2),

        '& > *': {
          marginRight: 0,
          marginBottom: theme.spacing(1),
        },
        '& > *:last-child': {
          marginRight: 0,
          marginBottom: 0,
        },
      },
    },
    actionButton: {
      flexShrink: 0,

      [theme.breakpoints.down('md')]: {
        width: '100%',
      },
    },
    actionButton_inherit: {},
    actionButton_default: {},
    actionButton_primary: {
      color: `${mostReadable(
        tinycolor(theme.palette.background.paper),
        [
          theme.palette.primary.light,
          theme.palette.primary.main,
          theme.palette.primary.dark,
        ],
        {}
      )?.toHex8String()}`,
    },
    actionButton_secondary: {
      color: `${mostReadable(
        tinycolor(theme.palette.background.paper),
        [
          theme.palette.secondary.light,
          theme.palette.secondary.main,
          theme.palette.secondary.dark,
        ],
        {}
      )?.toHex8String()}`,
    },
    actionButton_error: {
      color: `${mostReadable(
        tinycolor(theme.palette.background.paper),
        [
          theme.palette.error.light,
          theme.palette.error.main,
          theme.palette.error.dark,
        ],
        {}
      )?.toHex8String()}`,
    },
    actionButton_info: {
      color: `${mostReadable(
        tinycolor(theme.palette.background.paper),
        [
          theme.palette.info.light,
          theme.palette.info.main,
          theme.palette.info.dark,
        ],
        {}
      )?.toHex8String()}`,
    },
    actionButton_success: {
      color: `${mostReadable(
        tinycolor(theme.palette.background.paper),
        [
          theme.palette.success.light,
          theme.palette.success.main,
          theme.palette.success.dark,
        ],
        {}
      )?.toHex8String()}`,
    },
    actionButton_warning: {
      color: `${mostReadable(
        tinycolor(theme.palette.background.paper),
        [
          theme.palette.warning.light,
          theme.palette.warning.main,
          theme.palette.warning.dark,
        ],
        {}
      )?.toHex8String()}`,
    },
  };
});

function isButtonProps(action: any): action is ButtonProps {
  return Boolean((action as ButtonProps).title);
}

function isIconButtonProps(action: any): action is IconButtonProps {
  return Boolean((action as IconButtonProps).title);
}

// eslint-disable-next-line @typescript-eslint/no-empty-interface
export interface SectionHeaderProps
  extends ContainerComponent<
    'div',
    Partial<ReturnType<typeof useStyles>['classes']>
  > {
  title: string;
  size?: ComponentSize;
  subtitle?: string;
  actions?: (ButtonProps | IconButtonProps | (() => ReactNode))[];
  variant?: 'condensed' | 'prominent';
  icon?: string;
  iconColor?: ComponentColor;
  iconTitle?: string;
  onIconClick?: () => void;
  titleAction?: ReactNode;
}

export function SectionHeader({
  className,
  style,
  classes: classesProp,
  title,
  size = 'medium',
  variant = 'prominent',
  subtitle,
  actions,
  icon,
  iconColor = 'inherit',
  iconTitle,
  onIconClick,
  children,
  titleAction,
}: SectionHeaderProps) {
  const { classes, cx } = useStyles(undefined, {
    props: {
      classes: classesProp,
    },
  });

  const typographyVariants: {
    [key in ComponentSize]: Variant | 'inherit';
  } = {
    inherit: 'inherit',
    small: 'h5',
    medium: 'h4',
    large: 'h2',
  };

  return (
    <div
      className={cx(
        classes.root,
        className,
        classes[`root_${size}`],
        classes[`root_${variant}`]
      )}
      style={style}
    >
      <div className={cx(classes.titleWrapper)}>
        {titleAction}
        <div className={cx(classes.title)}>
          {icon && onIconClick && (
            <IconButton
              className={cx(classes.icon)}
              size={size}
              icon={icon}
              title={iconTitle}
              color={iconColor}
              onClick={() => {
                onIconClick();
              }}
            />
          )}
          {icon && !onIconClick && (
            <Icon
              className={cx(classes.icon)}
              size={size}
              title={iconTitle}
              color={iconColor}
            >
              {icon}
            </Icon>
          )}
          <Typography
            className={cx(classes.titleText)}
            variant={typographyVariants[size]}
            component="h2"
          >
            {title}
          </Typography>
        </div>
        {subtitle && <Typography variant="caption">{subtitle}</Typography>}
        {children && (
          <div className={cx(classes.contentWrapper)}>{children}</div>
        )}
      </div>
      {actions && (
        <div
          className={cx(
            classes.actionWrapper,
            classes[`actionWrapper_${variant}`]
          )}
        >
          {actions.map((action) => {
            if (isButtonProps(action) || isIconButtonProps(action)) {
              if (variant === 'prominent') {
                const componentProps = action as ButtonProps;
                return (
                  <Button
                    key={componentProps.title}
                    {...componentProps}
                    className={cx(
                      classes.actionButton,
                      componentProps.className
                    )}
                    color={componentProps.color || 'secondary'}
                    variant={componentProps.variant || 'pill'}
                  >
                    {action.title}
                  </Button>
                );
              } else {
                const componentProps = action as IconButtonProps;
                return (
                  <IconButton
                    key={componentProps.title}
                    {...action}
                    variant="text"
                    color="inherit"
                    className={cx(
                      classes.actionButton,
                      classes[
                        `actionButton_${componentProps.color || 'secondary'}`
                      ],
                      componentProps.className
                    )}
                    title={componentProps.title}
                  />
                );
              }
            } else {
              return action();
            }
          })}
        </div>
      )}
    </div>
  );
}

export default SectionHeader;
