import { render } from '@testing-library/react';

import TitleBar from './TitleBar';

describe(TitleBar.name, () => {
  it('should render successfully', () => {
    const { baseElement } = render(<TitleBar />);
    expect(baseElement).toBeTruthy();
  });
});
