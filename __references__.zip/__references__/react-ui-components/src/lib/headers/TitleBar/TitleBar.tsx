import { AppBar, AppBarProps, Toolbar, ToolbarProps } from '@mui/material';
import { forwardRef, ReactElement } from 'react';
import { makeStyles } from 'tss-react/mui';

const useStyles = makeStyles()((theme) => {
  return {
    root: {
      zIndex: 10,
      color: theme.palette.secondary.contrastText,
      background: theme.palette.secondary.main,
    },
    toolbar: {
      minWidth: '100%',
    },
    titleContent: {
      flexGrow: 1,
      flexShrink: 1,
      overflow: 'hidden',
    },
    actionContent: {
      flexShrink: 0,
      flexGrow: 0,
    },
  };
});

export interface TitleBarProps extends Omit<AppBarProps, 'children'> {
  titleContent?: ReactElement;
  actionContent?: ReactElement;
  ToolbarProps?: ToolbarProps;
}

export const TitleBar = forwardRef<HTMLDivElement, TitleBarProps>(
  (
    {
      className,
      style,
      classes: classesProp,
      titleContent,
      actionContent,
      ToolbarProps,
      ...rest
    }: TitleBarProps,
    ref
  ) => {
    const { classes, cx } = useStyles(undefined, {
      props: {
        classes: classesProp,
      },
    });

    return (
      <AppBar
        ref={ref}
        className={cx(classes.root, className)}
        style={style}
        position="relative"
        {...rest}
      >
        <Toolbar {...ToolbarProps} className={cx(classes.toolbar)}>
          <div className={cx(classes.titleContent)}>{titleContent}</div>
          <div className={cx(classes.actionContent)}>{actionContent}</div>
        </Toolbar>
      </AppBar>
    );
  }
);

export default TitleBar;
