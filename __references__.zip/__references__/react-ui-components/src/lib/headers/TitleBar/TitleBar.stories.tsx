import { Meta, Story } from '@storybook/react';
import { TitleBar as Component, TitleBarProps } from './TitleBar';

const meta: Meta = {
  component: Component,
  argTypes: {
    children: {
      control: {
        type: 'text',
      },
    },
  },
  parameters: {
    controls: { expanded: true },
  },
};

export default meta;

const Template: Story<TitleBarProps> = (args) => <Component {...args} />;

export const TitleBar = Template.bind({});
TitleBar.args = {};
