/* eslint-disable @typescript-eslint/no-var-requires,@typescript-eslint/no-unused-vars,@typescript-eslint/no-explicit-any */
// import type { Configuration } from 'webpack';

const getWebpackConfig = require('@nrwl/react/plugins/webpack');
const webpack = require('webpack');
const CKEditorWebpackPlugin = require('@ckeditor/ckeditor5-dev-webpack-plugin');
const { bundler, styles } = require('@ckeditor/ckeditor5-dev-utils');
const TerserWebpackPlugin = require('terser-webpack-plugin');

function config(initialConfig, options = null) {
  const config = initialConfig; //getWebpackConfig(initialConfig);

  const patchPostCssConfig = (config) => {
    const { plugins, ...rest } = config;
    return { postcssOptions: { plugins }, ...rest };
  };

  if (config.plugins) {
    // Remove the css loader
    const idx = config.plugins.findIndex(
      (plugin) => plugin.constructor.name === 'MiniCssExtractPlugin'
    );
    config.plugins.splice(idx, 1);

    config.plugins.push(
      new CKEditorWebpackPlugin({
        // See https://ckeditor.com/docs/ckeditor5/latest/features/ui-language.html
        language: 'en',
        additionalLanguages: 'all',
        buildAllTranslationsToSeparateFiles: true,
        addMainLanguageTranslationsToAllAssets: true,
      }),
      new webpack.BannerPlugin({
        banner: bundler.getLicenseBanner(),
        raw: true,
      })
    );
  }

  config.output = {
    path: config.output?.path,
    library: 'CKEditor5',
    filename: 'ckeditor.js',
    libraryTarget: 'umd',
    libraryExport: 'default',
  };

  config.optimization = {
    runtimeChunk: false,
    minimizer: [
      new TerserWebpackPlugin({
        // sourceMap: true,
        terserOptions: {
          output: {
            // Preserve CKEditor 5 license comments.
            comments: /^!/,
          },
        },
        extractComments: false,
      }),
    ],
  };

  // Ensure the default rules do not interfere
  const rules = (config.module?.rules || [])
    .map((rule) => {
      // Prevent the NX svg processing from interfering
      if (String(rule.test) === String(/\.svg$/)) {
        return null;
      }
      // Prevent the NX css processing from interfering
      if (
        String(rule.test) === String(/\.css$|\.scss$|\.sass$|\.less$|\.styl$/)
      ) {
        return null;
      }
      return rule;
    })
    .filter((i) => i);

  if (config.module?.rules) {
    config.module.rules = [
      {
        // test: /ckeditor5-[^/\\]+[/\\]theme[/\\]icons[/\\][^/\\]+\.svg$/,
        test: /\.svg$/,
        use: ['raw-loader'],
      },
      {
        test: /\.css$/,
        // test: /ckeditor5-[^/\\]+[/\\].+\.css$/,
        use: [
          {
            loader: 'style-loader',
            options: {
              injectType: 'singletonStyleTag',
              attributes: {
                'data-cke': true,
              },
            },
          },
          'css-loader',
          {
            loader: 'postcss-loader',
            options: {
              postcssOptions: styles.getPostCssConfig({
                themeImporter: {
                  themePath: require.resolve('@ckeditor/ckeditor5-theme-lark'),
                },
                minify: true,
              }),
            },
          },
        ],
      },
      ...(rules || []),
    ];
  }

  return config;
}

module.exports = config;
