# references-ckeditor5

This library was generated with [Nx](https://nx.dev).

## Building

Run `nx build references-ckeditor5` to build the library.

## Running unit tests

Run `nx test references-ckeditor5` to execute the unit tests via [Jest](https://jestjs.io).
