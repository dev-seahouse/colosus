/* eslint-disable @typescript-eslint/no-var-requires */

const { composePlugins, withNx } = require('@nrwl/webpack');

// Nx plugins for webpack.
module.exports = composePlugins(withNx(), (config) => {
  // Note: This was added by an Nx migration.
  // You should consider inlining the logic into this file.
  // For more information on webpack config and Nx see:
  // https://nx.dev/packages/webpack/documents/webpack-config-setup

  // eslint-disable-next-line @typescript-eslint/no-var-requires
  return require('./ckeditor-webpack.config.old.js')(config, null);
});
