import * as fs from 'fs';

const SVG_REGEX = /ckeditor5-[^/\\]+[/\\].+\.svg$/;

export type CKEditorPluginOptions = {
  svgRegex?: RegExp;
};

// https://github.com/ckeditor/ckeditor5/issues/9807#issuecomment-975792815
export default function (options?: CKEditorPluginOptions) {
  const { svgRegex = SVG_REGEX } = options || {};
  return {
    name: 'vite-ckeditor5-plugin',
    enforce: 'pre',
    async transform(src: string, id: string) {
      if (svgRegex.test(id)) {
        // SVG Files are loaded as raw text
        src = fs.readFileSync(id, 'utf8');
        const json = JSON.stringify(src)
          .replace(/\u2028/g, '\\u2028')
          .replace(/\u2029/g, '\\u2029');
        return {
          code: `export default ${json}`,
          map: { mappings: '' },
        };
      }
    },
  } as unknown;
}
