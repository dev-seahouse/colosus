import { EditorConfig } from '@ckeditor/ckeditor5-core/src/editor/editorconfig';
import BalloonEditorBase from '@ckeditor/ckeditor5-editor-balloon/src/ballooneditor';

import { defaultConfig, defaultPlugins } from '../standardPlugins';

class BalloonEditor extends BalloonEditorBase {}

// Plugins to include in the build.
BalloonEditor.builtinPlugins = defaultPlugins;

// Editor configuration.
BalloonEditor.defaultConfig = defaultConfig as EditorConfig;

export default BalloonEditor;
