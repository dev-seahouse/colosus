import { EditorConfig } from '@ckeditor/ckeditor5-core/src/editor/editorconfig';
import BalloonEditorBase from '@ckeditor/ckeditor5-editor-balloon/src/ballooneditor';

import BlockToolbar from '@ckeditor/ckeditor5-ui/src/toolbar/block/blocktoolbar';

import { defaultConfig, defaultPlugins } from '../standardPlugins';

class BalloonBlockEditor extends BalloonEditorBase {}

// Plugins to include in the build.
BalloonBlockEditor.builtinPlugins = [...defaultPlugins, BlockToolbar];

// Editor configuration.
BalloonBlockEditor.defaultConfig = {
  ...defaultConfig,
  blockToolbar: [
    'heading',
    '|',
    'fontfamily',
    'fontsize',
    'fontColor',
    'fontBackgroundColor',
    '|',
    'underline',
    'strikethrough',
    '|',
    'alignment',
    '|',
    'numberedList',
    'bulletedList',
    '|',
    'outdent',
    'indent',
    '|',
    'blockquote',
    'uploadImage',
    'insertTable',
    'mediaEmbed',
    '|',
    'undo',
    'redo',
  ],
  toolbar: {
    items: ['bold', 'italic', 'link'],
  },
  // This value must be kept in sync with the language defined in webpack.config.js.
  language: 'en',
} as EditorConfig;

export default BalloonBlockEditor;
