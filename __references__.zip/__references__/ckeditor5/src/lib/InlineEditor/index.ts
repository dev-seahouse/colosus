import { EditorConfig } from '@ckeditor/ckeditor5-core/src/editor/editorconfig';
import InlineEditorBase from '@ckeditor/ckeditor5-editor-inline/src/inlineeditor';

import { defaultConfig, defaultPlugins } from '../standardPlugins';

class InlineEditor extends InlineEditorBase {}

// Plugins to include in the build.
InlineEditor.builtinPlugins = defaultPlugins;

// Editor configuration.
InlineEditor.defaultConfig = defaultConfig as EditorConfig;

export default InlineEditor;
