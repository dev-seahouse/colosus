import { EditorConfig } from '@ckeditor/ckeditor5-core/src/editor/editorconfig';
import ClassicEditorBase from '@ckeditor/ckeditor5-editor-classic/src/classiceditor';

import { defaultConfig, defaultPlugins } from '../standardPlugins';

export default class ClassicEditor extends ClassicEditorBase {}

// Plugins to include in the build.
ClassicEditor.builtinPlugins = defaultPlugins;

// Editor configuration.
ClassicEditor.defaultConfig = defaultConfig as EditorConfig;
