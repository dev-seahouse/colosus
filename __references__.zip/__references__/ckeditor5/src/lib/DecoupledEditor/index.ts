import { EditorConfig } from '@ckeditor/ckeditor5-core/src/editor/editorconfig';
import DecoupledEditorBase from '@ckeditor/ckeditor5-editor-decoupled/src/decouplededitor';

import { defaultConfig, defaultPlugins } from '../standardPlugins';

class DecoupledEditor extends DecoupledEditorBase {}

// Plugins to include in the build.
DecoupledEditor.builtinPlugins = defaultPlugins;

// Editor configuration.
DecoupledEditor.defaultConfig = defaultConfig as EditorConfig;

export default DecoupledEditor;
