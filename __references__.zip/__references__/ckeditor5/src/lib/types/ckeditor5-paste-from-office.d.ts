declare module '@ckeditor/ckeditor5-paste-from-office/src/pastefromoffice';
