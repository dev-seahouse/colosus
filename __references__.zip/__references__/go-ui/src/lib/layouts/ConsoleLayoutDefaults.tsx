import { ConsoleLayoutDefaults } from '@bambu/references-react-ui-layout';
import { AppToolbarActions } from '../components';

export const BambuConsoleLayoutDefaults: typeof ConsoleLayoutDefaults = {
  ...ConsoleLayoutDefaults,
  theme: {
    ...ConsoleLayoutDefaults.theme,
    main: 'defaultLight',
    navbar: 'defaultLight',
    toolbar: 'defaultLight',
    footer: 'defaultLight',
    panel: 'defaultLight',
    dialog: 'defaultLight',
  },
  navbar: {
    ...ConsoleLayoutDefaults.navbar,
    shadow: 2,
    userInfo: {
      ...ConsoleLayoutDefaults.navbar.userInfo,
      allowProfileClick: true,
    },
  },
  toolbar: {
    ...ConsoleLayoutDefaults.toolbar,
    display: true,
    contentPosition: 'outside',
    elevation: 0,
    actions: AppToolbarActions,
  },
  footer: {
    ...ConsoleLayoutDefaults.footer,
    display: false,
  },
};
