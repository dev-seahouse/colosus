export * from './applicationConfig';
