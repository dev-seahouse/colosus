import { PaletteDeclaration } from '@bambu/js-core';

export const colors: PaletteDeclaration = {
  tint: 10,
  primary: '#7A48FF',
  secondary: '#4474FF',
};
