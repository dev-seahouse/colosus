import { _ } from '@bambu/js-core';
import { colors } from './colors';

// Attempt to import the local config file
const localConfig = {
  application: {},
};
// if (process) {
//   try {
//     localConfig = require('./local.config');
//   } catch (e) {
//     // Do nothing here as the defaults will be used
//   }
// }

export const appSettings = _.merge(
  {
    environment: 'dev',
    name: 'Bambu Admin',
    description: `Bambu Admin Interface`,
    keywords: 'Bambu Admin Interface',
    featureImage: '/assets/images/backgrounds/bambu_background.jpg',
    frontEndDocs: 'https://somewhere.when/deployed/index.html',
    apiDocs: 'https://somewhere.when/deployed/openapi',
    sourceDocs: '',
    website: 'https://bambu-admin.co',
    favIcon: '/assets/logos/favicon-96x96.png',
    logo: '/assets/logos/bambu-logo.svg',
    company_name: 'Mangosteen Pte. Ltd.',
    company_logo: 'assets/logos/bambu-logo.png',
    company_url: 'https://bambu.co',
    ga_tag_id: 'gtag',
    themeMode: 'light',
    colors: colors,

    bambu_admin: {
      apiRoot: process.env['NX_API_ROOT'] || 'https://api.bambu.co',
      webRoot: process.env['NX_WEB_ROOT'] || 'https://app.bambu.co',
    },
    oauth: {
      apiRoot:
        process.env['NX_AUTH_PROVIDER_API_ROOT'] ||
        'https://api.auth.provider.com',
      clientID: process.env['NX_AUTH_PROVIDER_CLIENT_ID'],
      clientKey: process.env['NX_AUTH_PROVIDER_CLIENT_KEY'],
      clientSecret: process.env['NX_AUTH_PROVIDER_CLIENT_SECRET'],
    },
  },
  localConfig.application
);
