# references-go-ui

This library was generated with [Nx](https://nx.dev).

## Running unit tests

Run `nx test references-go-ui` to execute the unit tests via [jest](https://jestjs.io/).
