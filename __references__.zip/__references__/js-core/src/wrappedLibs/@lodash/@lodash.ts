import * as __ from 'lodash';

const _ = __.runInContext();

_.mixin({
  // Immutable set for setting state
  setIn: (state: never, name: string, value: never) => {
    return _.setWith(_.clone(state), name, value, _.clone);
  },
});

export default _;
