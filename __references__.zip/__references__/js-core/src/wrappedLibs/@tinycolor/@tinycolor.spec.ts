'use strict';

import { tinycolor } from './@tinycolor';

describe('tinycolor', () => {
  it('should be defined', () => {
    expect(tinycolor).toBeDefined();
  });
});
