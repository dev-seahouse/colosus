export { default as tinycolor } from '@ctrl/tinycolor';
export * from '@ctrl/tinycolor';
