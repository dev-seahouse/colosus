import * as history from 'history';
export const createHistory = history.createBrowserHistory;
