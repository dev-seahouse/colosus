'use strict';

import { createHistory } from './@history';

describe('history', () => {
  it('should be defined', () => {
    expect(createHistory).toBeDefined();
  });
});
