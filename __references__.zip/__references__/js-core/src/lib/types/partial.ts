export const Partial = <T>(
  Class: new () => T
): new () => {
  [P in keyof T]?: T[P];
} => Class;
