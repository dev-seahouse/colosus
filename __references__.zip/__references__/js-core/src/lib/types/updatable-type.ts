export type UpdateableT = {
  objectVersion: number;
};
