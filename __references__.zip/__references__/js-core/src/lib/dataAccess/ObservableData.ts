import { BehaviorSubject } from 'rxjs';
import { I18NArguments } from '../i18n';
import { DTOPagedData, DtoType } from './types';
import { DtoObserverState } from './types/dto-observable-state.type';
import _ from '../../wrappedLibs/@lodash';

export type ObservableDataTransforms<DataType> = {
  pagedResult?: (data: unknown) => DTOPagedData<DataType>;
  dtoTransforms?: ((data: unknown) => DataType)[];
};

type ObservableDataProps<ObserverType, DataType> = {
  global: boolean;
  name: string;
  initialState?: Partial<ObserverType>;
  transforms?: Partial<ObservableDataTransforms<DataType>>;
};

const globalObservables: {
  [key: string]: BehaviorSubject<any>;
} = {};

export class ObservableData<
  DataType extends DtoType,
  ObserverType extends DtoObserverState<DataType> = DtoObserverState<DataType>
> {
  protected subject: BehaviorSubject<ObserverType>;
  private name: string;
  private transforms: ObservableDataTransforms<DataType>;

  constructor(args: ObservableDataProps<ObserverType, DataType>) {
    this.name = args.name;

    this.transforms = _.merge(
      {
        pagedResult(data) {
          const rawData = Array.isArray(data) ? data : [data];
          const dtoTransform = args.transforms?.dtoTransforms;
          return {
            // If there are dtoTransforms, then ensure that each record is transformed
            data: dtoTransform
              ? rawData.map((record) => {
                  return dtoTransform.reduce((acc, transform) => {
                    return transform(acc);
                  }, record);
                })
              : rawData,
            totalCount: rawData.length,
            index: 0,
            pageSize: rawData.length,
            pageInfo: {
              hasNextPage: false,
              hasPreviousPage: false,
            },
          };
        },
      } as ObservableDataTransforms<DataType>,
      args.transforms || {}
    );

    const intialState = _.merge(
      {},
      {
        page: {
          data: [],
          totalCount: 0,
          index: 0,
          pageSize: 0,
          pageInfo: {
            hasNextPage: false,
            hasPreviousPage: false,
          },
        },
        lastRetrieved: null,
        listing: false,
        creating: false,
        updating: false,
        removing: false,
        getting: false,
        errors: [],
      } as DtoObserverState<DataType>,
      args.initialState || {}
    ) as ObserverType;

    if (args.global) {
      this.subject = globalObservables[this.name];
      if (!this.subject) {
        globalObservables[this.name] = new BehaviorSubject<ObserverType>(
          intialState
        );
        this.subject = globalObservables[this.name];
      }
    } else {
      this.subject = new BehaviorSubject<ObserverType>(intialState);
    }
  }

  setNextState(payload: Partial<DtoObserverState<DataType> | ObserverType>) {
    const state = this.subject.getValue();
    this.subject.next({
      ...state,
      ...payload,
    });
  }

  list(data: DataType[]) {
    this.setNextState({
      page: this.transforms.pagedResult
        ? this.transforms.pagedResult(data)
        : // The DataType has provided no paged transform, therefore expect the data in the right format
          (data as unknown as DTOPagedData<DataType>),
      errors: [],
    });
  }

  listing(flag: boolean) {
    this.setNextState({ listing: flag });
  }

  get(data: DataType) {
    // If we have received an item that is already in memory, then replace
    // to make sure we are up to date
    const page = this.subject.getValue().page;
    const dataItems = [...page.data].map((item) => {
      if (item.id === data.id) {
        return { ...data };
      }
      return item;
    });
    this.setNextState({
      page: {
        ...page,
        data: [...dataItems],
      },
      errors: [],
      lastRetrieved: data,
    });
  }

  getting(flag: boolean) {
    this.setNextState({ getting: flag });
  }

  create(data: DataType) {
    const page = this.subject.getValue().page;
    this.setNextState({
      page: {
        ...page,
        totalCount: page.totalCount + 1,
        data: [...page.data, data],
      },
      errors: [],
      lastRetrieved: data,
    });
  }

  creating(flag: boolean) {
    this.setNextState({ creating: flag });
  }

  update(id: string, data: DataType) {
    const page = this.subject.getValue().page;
    const dataItems = [...page.data].map((item) => {
      if (item.id === data.id) {
        return { ...data };
      }
      return item;
    });

    this.setNextState({
      page: {
        ...page,
        data: dataItems,
      },
      errors: [],
      lastRetrieved: data,
    });
  }

  updating(flag: boolean) {
    this.setNextState({ updating: flag });
  }

  remove(id: string) {
    const page = this.subject.getValue().page;
    const dataItems = [...page.data].filter((item) => {
      return item.id !== id;
    });

    this.setNextState({
      page: {
        ...page,
        data: dataItems,
      },
      errors: [],
    });
  }

  removing(flag: boolean) {
    this.setNextState({ removing: flag });
  }

  error(errors: I18NArguments[]) {
    this.setNextState({
      errors,
    });
  }

  getObservable() {
    return this.subject;
  }

  getState() {
    return this.subject.getValue();
  }

  getFromStateByID(id: string) {
    return this.subject.getValue().page.data.find((item) => item.id === id);
  }

  getFromStateByIDs(ids: string[]) {
    return this.subject
      .getValue()
      .page.data.find((item) => ids.includes(item.id));
  }
}
