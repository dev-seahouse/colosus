import { AxiosInstance } from 'axios';
import {
  catchError,
  finalize,
  map,
  Observable,
  of,
  switchMap,
  tap,
} from 'rxjs';
import DataApi, { PaginationProps } from './DataApi';
import { handleAxiosError } from './handleAxiosError';
import { ObservableData, ObservableDataTransforms } from './ObservableData';
import { DtoType } from './types';

export type DataRepositoryProps<
  DataType extends DtoType,
  ObservableType extends ObservableData<DataType> = ObservableData<DataType>
> = {
  baseURL?: string;
  axios?: AxiosInstance;
  dtoPath: string;
  global?: boolean;
  observableService?: ObservableType;
  apiService?: DataApi<DataType>;
  transforms?: ObservableDataTransforms<DataType>;
};

export class DataRepository<
  DataType extends DtoType,
  ObservableType extends ObservableData<
    DataType,
    any
  > = ObservableData<DataType>
> {
  protected readonly dataApi: DataApi<DataType>;
  protected readonly observableService: ObservableType;

  constructor(args: DataRepositoryProps<DataType, ObservableType>) {
    if (args.apiService) {
      this.dataApi = args.apiService;
    } else {
      this.dataApi = new DataApi(args);
    }
    const name = this.dataApi.getBasePath();
    if (args.observableService) {
      this.observableService = args.observableService;
    } else {
      this.observableService = new ObservableData<DataType>({
        // Global by default
        global: args.global === false ? false : true,
        name: name,
        transforms: args.transforms,
      }) as ObservableType;
    }
  }

  getBaseURL() {
    return this.dataApi.getBasePath();
  }

  getState() {
    return this.observableService.getState();
  }

  setToken(token: string) {
    this.dataApi.setToken('Bearer', token);
  }

  findAll(pagination?: PaginationProps): Observable<DataType[]> {
    return of({
      pagination,
    }).pipe(
      tap(() => this.observableService.listing(true)),
      // TODO: Retrieve from cache before attempting URI
      switchMap(({ pagination }) => {
        return this.dataApi
          .findAll(pagination)
          .pipe(map((response) => response.data));
        // TODO: Cache response here
      }),
      tap((result) => this.observableService.list(result)),
      catchError((err) => {
        this.observableService.error(handleAxiosError(err));
        throw err;
      }),
      finalize(() => {
        this.observableService.listing(false);
      })
    );
  }

  findOne(id: string): Observable<DataType> {
    return of(id).pipe(
      tap(() => this.observableService.getting(true)),
      // Check local state first, if not available go to api
      map((id) => this.observableService.getFromStateByID(id)),
      switchMap((cachedData) => {
        return cachedData
          ? of(cachedData)
          : this.dataApi.findOne(id).pipe(
              map((response) => response?.data)
              // TODO: Cache response here
            );
      }),
      tap((result) => {
        this.observableService.get(result);
      }),
      catchError((err) => {
        this.observableService.error(handleAxiosError(err));
        throw err;
      }),
      finalize(() => {
        this.observableService.getting(false);
      })
    );
  }

  findByIDs(ids: string[]): Observable<DataType[]> {
    return of(ids).pipe(
      tap(() => this.observableService.listing(true)),
      // TODO: Retrieve from cache before attempting URI
      switchMap((ids) => {
        return this.dataApi
          .findByIDs(ids)
          .pipe(map((response) => response.data));
        // TODO: Cache response here
      }),
      tap((result) => {
        this.observableService.list(result);
      }),
      catchError((err) => {
        this.observableService.error(handleAxiosError(err));
        throw err;
      }),
      finalize(() => {
        this.observableService.listing(false);
      })
    );
  }

  create(data: DataType) {
    return of(data).pipe(
      tap(() => this.observableService.creating(true)),
      switchMap((data) => {
        return this.dataApi.create(data).pipe(map((response) => response.data));
      }),
      tap((result) => {
        this.observableService.create(result);
      }),
      catchError((err) => {
        this.observableService.error(handleAxiosError(err));
        throw err;
      }),
      finalize(() => {
        this.observableService.creating(false);
      })
    );
  }

  update(id: string, data: DataType) {
    return of({
      id,
      data,
    }).pipe(
      tap(() => this.observableService.updating(true)),
      switchMap(({ id, data }) => {
        return this.dataApi
          .update(id, data)
          .pipe(map((response) => response.data));
      }),
      tap((result) => {
        // here id refers to the id passed in to the function not
        // the id in the observable
        this.observableService.update(id, result);
      }),
      catchError((err) => {
        this.observableService.error(handleAxiosError(err));
        throw err;
      }),
      finalize(() => {
        this.observableService.updating(false);
      })
    );
  }

  updatePartial(id: string, data: Partial<DataType>) {
    return of({
      id,
      data,
    }).pipe(
      tap(() => this.observableService.updating(true)),
      switchMap(({ id, data }) => {
        return this.dataApi
          .updatePartial(id, data)
          .pipe(map((response) => response.data));
      }),
      tap((result) => {
        // here id refers to the id passed in to the function not
        // the id in the observable
        this.observableService.update(id, result);
      }),
      catchError((err) => {
        this.observableService.error(handleAxiosError(err));
        throw err;
      }),
      finalize(() => {
        this.observableService.updating(false);
      })
    );
  }

  remove(id: string) {
    return of(id).pipe(
      tap(() => this.observableService.removing(true)),
      switchMap((id) => {
        return this.dataApi.remove(id).pipe(map((response) => response.data));
      }),
      tap(() => {
        // here id refers to the id passed in to the function not
        // the id in the observable
        this.observableService.remove(id);
      }),
      catchError((err) => {
        this.observableService.error(handleAxiosError(err));
        throw err;
      }),
      finalize(() => {
        this.observableService.removing(false);
      })
    );
  }

  getObservable() {
    return this.observableService.getObservable();
  }
}
