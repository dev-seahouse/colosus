import axios from 'axios';
import { I18NArguments } from '../i18n';

export function handleAxiosError(error: unknown) {
  let errorMessage = '';
  if (axios.isAxiosError(error)) {
    if (error.response?.data) {
      const data: any = error.response?.data;
      if (data.errors && data.errors.length > 0) {
        return [data.errors];
      } else if (data.error_description) {
        return [[data.error_description]];
      } else if (data.message) {
        return [[data.message]];
      } else if (Array.isArray(data) && data.length > 0) {
        return data.map((e) => [e.message]);
      }
    } else if (error.response && error.response.statusText) {
      errorMessage = error.response.statusText;
    }
  }
  if (!errorMessage) {
    errorMessage = (error as Error).message || 'An unknown error has occurred';
  }
  return [[errorMessage]] as I18NArguments[];
}
