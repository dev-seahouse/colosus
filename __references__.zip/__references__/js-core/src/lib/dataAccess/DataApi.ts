import axios, { AxiosInstance, AxiosResponse } from 'axios';
import { defer, from, Observable } from 'rxjs';
import { DtoType } from './types';

export type DataApiProps = {
  baseURL?: string;
  axios?: AxiosInstance;
  dtoPath: string;
};

export type PaginationProps = {
  offset: number;
  limit: number;
};

export type CancelAxios = () => void;

export default class DataApi<DataType extends DtoType> {
  protected axios: AxiosInstance;
  private baseURL: string;
  private dtoPath: string;

  constructor(args: DataApiProps) {
    if (!args.axios) {
      this.axios = axios.create({
        headers: {
          'Content-Type': 'application/json',
        },
        // withCredentials: true,
      });
    } else {
      this.axios = args.axios;
    }
    this.baseURL = this.axios.defaults.baseURL || args.baseURL || '';
    if (!this.baseURL) {
      throw new Error('A base url was not correctly configured');
    }
    this.dtoPath = args.dtoPath;
  }

  setToken(tokenType: string, token: string) {
    this.axios.defaults.headers.common[
      'Authorization'
    ] = `${tokenType} ${token}`;
  }

  getBasePath() {
    return `${this.baseURL}/${this.dtoPath}`;
  }

  // TODO: if a request is already in progress, just wait for it.
  // TODO: Need to be able to cancel axios
  findOne(id: string): Observable<AxiosResponse<DataType>> {
    return new Observable((observer) => {
      this.axios
        .get(`${this.getBasePath()}/${id}`)
        .then((res) => {
          observer.next(res);
          observer.complete();
        })
        .catch((err) => {
          observer.error(err);
        });
    });
  }

  // TODO: Need to be able to cancel axios
  findAll(pagination?: PaginationProps): Observable<AxiosResponse<DataType[]>> {
    const path = this.getBasePath();
    // TODO: DataApi must be able to form url to cater for filters, ordering, and pagination
    // This transform should be configurable
    const url = pagination
      ? `${path}?offset=${pagination.offset}&limit=${pagination.limit}`
      : path;

    return defer(() => from(this.axios.get(url)));
  }

  findByIDs(ids: string[]): Observable<AxiosResponse<DataType[]>> {
    const url = `${this.getBasePath()}/${ids.join(',')}`;
    return defer(() => from(this.axios.get(url)));
  }

  create(data: DataType): Observable<AxiosResponse<DataType>> {
    const url = `${this.getBasePath()}`;
    return defer(() => from(this.axios.post(url, data)));
  }

  update(id: string, data: DataType): Observable<AxiosResponse<DataType>> {
    const url = `${this.getBasePath()}/${id}`;
    return defer(() => from(this.axios.put(url, data)));
  }

  updatePartial(
    id: string,
    data: Partial<DataType>
  ): Observable<AxiosResponse<DataType>> {
    const url = `${this.getBasePath()}/${id}`;
    return defer(() => from(this.axios.patch(url, data)));
  }

  remove(id: string): Observable<AxiosResponse<DataType>> {
    const url = `${this.getBasePath()}/${id}`;
    return defer(() => from(this.axios.delete(url)));
  }
}
