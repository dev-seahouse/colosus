import { AxiosResponse } from 'axios';

export default async function handleAxiosApi<ResponseType>(
  axiosPromises: Promise<AxiosResponse<any>> | Promise<AxiosResponse<any>>[]
): Promise<ResponseType> {
  axiosPromises = Array.isArray(axiosPromises)
    ? axiosPromises
    : [axiosPromises];
  if (axiosPromises.length === 1) {
    const { data } = await axiosPromises[0];
    return data;
  }

  return Promise.all(
    axiosPromises.map(async (promise) => {
      const { data } = await promise;
      return data;
    })
  ) as any;
}
