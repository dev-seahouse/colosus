import { isEmail } from './isEmail';

describe('Validations: Email', () => {
  it('fails for invalid types', () => {
    // @ts-expect-error allowing for test case
    expect(isEmail()).toBe(false);
    // @ts-expect-error allowing for test case
    expect(isEmail(undefined)).toBe(false);
    // @ts-expect-error allowing for test case
    expect(isEmail(null)).toBe(false);
    // @ts-expect-error allowing for test case
    expect(isEmail(1234567890)).toBe(false);
  });

  it('passes for valid inputs', () => {
    expect(isEmail('abc-d@mail.com')).toBe(true);
    expect(isEmail('abc.def@mail.com')).toBe(true);
    expect(isEmail('abc@mail.com')).toBe(true);
    expect(isEmail('abc_def@mail.com')).toBe(true);
    expect(isEmail('abc.def@mail.cc')).toBe(true);
    expect(isEmail('abc.def@mail-archive.com')).toBe(true);
    expect(isEmail('abc.def@mail.org')).toBe(true);
    expect(isEmail('abc.def@mail.com')).toBe(true);
    expect(isEmail('test@mail.com')).toBe(true);
    expect(isEmail('test+one@mail.com')).toBe(true);
  });

  it('fails for invalid inputs', () => {
    expect(isEmail('')).toBe(false);
    expect(isEmail(' ')).toBe(false);
    expect(isEmail('abc..def@mail.com')).toBe(false);
    expect(isEmail('.abc@mail.com')).toBe(false);
    expect(isEmail('abc.def@mail.c')).toBe(false);
    expect(isEmail('abc.def@mail#archive.com')).toBe(false);
    expect(isEmail('abc.def@mail')).toBe(false);
    expect(isEmail('abc.def@mail..com')).toBe(false);
  });
});
