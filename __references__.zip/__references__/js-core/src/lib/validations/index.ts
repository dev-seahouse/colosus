export * from './isEmail';
export * from './isName';
export * from './isURL';
export * from './isValidPassword';
