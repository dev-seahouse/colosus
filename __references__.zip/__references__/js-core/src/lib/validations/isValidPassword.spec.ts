import { isValidPassword } from './isValidPassword';

describe('Validations: Password', () => {
  it('fails for invalid types', () => {
    // @ts-expect-error allowing for test case
    expect(isValidPassword()).toBe(false);
    // @ts-expect-error allowing for test case
    expect(isValidPassword(undefined)).toBe(false);
    // @ts-expect-error allowing for test case
    expect(isValidPassword(null)).toBe(false);
    // @ts-expect-error allowing for test case
    expect(isValidPassword(1234567890)).toBe(false);
  });

  it('passes for valid inputs', () => {
    expect(isValidPassword('1!Password')).toBe(true);
  });

  it('fails for invalid inputs', () => {
    expect(isValidPassword('')).toBe(false);
    expect(isValidPassword(' ')).toBe(false);
    expect(isValidPassword('aaaaaaaa')).toBe(false);
    expect(isValidPassword('AAAAAAAA')).toBe(false);
    expect(isValidPassword('Pswrd1!')).toBe(false);
  });
});
