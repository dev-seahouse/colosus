export const PASSWORD_PATTERN = /^(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{8,}$/;

export const isValidPassword = (value: string): boolean => {
  return !!PASSWORD_PATTERN.test(value);
};
