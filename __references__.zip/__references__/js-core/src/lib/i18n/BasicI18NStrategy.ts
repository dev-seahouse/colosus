import { formatString } from '../formatters';
import { Primitive } from '../types';
import { isRTL } from './languages';
import { I18NArguments, I18NStrategy, VocabularyDefinition } from './types';

export class BasicI18NStrategy implements I18NStrategy {
  private selectedVocabulary: VocabularyDefinition | null = null;

  t(...params: I18NArguments): string {
    const [text, ...rest] = params;
    if (!text) {
      return text;
    }
    const translatedText = this.selectedVocabulary
      ? this.selectedVocabulary.values[text.toLocaleLowerCase()]
      : undefined;
    if (!translatedText) {
      this.onInvalidTranslation(text, this.selectedVocabulary?.name);
    }
    return formatString(translatedText || text, ...(rest as Primitive[]));
  }

  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  onInvalidTranslation(text: string, vocabulary: string | undefined) {
    // Do nothing by default
  }

  setVocabulary(name: string, vocabularyDefinition: VocabularyDefinition) {
    this.selectedVocabulary = vocabularyDefinition;
  }

  loadVocabularies() {
    return [];
  }

  isRTL() {
    if (this.selectedVocabulary) {
      return isRTL(this.selectedVocabulary.language);
    } else {
      return false;
    }
  }
}
