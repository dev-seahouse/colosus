import _ from '../../wrappedLibs/@lodash';

export default function joinPath(a = '', b = ''): string {
  return _.trimEnd(a, '/') + '/' + _.trimStart(b, '/');
}
