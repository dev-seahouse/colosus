export default function getQueryParams(url: string) {
  return url
    .split('?')
    .pop()
    ?.split('&')
    .map((param) => {
      const [key, val] = param.split('=');
      return [key, decodeURIComponent(val || '')];
    })
    .reduce((result: any, [key, val]) => {
      result[key] = val;
      return result;
    }, {});
}
