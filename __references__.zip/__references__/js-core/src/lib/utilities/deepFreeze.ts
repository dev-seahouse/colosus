export default function deepFreeze<T>(target: T): T {
  if (!target) {
    return target;
  }
  if (Array.isArray(target)) {
    return target.map((v) => deepFreeze(v)) as unknown as T;
  }
  const propNames = Object.getOwnPropertyNames(target);
  for (const name of propNames) {
    const value = (target as any)[name];
    if (value && typeof value === 'object') {
      deepFreeze(value);
    }
  }
  return Object.freeze(target);
}
