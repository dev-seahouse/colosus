export default function cloneFrozen<T>(target: T): T {
  if (target === null || typeof target !== 'object') {
    return target;
  }
  const clone = (target as any).constructor();
  for (const key in target) {
    const value = target[key];
    if (value && typeof value === 'object') {
      clone[key] = cloneFrozen(value);
    } else {
      clone[key] = value;
    }
  }
  return clone;
}
