'use strict';

import { formatString as sut } from './formatString';

describe('formatBytes', () => {
  it('should be defined', () => {
    expect(sut).toBeDefined();
  });

  it('should correctly format text with no parameters', () => {
    expect(sut('test')).toBe('test');
    expect(sut('test1')).toBe('test1');
    expect(sut('test2')).toBe('test2');
  });

  it('should ignore parameters if no tokens are provided', () => {
    expect(sut('test {0}')).toBe('test ');
    expect(sut('test1 {0}')).toBe('test1 ');
    expect(sut('test2 {0}')).toBe('test2 ');
  });

  it('should replace tokenised parameters', () => {
    expect(sut('test {0} {1} {2}', 1, 2, 3)).toBe('test 1 2 3');
    expect(sut('test1 {2} {1} {0}', 1, 2, 3)).toBe('test1 3 2 1');
    expect(sut('test2 {1} {0} {2}', 1, 2, 3)).toBe('test2 2 1 3');
    expect(sut('test2 {1} {1} {1}', 1, 2, 3)).toBe('test2 2 2 2');
    expect(sut('test2 {2} {2} {2}', 1, 2, 3)).toBe('test2 3 3 3');
    expect(sut('test2 {0} {0} {2}', 1, 2, 3)).toBe('test2 1 1 3');
  });

  it('should ignore parameters if not enough are provided', () => {
    expect(sut('test {0} {1}', 'param1', 'param2')).toBe('test param1 param2');
    expect(sut('test1 {0} {1}', 'param1')).toBe('test1 param1 ');
  });

  it('should handle boolean parameters', () => {
    expect(sut('OR| {0} {1} {2}', true, true, true)).toBe('OR| true true true');
    expect(sut('OR| {0} {1} {2}', true, false, true)).toBe(
      'OR| true false true'
    );
    expect(sut('OR| {0} {1} {2}', false, true, true)).toBe(
      'OR| false true true'
    );
    expect(sut('OR| {0} {1} {2}', false, false, false)).toBe(
      'OR| false false false'
    );
  });

  it('should handle formatting parameters', () => {
    expect(sut('test {0}', sut('f{0}mat', 'or'))).toBe('test format');
  });

  it('should handle undefined parameters', () => {
    expect(
      sut(
        'test {0} {0}',
        undefined as unknown as string,
        undefined as unknown as string
      )
    ).toBe('test  ');
  });

  it('should handle null parameters', () => {
    expect(
      sut('test {0} {0}', null as unknown as string, null as unknown as string)
    ).toBe('test  ');
  });

  it('should allow escaping of parameters', () => {
    expect(sut('test \\{0} {0}', 'skipped')).toBe('test {0} skipped');
  });
});
