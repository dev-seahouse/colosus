import { Primitive } from '../types';

export function formatString(str: string, ...parameters: Primitive[]) {
  return str.replace(/\\?{(\d+)}/g, (match: string, number: number) => {
    if (match.startsWith('\\')) {
      return match.substring(1);
    }
    return parameters[number] !== undefined && parameters[number] !== null
      ? parameters[number].toString()
      : '';
  });
}
